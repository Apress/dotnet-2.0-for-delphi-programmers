// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Threading;

namespace AsynchTest
{
	delegate bool Test();
	delegate void Method();
	
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			Test T = new Test(IsRunningInThreadPool);

			bool Synchronous = T();
			IAsyncResult Asynch = T.BeginInvoke(null, null);
			bool Asynchronous = T.EndInvoke(Asynch);
			Console.WriteLine("Synchronous = {0}, Asynchronous = {1}", Synchronous, Asynchronous);

			ThreadTester Tester = new ThreadTester();
			Method AsynchMethod = new Method(Tester.Asynch);
			AsyncCallback Callback = new AsyncCallback(Tester.Callback);

			AsynchMethod.EndInvoke(AsynchMethod.BeginInvoke(Callback, null));
			Console.WriteLine(Object.ReferenceEquals(Tester.AysnchThread, Tester.CallbackThread));

			Console.ReadLine();
		}

		private static bool IsRunningInThreadPool()
		{ 
			return Thread.CurrentThread.IsThreadPoolThread; 
		}
	}

	class ThreadTester
	{
		public Thread AysnchThread, CallbackThread;
		
		public void Asynch()
		{
			AysnchThread = Thread.CurrentThread;
		}

		public void Callback(IAsyncResult Asynch)
		{
			CallbackThread = Thread.CurrentThread;
		}
	}
}
