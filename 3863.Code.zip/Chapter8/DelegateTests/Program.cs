// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

namespace DelegateTests
{
    public delegate int IntFn(int N);

    class Program
    {
        static void Main(string[] args)
        {
            IntFn A = Test<int>.Closed;
            IntFn B = Test<string>.Closed;
            IntFn C = Test<int>.Constructed;
            IntFn D = Test<string>.Open<int>;
        }
    }

    public static class Test<T>
    {
        public static int Closed(int N) { return N; }
        public static T Constructed(T N) { return N; }
        public static X Open<X>(X N) { return N; }
    }
}
