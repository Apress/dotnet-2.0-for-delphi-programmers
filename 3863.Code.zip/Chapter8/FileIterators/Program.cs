// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace FileIterators
{
    class Program
    {
        static void Main(string[] args)
        {
            Contents ProjectDirectory = new Contents(@"..\.."); // assuming Visual Studio

            Console.WriteLine("Unsorted");
            foreach (FileSystemInfo Info in ProjectDirectory)
                Console.WriteLine(Info.FullName);

            Console.WriteLine("\nName(Unsorted)");
            foreach (string Filename in Name(ProjectDirectory))
                Console.WriteLine(Filename);

            Console.WriteLine("\nSorted");
            foreach (FileSystemInfo Info in ProjectDirectory.Sorted(Comparer))
                Console.WriteLine(Info.FullName);

            Console.WriteLine("\nName(Sorted)");
            foreach (string Filename in Name(ProjectDirectory.Sorted(Comparer)))
                Console.WriteLine(Filename);

            Console.ReadLine();
        }

        private static int Comparer(FileSystemInfo Left, FileSystemInfo Right)
        {
            if ((Left.Attributes & FileAttributes.Directory) != (Right.Attributes & FileAttributes.Directory))
                // Directories first
                return (Left.Attributes & FileAttributes.Directory) != 0
                    ? -1   // left < right left (directory before file)
                    : +1;  // left > right (file after directory)
            else
                return String.Compare(Left.Name, Right.Name, true);
        }

        private static IEnumerable<string> Name(IEnumerable<FileSystemInfo> Files)
        {
            foreach (FileSystemInfo File in Files)
                yield return File.Name;
        }
    }

    class Contents : IEnumerable<FileSystemInfo>
    {
        public Contents(string DirectoryName)
        {
            DirectoryInfo Root = new DirectoryInfo(DirectoryName);
            if (!Root.Exists)
                throw new ArgumentException(String.Format("Directory \"{0}\" does not exist", DirectoryName));
            if ((Root.Attributes & FileAttributes.Directory) == 0)
                throw new ArgumentException(String.Format("\"{0}\" is not a directory", DirectoryName));
            this.Root = Root;
        }
        private DirectoryInfo Root;

        #region IEnumerable<FileSystemInfo> Members

        public IEnumerator<FileSystemInfo> GetEnumerator()
        {
            foreach (FileSystemInfo Info in Unsorted(Root))
                yield return Info;
        }

        private IEnumerable<FileSystemInfo> Unsorted(DirectoryInfo Root)
        {
            foreach (FileSystemInfo Info in Root.GetFileSystemInfos())
            {
                yield return Info;
                DirectoryInfo Directory = Info as DirectoryInfo;
                if (Directory != null)
                    foreach (FileSystemInfo Child in Unsorted(Directory))
                        yield return Child;
            }
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        #region Sorted

        public IEnumerable<FileSystemInfo> Sorted(Comparison<FileSystemInfo> Sorter)
        {
            return Sorted(Root, Sorter);
        }

        private IEnumerable<FileSystemInfo> Sorted(DirectoryInfo Root, Comparison<FileSystemInfo> Sorter)
        {
            FileSystemInfo[] Elements = Root.GetFileSystemInfos();
            Array.Sort(Elements, Sorter);
            foreach (FileSystemInfo Info in Elements)
            {
                yield return Info;
                DirectoryInfo Directory = Info as DirectoryInfo;
                if (Directory != null)
                    foreach (FileSystemInfo Child in Sorted(Directory, Sorter))
                        yield return Child;
            }
        }

        #endregion Sorted
    }
}
