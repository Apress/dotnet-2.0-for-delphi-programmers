// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

namespace OpenInterface
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    public interface IClosed
    {
        T OpenFn<T>(T Param);
    }

    public interface IOpen<T>
    {
        T Fn(T Param);
    }

    public class Open<T> : IOpen<T>, IClosed
    {
        public T Fn(T Param)
        {
            throw new NotImplementedException();
        }

        public T2 OpenFn<T2>(T2 Param)
        {
            throw new NotImplementedException();
        }
    }

    public class Closed : IOpen<int>, IClosed
    {
        public int Fn(int Param)
        {
            throw new NotImplementedException();
        }

        public T OpenFn<T>(T Param)
        {
            throw new NotImplementedException();
        }
    }
}
