// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace Delegates
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			Class1 C = new Class1();
			Fn F = new Fn(C.Function);
			double Result = F(8d);
			Console.WriteLine(Result);
			Console.ReadLine();
		}

		private double Function(double Parameter)
		{
			return Parameter;
		}
	}

	internal delegate void Callback();
	public delegate double Fn(double D);
}
