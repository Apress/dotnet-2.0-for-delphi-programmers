// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

class CoVariance
{
	[System.STAThread]
	static void Main(string[] args)
	{
		System.Console.WriteLine("OK");
		System.Console.ReadLine();
	}

	// Statement below compiles under 2.0, not 1.1
	//	BaseFunction F = new BaseFunction(Base.BaseFn); // Covariant
	
	class Base
	{
		public static void BaseProc(Base B) { }
		public static Derived BaseFn(Base B) { return new Derived(); }
	}

	class Derived : Base
	{
		public static void DerivedProc(Derived D) { }
		public static Derived DerivedFn(Derived D) { return D; }
	}

	class ReDerived : Derived
	{
		public static void ReDerivedProc(ReDerived R) { }
	}

	delegate Base BaseFunction(Base B);
}
