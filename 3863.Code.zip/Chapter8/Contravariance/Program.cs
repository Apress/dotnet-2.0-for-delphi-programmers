// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

class ContraVariance
{
    [System.STAThread]
    static void Main(string[] args)
    {
        BaseMethod BaseP = new BaseMethod(Base.BaseProc);
        // Statement below doesn't compile under 1.1 or 2.0
        //BaseProc DerivedP = new BaseProc(Derived.DerivedProc);

        // Statement below compiles under 2.0, not 1.1
        //		DerivedMethod BaseD = new DerivedMethod(Base.BaseProc); // contravariant
        DerivedMethod DerivedD = new DerivedMethod(Derived.DerivedProc);

        System.Console.WriteLine("OK");
        System.Console.ReadLine();
    }

    // Statement below compiles under 2.0, not 1.1
    BaseFunction F = new BaseFunction(Base.BaseFn); // Covariant

    //	BaseMethod BaseP = new BaseMethod(Derived.DerivedProc);
    DerivedMethod DerivedP = new DerivedMethod(Derived.DerivedProc);

    // Statement below doesn't compile under 2.0 or 1.1
    //DerivedMethod BaseD = new DerivedMethod(ReDerived.ReDerivedProc);

    // Statement below compiles under 2.0, not 1.1
    DerivedMethod BaseD = new DerivedMethod(Base.BaseProc); // contravariant

    class Base
    {
        public static void BaseProc(Base B) { }
        public static Derived BaseFn(Base B) { return new Derived(); }
    }

    class Derived : Base
    {
        public static void DerivedProc(Derived D) { }
        public static Derived DerivedFn(Derived D) { return D; }
    }

    class ReDerived : Derived
    {
        public static void ReDerivedProc(ReDerived R) { }
    }

    delegate void BaseMethod(Base B);
    delegate void DerivedMethod(Derived D);

    delegate Base BaseFunction(Base B);
    delegate Base DerivedFunction(Derived D);
}
