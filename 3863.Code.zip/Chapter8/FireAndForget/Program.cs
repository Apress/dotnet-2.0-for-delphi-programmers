// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using Shemitz.Utilities;

namespace FireAndForgetTest
{
    delegate void FourStrings(string E, string A, string D, string G);

    class Program
    {
        static void Main(string[] args)
        {
            FourStrings Background = Quartet;

            System.Threading.ThreadPool.QueueUserWorkItem(
                delegate { Quartet("Fred", "George", "Ron", "Ginny"); }
                );

            Background.BeginInvoke("John", "Paul", "George", "Ringo",
                FireAndForget.EndInvokeDelegate, Background);
            Console.ReadLine();
        }

        static void Quartet(string A, string B, string C, string D)
        {
            Console.WriteLine("{0}, {1}, {2}, {3}", A, B, C, D);
        }
    }

}
