// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;

using NUnit.Framework;

namespace DelegateEditing
{
    [TestFixture]
    public class DelegateTests
    {
        private delegate void Method(object sender);

        private Method EventList;
        private event Method Fred
        {
            add { EventList += value; }
            remove { EventList -= value; }
        }

        private void Dummy(object sender) { }

        [Test]
        public void Add()
        {
            Method This = new Method(Dummy); // C# 1.x
            Method That = Dummy;             // C# 2

            Method Foo = This - That;
            Assert.IsNull(Foo);

            Foo += This;


            Method Two = (Method)Delegate.Combine(This, That);
            Two = This + That;

            Two(this);

            Method TwoA = (Method)Delegate.Combine(This, This);
            Method TwoB = (Method)Delegate.Combine(That, That);

            Method Three = (Method)Delegate.Combine(new Method(Dummy), Two);
            Method Four = (Method)Delegate.Combine(Two, Two);

            Assert.IsNull(EventList);

            EventList += TwoA;
            EventList += TwoB;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(4, EventList.GetInvocationList().Length);

            EventList -= Two;
            EventList -= Four;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(2, EventList.GetInvocationList().Length);

            EventList += Two;
            EventList -= Four;
            Assert.IsNull(EventList);

            EventList += Four;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(4, EventList.GetInvocationList().Length);

            EventList = (Method)Delegate.RemoveAll(EventList, This);
            Assert.IsNull(EventList);

            EventList += EventList;
            Assert.IsNull(EventList);

            //			EventList += This;
            Fred += This;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(1, EventList.GetInvocationList().Length);

            EventList -= Two;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(1, EventList.GetInvocationList().Length);

            EventList -= That;
            Assert.IsNull(EventList);

            EventList += This;
            EventList += This;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(2, EventList.GetInvocationList().Length);

            Assert.IsNotNull(EventList);

            EventList -= new Method(Dummy);
            Assert.IsNotNull(EventList);
            Assert.AreEqual(1, EventList.GetInvocationList().Length);

            EventList -= Two;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(1, EventList.GetInvocationList().Length);

            EventList -= new Method(Dummy);
            Assert.IsNull(EventList);

            EventList += Two;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(2, EventList.GetInvocationList().Length);

            EventList += Four;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(6, EventList.GetInvocationList().Length);

            EventList -= new Method(Dummy);
            Assert.IsNotNull(EventList);
            Assert.AreEqual(5, EventList.GetInvocationList().Length);

            EventList -= Three;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(2, EventList.GetInvocationList().Length);

            EventList -= This;
            Assert.IsNotNull(EventList);
            Assert.AreEqual(1, EventList.GetInvocationList().Length);

            EventList -= That;
            Assert.IsNull(EventList);

            if (EventList != null)
                EventList(this);
        }


        private event Method NoDups
        {
            add { _NoDups = (Method)NoDuplicates.Combine(_NoDups, value); }
            remove { _NoDups = (Method)NoDuplicates.Remove(_NoDups, value); }
        }
        private Method _NoDups;

        public abstract class NoDuplicates
        {
            public static Delegate Combine(Delegate List, Delegate value)
            {
                // Add one copy of any value not currently in List
                Delegate[] Existing = List != null
                    ? List.GetInvocationList()
                    : new Delegate[0];
                foreach (Delegate Handler in value.GetInvocationList())
                    if (Array.IndexOf(Existing, Handler) < 0)
                    {
                        List = Delegate.Combine(List, Handler);
                        Existing = List.GetInvocationList();
                    }
                return List;
            }

            public static Delegate Remove(Delegate List, Delegate value)
            {
                // Remove List's copy of any delegate in value
                foreach (Delegate Handler in value.GetInvocationList())
                    List = Delegate.Remove(List, Handler);
                return List;
            }
        }


        [Test]
        public void RemoveAll()
        {
            Method This = new Method(Dummy);
            Method That = new Method(Dummy);

            Method Two = (Method)Delegate.Combine(This, That);
            Method Three = (Method)Delegate.Combine(new Method(Dummy), Two);
            Method Four = (Method)Delegate.Combine(Two, Two);

            Assert.IsNull(_NoDups);

            NoDups += Two;
            Assert.IsNotNull(_NoDups);
            Assert.AreEqual(1, _NoDups.GetInvocationList().Length);

            NoDups -= This;
            Assert.IsNull(_NoDups);

            NoDups += Two;
            NoDups += Two;
            Assert.IsNotNull(_NoDups);
            Assert.AreEqual(1, _NoDups.GetInvocationList().Length);

            NoDups -= This;
            Assert.IsNull(_NoDups);

            NoDups += Two;
            Assert.IsNotNull(_NoDups);
            Assert.AreEqual(1, _NoDups.GetInvocationList().Length);

            NoDups -= Four;
            Assert.IsNull(_NoDups);
            //			Assert.IsNotNull(_NoDups);
            //			Assert.AreEqual(2, _NoDups.GetInvocationList().Length);
        }

    }
}
