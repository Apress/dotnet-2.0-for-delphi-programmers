// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Xml;
using System.Text;

using FileSystemEntries;

namespace WriteDirectoryFile
{
    class Program
    {
        static void Main(string[] args)
        {
            string Chapter18Path = Environment.CurrentDirectory + @"\..\..\.."; // assuming Visual Studio ....

            DirectoryEntry Chapter18 = DirectoryEntry.FromPath(Chapter18Path);
            
            WriteDirectoryToXml(Chapter18Path + @"\Contents.xml", Chapter18);
        }

        private static void WriteDirectoryToXml(string XmlFilename, DirectoryEntry Chapter18)
        {
            //using (XmlTextWriter Writer = new XmlTextWriter(XmlFilename, Encoding.UTF8))
            //{
            //    Writer.Formatting = Formatting.Indented;
            //}

            XmlWriterSettings Settings = new XmlWriterSettings();
            Settings.Indent = true;

            using (XmlWriter XML = XmlWriter.Create(XmlFilename, Settings))
            {
                XML.WriteStartElement("Entries"); // the top-level element
                try
                {
                    Chapter18.Write(XML); // the actual data
                }
                finally
                {
                    XML.WriteEndElement(); // this is necessary!
                }
            }
        }
    }
}
