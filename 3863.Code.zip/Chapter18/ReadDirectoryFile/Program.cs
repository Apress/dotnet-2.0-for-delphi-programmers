// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

using FileSystemEntries;

namespace ReadDirectoryFile
{
    class Program
    {
        static void Main(string[] args)
        {
            // Note that this reads the file that the WriteDirectoryFile project creates
            string Chapter18Path = Environment.CurrentDirectory + @"\..\..\.."; // assuming Visual Studio ....

            DirectoryEntry FromFS  = DirectoryEntry.FromPath(Chapter18Path);
            DirectoryEntry FromXml = DirectoryEntry.FromXml(Chapter18Path + @"\Contents.xml");

            //Console.WriteLine("FromFS.Count: {0}, FromXml.Count: {1}", FromFS.Count, FromXml.Count);
            //foreach (FileSystemEntry Entry in FromXml)
            //    Console.WriteLine(Entry.Name);

            //FromFS.Show(0);
            //Console.WriteLine(new string('-', 70));
            //FromXml.Show(0);

            Console.WriteLine(FromFS.Matchs(FromXml));

            Console.ReadLine();
        }

    }
}
