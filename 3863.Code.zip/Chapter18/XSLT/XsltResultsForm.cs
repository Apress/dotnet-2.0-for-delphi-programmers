// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

using Shemitz.XML;
using Shemitz.Utilities;

namespace XSLT
{
    public partial class XsltResultsForm : Form
    {
        public XsltResultsForm()
        {
            InitializeComponent();
        }

        private void XsltResultsForm_Load(object sender, EventArgs e)
        {
            string Chapter18Path = Environment.CurrentDirectory + @"\..\..\.."; // assuming Visual Studio ....
            string ContentsXml = Chapter18Path + @"\Contents.xml";

            using (Stream Input = new FileStream(ContentsXml, FileMode.Open, FileAccess.Read))
            {
                RunXsl("First", Input, 
                    Xsl.Stylesheet(
                        Xsl.Template("Entries", "Matched the top-level element.")
                    ));
                RunXsl("Second", Input, 
                    Xsl.Stylesheet(
                        Xsl.Template("Entry", "Matched an <Entry/> element.")
                    ));
                RunXsl("Third", Input, 
                    Xsl.Stylesheet(
                        Xsl.Template("Entry", "Matched an ", Xsl.Text("&lt;", true), "Entry", Xsl.Text("&gt;", true), " element.")
                    ));
                RunXsl("Fourth", Input, 
                    Xsl.Stylesheet(
                        Xsl.Template("Entries", ""),
                        Xsl.Template("Entry", "Matched an ", Xsl.Text("&lt;", true), "Entry", Xsl.Text("&gt;", true), " element.")
                    ));
                RunXsl("Fifth", Input,
                    Xsl.Stylesheet(
                        Xsl.Template("Entries", Xsl.ApplyTemplates("Entry")),
                        Xsl.Template("Entry", "Matched an ", Xsl.Text("&lt;", true), "Entry", Xsl.Text("&gt;", true), " element.")
                    ));
                RunXsl("Sixth", Input,
                    Xsl.Stylesheet(
                        Xsl.Template("Entries", Xsl.ApplyTemplates("Entry")),
                        Xsl.Template("Entry",
                            Xsl.ApplyTemplates("@Name"), Xsl.Text("\n"), Xsl.ApplyTemplates("Entry"))
                    ));

                RunXsl("Seventh", Input,
                Xsl.Stylesheet(
                    Xsl.Template("Entries",
                        Xsl.ApplyTemplates("Entry",
                            Xsl.WithParam("Indent", true, "''")
                         )),
                    Xsl.Template("Entry", Xsl.Param("Indent"),
                        Xsl.ValueOf("$Indent"), Xsl.ValueOf("@Name"),
                        Xsl.Text(" "), Xsl.ValueOf("@LastWriteTime"),
                        Xsl.Text("\n"),
                        Xsl.ApplyTemplates("Entry",
                            Xsl.Sort("@Name"),
                            Xsl.WithParam("Indent", true, "concat($Indent, '  ')")
                        ))
                ));

                RunXsl("Eighth", Input,
                Xsl.Stylesheet(
                    Xsl.Template("Entries",
                        Xsl.ApplyTemplates("Entry",
                            Xsl.WithParam("Indent", true, "''")
                         )),
                    Xsl.Template("Entry", Xsl.Param("Indent"),
                        Xsl.ValueOf("$Indent"), Xsl.ValueOf("@Name"),
                        Xsl.CallTemplate("Filesize", Xsl.WithParam("Bytes", false, Xsl.ValueOf("@Bytes"))),
                        Xsl.Text(" "), Xsl.ValueOf("@LastWriteTime"),
                        Xsl.Text("\n"),
                        Xsl.ApplyTemplates("Entry",
                            Xsl.Sort("@Name"),
                            Xsl.WithParam("Indent", true, "concat($Indent, '  ')")
                        )),
                    Xsl.NamedTemplate("Filesize", Xsl.Param("Bytes"),
                        Xsl.If(" $Bytes != '' ",
                            Xsl.Text(" "), Xsl.ValueOf("$Bytes"), " bytes")
                        )
                ));
            }
        }

        private void RunXsl(string Caption, Stream Input, string XSL)
        {
            string Result;
            using (Stream Output = new MemoryStream())
            {
                Xsl.ApplyXslt(Output, Input, XSL);
                Result = StreamTools.ToString(Output);
            }

            TabPage NewPage = new TabPage(Caption);
            NewPage.BackColor = Color.White;
            Results.TabPages.Add(NewPage);

            Label ResultLabel = new Label();
            ResultLabel.Parent = NewPage;
            //ResultLabel.AutoSize = false;
            //ResultLabel.Dock = DockStyle.Fill;
            ResultLabel.Location = new Point(0);
            ResultLabel.AutoSize = true;
            ResultLabel.BackColor = Color.LightYellow;
            ResultLabel.Text = Result;

            int LineCount = Result.Split('\n').Length;
            toolTip.SetToolTip(ResultLabel, String.Format("{0} line{1}", LineCount, LineCount != 1 ? "s" : ""));
        }
    }
}