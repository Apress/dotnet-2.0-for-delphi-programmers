// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace DomTree
{
    public partial class DomTreeForm : Form
    {
        public DomTreeForm()
        {
            InitializeComponent();
        }

        private void DomTreeForm_Load(object sender, EventArgs e)
        {
            XmlDocument Files = new XmlDocument();
            Files.Load(Environment.CurrentDirectory + @"\..\..\..\Contents.xml");

            DomTree.BeginUpdate();
            try
            {
                ShowFiles((XmlElement)Files.DocumentElement.FirstChild, DomTree.Nodes);
            }
            finally
            {
                DomTree.EndUpdate();
            }
        }

        private void ShowFiles(XmlElement Element, TreeNodeCollection ParentNodes)
        {
            TreeNode Node = new TreeNode(Element.GetAttribute("Name"));
            ParentNodes.Add(Node);
            foreach (XmlElement Child in Element)
                ShowFiles(Child, Node.Nodes);
        }
    }
}