// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Xml;

namespace FileSystemEntries
{
    public sealed class FileEntry: FileSystemEntry
    {
        /// <summary>
        /// File size, in bytes
        /// </summary>
        public long Bytes;

        public FileEntry(FileInfo Info)
            : base(Info)
        {
            this.Bytes = Info.Length;
        }

        public FileEntry(string Name, string Fullname,
            DateTime CreationTime, DateTime LastAccessTime, DateTime LastWriteTime,
            FileAttributes Attributes,
            long Bytes)
            : base(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes)
        {
            this.Bytes = Bytes;
        }


        protected override void WriteDetails(XmlWriter XML)
        {
            XML.WriteAttributeString("Bytes", Bytes.ToString());
        }

        public override bool Matchs(FileSystemEntry Other)
        {
            FileEntry OtherFile = Other as FileEntry;
            return OtherFile != null && OtherFile.Fullname == Fullname;
        }

    }
}
