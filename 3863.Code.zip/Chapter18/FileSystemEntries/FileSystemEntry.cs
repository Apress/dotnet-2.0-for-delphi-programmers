// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace FileSystemEntries
{
    public abstract class FileSystemEntry
    {
        #region Fields

        /// <summary>
        /// The filename, sans path
        /// </summary>
        public string Name;

        /// <summary>
        /// The full, 'absolute' name - includes rooted path (no ..)
        /// </summary>
        public string Fullname;

        /// <summary>
        /// When the entry was created
        /// </summary>
        public DateTime CreationTime;

        /// <summary>
        /// When the entry was last used
        /// </summary>
        public DateTime LastAccessTime;

        /// <summary>
        /// when the entry was last written
        /// </summary>
        public DateTime LastWriteTime;

        /// <summary>
        /// The file attributes - read-only, hidden, &c
        /// </summary>
        public FileAttributes Attributes;

        #endregion Fields

        #region Constructors

        public FileSystemEntry(string Name, string Fullname, 
            DateTime CreationTime, DateTime LastAccessTime, DateTime LastWriteTime, 
            FileAttributes Attributes)
        {
            this.Name = Name;
            this.Fullname = Fullname;
            this.CreationTime = CreationTime;
            this.LastAccessTime = LastAccessTime;
            this.LastWriteTime = LastWriteTime;
            this.Attributes = Attributes;
        }

        public FileSystemEntry(FileSystemInfo FileInfo)
        {
            this.Name = FileInfo.Name;
            //this.Fullname = Path.GetFullPath(FileInfo.FullName);
            Debug.Assert(!Regex.IsMatch(FileInfo.FullName, DotDotBackslash), 
                "Fullname should be an 'absolute' name");
            this.Fullname = FileInfo.FullName;
            this.CreationTime = FileInfo.CreationTime;
            this.LastAccessTime = FileInfo.LastAccessTime;
            this.LastWriteTime = FileInfo.LastWriteTime;
            this.Attributes = FileInfo.Attributes;
        }

        private static string DotDotBackslash = Regex.Escape(@"..\");

        #endregion Constructors

        #region Write XML

        public void Write(XmlWriter XML)
        {
            XML.WriteStartElement("Entry"); // a single file system entry
            try
            {
                XML.WriteAttributeString("Name", Name);
                XML.WriteAttributeString("Fullname", Fullname);
                XML.WriteAttributeString("CreationTime", CreationTime.ToString());
                XML.WriteAttributeString("LastAccessTime", LastAccessTime.ToString());
                XML.WriteAttributeString("LastWriteTime", LastWriteTime.ToString());
                XML.WriteAttributeString("Attributes", Attributes.ToString());

                WriteDetails(XML);
            }
            finally
            {
                XML.WriteEndElement(); // this is necessary!
            }
        }

        protected abstract void WriteDetails(XmlWriter XML);

        #endregion Write XML

        #region Read XML

        /// <summary>
        /// Skip to next non-whitespace
        /// </summary>
        /// <param name="Xml"></param>
        protected static void SkiptoNextContent(XmlReader Xml)
        {
            bool More;
            do
                More = Xml.Read();
            while (More && Xml.NodeType == XmlNodeType.Whitespace);
        }

        /// <summary>
        /// Skip to next element with right Name
        /// </summary>
        protected static void NextElement(XmlReader Xml, String Name)
        {
            while (Xml.NodeType != XmlNodeType.Element || Xml.Name != Name)
                Xml.Read();
        }

        /// <summary>
        /// Goto next Entry or /Entries
        /// </summary>
        private static void NextEntry(XmlReader Xml)
        {
            bool IsNext, IsEnd;
            do
            {
                Xml.Read();
                IsNext = Xml.NodeType == XmlNodeType.Element && Xml.Name == "Entry";
                IsEnd = (!IsNext) && Xml.NodeType == XmlNodeType.EndElement && Xml.Name == "Entries";
            }
            while (!(IsNext || IsEnd));
        }

        /// <summary>
        /// Read next DirectoryEntry or a FileEntry
        /// </summary>
        protected static FileSystemEntry ReadElement(XmlReader Xml)
        {
            NextElement(Xml, "Entry");
            Debug.Assert(Xml.NodeType == XmlNodeType.Element && Xml.Name == "Entry");

            bool IsEmpty = Xml.IsEmptyElement; // Empty elements are files OR empty directories

            // Read attributes to Dictionary, so order doesn't matter
            Dictionary<string, string> XmlAttributes = GetAttributes(Xml);

            #region Read/parse common XML attributes

            string Name = XmlAttributes["Name"];
            string Fullname = XmlAttributes["Fullname"];
            DateTime CreationTime   = DateTime.Parse(XmlAttributes["CreationTime"]);
            DateTime LastAccessTime = DateTime.Parse(XmlAttributes["LastAccessTime"]);
            DateTime LastWriteTime  = DateTime.Parse(XmlAttributes["LastWriteTime"]);
            FileAttributes Attributes = (FileAttributes)Enum.Parse(typeof(FileAttributes), XmlAttributes["Attributes"], true);

            #endregion Read/parse common XML attributes

            #region Read entry; leave Xml positioned on either <Entry> OR </Entries>

            FileSystemEntry Result;
            if ((Attributes & FileAttributes.Directory) == 0)
            {
                // file
                Result = new FileEntry(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes,
                    long.Parse(XmlAttributes["Bytes"]));
                Debug.Assert(Xml.NodeType == XmlNodeType.Attribute);
            }
            else
            {
                // directory
                if (IsEmpty)
                {
                    // empty directory
                    Result = new DirectoryEntry(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes);
                    Debug.Assert(Xml.NodeType == XmlNodeType.Attribute);
                }
                else
                {
                    // Populated directory - read entries, leave Xml positioned on </Entry>
                    Result = new DirectoryEntry(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes,
                        Xml);
                    Debug.Assert(Xml.NodeType == XmlNodeType.EndElement && Xml.Name == "Entry",
                        String.Format("Expecting </Entry>, got {0}, {1}", Xml.NodeType, Xml.Name));
                }
            }

            SkiptoNextContent(Xml);
            
            #endregion Read entry; leave Xml positioned on either <Entry> OR </Entries>

            return Result;
        }

        private static Dictionary<string, string> GetAttributes(XmlReader Xml)
        {
            Dictionary<string, string> Result = new Dictionary<string, string>();
            if (Xml.MoveToFirstAttribute())
                do
                    Result[Xml.Name] = Xml.Value;
                while (Xml.MoveToNextAttribute());
            return Result;
        }

        #endregion Read XML

        public virtual void Show(int Depth)
        {
            Console.WriteLine("{0}{1}", new String('\t', Depth), Name);
        }

        public abstract bool Matchs(FileSystemEntry Other);
    }
}
