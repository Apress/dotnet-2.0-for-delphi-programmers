using System;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Collections.Generic;

namespace FileSystemEntries
{
    public sealed class DirectoryEntry : FileSystemEntry, IEnumerable<FileSystemEntry>
    {
        #region Fields & constructor(s)

        private List<FileSystemEntry> Contents = new List<FileSystemEntry>();

        public int Count
        {
            get { return Contents.Count; }
        }

        public FileSystemEntry this[int Index]
        {
            get { return Contents[Index]; }
        }

        public DirectoryEntry(DirectoryInfo Info)
            : base(Info)
        {
            foreach (FileSystemInfo Entry in Info.GetFileSystemInfos())
            {
                FileInfo File = Entry as FileInfo;
                if (File != null)
                    Contents.Add(new FileEntry(File));
                else
                {
                    DirectoryInfo Directory = Entry as DirectoryInfo;
                    Debug.Assert(Directory != null,
                        "FileSystemInfo should only be either FileInfo or DirectoryInfo");
                    Contents.Add(new DirectoryEntry(Directory));
                }
            }
        }

        public DirectoryEntry(string Name, string Fullname,
            DateTime CreationTime, DateTime LastAccessTime, DateTime LastWriteTime,
            FileAttributes Attributes)
            : base(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes)
        {}

        public DirectoryEntry(string Name, string Fullname,
            DateTime CreationTime, DateTime LastAccessTime, DateTime LastWriteTime,
            FileAttributes Attributes,
            XmlReader Xml)
            : base(Name, Fullname, CreationTime, LastAccessTime, LastWriteTime, Attributes)
        {
            NextElement(Xml, "Entry"); // skip to <Entry>

            while (Xml.NodeType == XmlNodeType.Element && Xml.Name == "Entry")
                Contents.Add(FileSystemEntry.ReadElement(Xml));

            Debug.Assert(Xml.NodeType == XmlNodeType.EndElement && Xml.Name == "Entry",
                String.Format("Expecting </Entry>, got {0}, {1}", Xml.NodeType, Xml.Name));
                        }

        public static DirectoryEntry FromPath(string Pathname)
        {
            DirectoryInfo Info = new DirectoryInfo(Pathname);

            // Return null if directory does not exist
            return (Info.Exists)
                ? new DirectoryEntry(Info)
                : null;
        }

        #endregion Fields & constructor(s)

        #region Write XML

        protected override void WriteDetails(XmlWriter XML)
        {
            foreach (FileSystemEntry Entry in Contents)
                Entry.Write(XML);
        }

        #endregion Write XML

        #region Read XML

        public static DirectoryEntry FromXml(string XmlFilename)
        {
            using (XmlReader Xml = XmlReader.Create(XmlFilename))
                return (DirectoryEntry)FileSystemEntry.ReadElement(Xml);
        }

        #endregion Read XML

        #region debug and examination code

        #region IEnumerable<FileSystemEntry> Members

        IEnumerator<FileSystemEntry> IEnumerable<FileSystemEntry>.GetEnumerator()
        {
            return Contents.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        public override void Show(int Depth)
        {
            base.Show(Depth);
            foreach (FileSystemEntry Child in Contents)
                Child.Show(Depth + 1);
        }

        public override bool Matchs(FileSystemEntry Other)
        {
            DirectoryEntry OtherDirectory = Other as DirectoryEntry;
            if (OtherDirectory == null || OtherDirectory.Fullname != Fullname || OtherDirectory.Count != Count)
                return false;
            for (int Index = 0; Index < Count; Index++)
                if (!this[Index].Matchs(OtherDirectory[Index]))
                    return false;
            return true;
        }

        #endregion debug and examination code
    }
}
