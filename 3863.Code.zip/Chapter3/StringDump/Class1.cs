// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Runtime.InteropServices;

namespace StringDump
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Dump("a");
			Dump("ab");
			Dump("abc");
			Dump("abcd");
			Dump("abcde");
			Console.ReadLine();
		}

		unsafe private static void Dump(string S)
		{
			GCHandle Handle = GCHandle.Alloc(S, GCHandleType.Pinned);
			try
			{
				void* Pointer = Handle.AddrOfPinnedObject().ToPointer();
				int* Header = ((int*) Pointer - 4);
				char* Data = (char*) Pointer;
				for (int I = 0; I < 4; I++)
					Console.Write("{0:x8} ", *(Header++));
				Console.WriteLine();
				int ArrayLength = *(Header - 2);
				for (int I = 0; I < ArrayLength; I++)
				{
					char C = *(Data++);
					Console.Write("{0} ({1:x4}) ", C, (int) C);
				}
				Console.WriteLine();
			}
			finally
			{
				Handle.Free();
			}
		}
	}
}
