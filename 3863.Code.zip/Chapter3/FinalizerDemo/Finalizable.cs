// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace FinalizerDemo
{
    public abstract class Finalizable : IDisposable
    {
        /// <summary>
        /// You can call methods of reference fields from Dispose -
        /// but not from the destructor
        /// </summary>
        protected virtual void DisposeManaged() { }

        /// <summary>
        /// This method is called when the method is disposed OR finalized. 
        /// It should only call methods of objects in global data structures, 
        /// or static methods, or unmanaged primitives (close handles, etc).
        /// </summary>
        protected abstract void ReleaseUnmanaged();

        /// <summary>
        /// This is called directly or indirectly from user code. 
        /// It is safe to dispose of managed instances. 
        /// </summary>
        public void Dispose()
        {
            Dispose(true); // Safe to Dispose of reference fields
        }

        /// <summary>
        /// Any reference fields may have been finalized: 
        /// It is not safe to dispose of managed instances.
        /// </summary>
        ~Finalizable()
        {
            Dispose(false); // only release unmanaged resources
        }

        private void Dispose(bool Managed)
        {
            if (!disposed)
            {
                if (Managed)
                {
                    DisposeManaged(); // may be no-op
                    GC.SuppressFinalize(this); // DON'T call the finalizer!
                }
                ReleaseUnmanaged(); // the whole point of all this
            }
            disposed = true;
        }

        private bool disposed = false;
    }
}
