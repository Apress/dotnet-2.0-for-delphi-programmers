// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
//using System.Runtime.InteropServices;

namespace LargeObjectHeap
{
    class Program
    {
        static void Main(string[] args)
        {
            int Cutoff = LargeObjectCutoff(1, 100000);
            Console.WriteLine("LargeObjectCutoff at {0} characters", Cutoff);
            for (int N = Cutoff - 2; N <= Cutoff + 2; N++)
                Show(N);
            Console.ReadLine();
        }

        static int LargeObjectCutoff(int Low, int High)
        {
            if ((High - Low) <= 1)
                return Low;
            else
            {
                int Middle = Low / 2 + High / 2; // extra div avoids possibility of overflow
                string S = new String(' ', Middle);
                int Generation = GC.GetGeneration(S);
                S = null; // probably not necessary - jitter will see it is not used any more
                if (Generation == 0)
                    return LargeObjectCutoff(Middle, High);
                else
                    return LargeObjectCutoff(Low, Middle);
            }
        }

        static void Show(int Chars)
        {
            string S = new String(' ', Chars);
            Console.WriteLine("{0} chars, generation {1}", Chars, GC.GetGeneration(S));
        }
    }
}
