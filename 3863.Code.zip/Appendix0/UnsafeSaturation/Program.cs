// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;

using Shemitz.Utilities;

namespace UnsafeSaturation
{
    public delegate void Method();

    class Program
    {
        const float SaturationLevel = 3f; // 0 is grayscale. 1 is normal color. 1/2 is halfway to grayscale ....

        static void Main(string[] args)
        {
            Bitmap Original = EmbeddedResource.GetBitmap("redwall_cavern.60.jpg");
            Bitmap Copy = SetSaturation(Original, SaturationLevel);
            string CopyName = string.Format(@"redwall_cavern.60.saturation({0:f2}).jpg", SaturationLevel);
            Copy.Save(CopyName, ImageFormat.Jpeg); // in exe directory

            Method Safe = delegate { Recolor(Original, SaturationLevel); };
            Method Unsafe = delegate { SetSaturation(Original, SaturationLevel); };

            using (new Benchmark())
            {
                Safe(); // safe is faster, no matter what order you call Safe/Unsafe
                Unsafe();
            }
            using (new Benchmark("Safe"))
                Safe();
            using (new Benchmark("Unsafe"))
                Unsafe();
            Console.ReadLine();
        }

        const float RedComponent = 0.3f, GreenComponent = 0.59f, BlueComponent = 0.11f; // http://www.bobpowell.net/grayscale.htm

        /// <summary>
        /// Grays or overcolors a Bitmap
        /// </summary>
        /// <param name="Original">Bitmap to recolor</param>
        /// <param name="ColorLevel">0 is gray, 1 is normal, 2 is double color, and so on.</param>
        public static Bitmap Recolor(Bitmap Original, float Saturation)
        {
            // Create the ColorMatrix
            ColorMatrix NewMatrix = new ColorMatrix(); // identity matrix

            NewMatrix.Matrix00 = RedComponent + (1f - RedComponent) * Saturation;
            NewMatrix.Matrix01 = NewMatrix.Matrix02 = RedComponent - RedComponent * Saturation;

            NewMatrix.Matrix11 = GreenComponent + (1f - GreenComponent) * Saturation;
            NewMatrix.Matrix10 = NewMatrix.Matrix12 = GreenComponent - GreenComponent * Saturation;

            NewMatrix.Matrix22 = BlueComponent + (1f - BlueComponent) * Saturation;
            NewMatrix.Matrix20 = NewMatrix.Matrix21 = BlueComponent - BlueComponent * Saturation;

            Bitmap NewImage = new Bitmap(Original.Width, Original.Height);

            using (Graphics NewGraphics = Graphics.FromImage(NewImage))
            using (ImageAttributes NewAttributes = new ImageAttributes())
            {
                NewAttributes.SetColorMatrix(NewMatrix);
                NewGraphics.DrawImage(Original,
                    new Rectangle(new Point(0, 0), Original.Size),
                    0, 0, Original.Width, Original.Height,
                    GraphicsUnit.Pixel,
                    NewAttributes);
            }
            return NewImage;
        }

        public static Bitmap SetSaturation(Bitmap Original, float S)
        {
            return Copy(Original, Saturation.Map(S));
        }

        private class Saturation: IMap
        {
            public static IMap Map(float S)
            {
                return new Saturation(S);
            }

            private Saturation(float S)
            {
                RedTerm = RedComponent + (1f - RedComponent) * S;
                NotRedTerm = RedComponent - RedComponent * S;

                GreenTerm = GreenComponent + (1f - GreenComponent) * S;
                NotGreenTerm = GreenComponent - GreenComponent * S;

                BlueTerm = BlueComponent + (1f - BlueComponent) * S;
                NotBlueTerm = BlueComponent - BlueComponent * S;
            }

            private float RedTerm, NotRedTerm, GreenTerm, NotGreenTerm, BlueTerm, NotBlueTerm;

            Color IMap.Map(Color C)
            {
                int Red = C.R, Green = C.G, Blue = C.B;

                return Color.FromArgb(
                    Choke(RedTerm * Red + NotGreenTerm * Green + NotBlueTerm * Blue),
                    Choke(NotRedTerm * Red + GreenTerm * Green + NotBlueTerm * Blue),
                    Choke(NotRedTerm * Red + NotGreenTerm * Green + BlueTerm * Blue));
            }

            private int Choke(float Value)
            {
                return Value >= 255
                    ? 255 // high limit
                    : Value <= 0
                        ? 0 // low limit
                        : (int)Value; // else, Value
            }
        }

        public interface IMap
        {
            Color Map(Color C);
        }

        #region unsafe

        /// <remarks>I could undoubtedly �bum� a few cycles from the key Program.Copy method - but
        /// I'm recovering from a mountain bike accident that makes it hard to type. September 11, 2005.</remarks>
        public static Bitmap Copy(Bitmap Original, IMap M)
        {
            Bitmap NewImage = new Bitmap(Original.Width, Original.Height);

            BitmapData Result = NewImage.LockBits(
                new Rectangle(new Point(0), NewImage.Size), ImageLockMode.WriteOnly, NewImage.PixelFormat);
            try
            {
                BitmapData Input = Original.LockBits(
                    new Rectangle(new Point(0), Original.Size), ImageLockMode.ReadOnly, Original.PixelFormat);
                try
                {
                    PixelPtr InputPtr = PixelPtr.Factory(Input);
                    PixelPtr ResultPtr = PixelPtr.Factory(Result);
                    if (M == null) // copy
                        for (int Row = 0; Row < Input.Height; Row++)
                        {
                            InputPtr.Row = ResultPtr.Row = Row;

                            for (int Column = 0; Column < Input.Width; Column++)
                            {
                                Color C = InputPtr.Read();
                                ResultPtr.Write(C);
                            }
                        }
                    else // process
                        for (int Row = 0; Row < Input.Height; Row++)
                        {
                            InputPtr.Row = ResultPtr.Row = Row;

                            for (int Column = 0; Column < Input.Width; Column++)
                            {
                                Color C = M.Map(InputPtr.Read());
                                ResultPtr.Write(C);
                            }
                        }
                    return NewImage;
                }
                finally
                {
                    Original.UnlockBits(Input);
                }
            }
            finally
            {
                NewImage.UnlockBits(Result);
            }
        }

        private unsafe abstract class PixelPtr
        {
            public static PixelPtr Factory(BitmapData Locked)
            {
                int Bytes = Locked.Stride / Locked.Width;
                switch (Bytes)
                {
                    case 3:
                        return new TwentyFourBit(Locked);
                    case 4:
                        return new ThirtyTwoBit(Locked);
                    default:
                        throw new NotSupportedException("Only 24-bit and 32-bit formats implemented");
                }
            }

            protected PixelPtr(BitmapData Locked, int Bytes)
            {
                this.Locked = Locked;
                this.Ptr = (uint*)Locked.Scan0; // row 0
                this.Bytes = Bytes; // Locked.Stride / Locked.Width;
                System.Diagnostics.Debug.Assert(Bytes == Locked.Stride / Locked.Width);
                System.Diagnostics.Debug.Assert(Bytes >= 3);
            }

            protected readonly BitmapData Locked;
            protected readonly int Bytes;
            protected uint* Ptr;

            public int Row
            {
                set
                {
                    Ptr = (uint*)((int)Locked.Scan0 + Locked.Stride * value);
                }
            }

            public abstract Color Read();

            public abstract void Write(Color C);

            protected void Skip()
            {
                Ptr = (uint*)((int)Ptr + Bytes);
            }
        }

        private unsafe sealed class ThirtyTwoBit : PixelPtr
        {
            public ThirtyTwoBit(BitmapData Locked)
                : base(Locked, 4)
            {
            }

            public override Color Read()
            {
                return Color.FromArgb((int)*(Ptr++));
            }

            public override void Write(Color C)
            {
                *(Ptr++) = (uint)C.ToArgb();
            }
        }

        private unsafe sealed class TwentyFourBit : PixelPtr
        {
            public TwentyFourBit(BitmapData Locked)
                : base(Locked, 3)
            {
            }

            public override Color Read()
            {
                uint Mask = 0x00FFFFFF; // low 24-bits
                uint Value = (*Ptr & Mask) | 0xFF00000; // or in full alpha
                Skip();
                //Ptr = (uint*)((int)Ptr + 3);
                return Color.FromArgb((int)Value);
            }

            public override void Write(Color C)
            {
                uint MaskOn = 0x00FFFFFF; // low 24-bits
                uint MaskOff = 0xFFFFFFFF ^ MaskOn;
                *Ptr = ((uint)C.ToArgb() & MaskOn) | (*Ptr & MaskOff);
                Skip();
                //Ptr = (uint*)((int)Ptr + 3);
                //*(Ptr++) = (uint)C.ToArgb();
            }
        }

        #endregion unsafe
    }
}
