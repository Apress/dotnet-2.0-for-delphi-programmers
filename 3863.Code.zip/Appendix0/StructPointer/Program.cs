// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

namespace structpointer
{
    class Program
    {
        unsafe struct Safe 
        {
            public fixed int N[7];
            public int X, Y;
            public int Fn(int N) { Console.WriteLine("{0}", N); return N; }
        }
        struct Unsafe { string A, B, C; }

        unsafe struct A { fixed char String[5];}
        //struct B { fixed Safe BB[5];}
        //struct C { fixed Unsafe CC[5];}

        static void Main(string[] args)
        {
            unsafe
            {
                Safe Struct;
                //Safe* S = &Struct;
                Safe* S = null;

                void* fred = &Struct;
                S = (Safe*)fred;

                S->Fn(77);


                char First;

                string ManagedString = "ManagedString";
                fixed (char* StringPtr = ManagedString)
                    First = *StringPtr;

                int[] Table = new int[] { 1, 2, 3 };
                fixed (int* IntPtr = Table)
                {
                }
            }
        }
    }
}
