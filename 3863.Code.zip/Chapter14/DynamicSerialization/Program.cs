﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Collections;

using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

using System.Xml.Serialization;

using System.Diagnostics;
//using Shemitz.Utilities;

using NUnit.Framework;

#endregion

namespace DynamicSerialization
{
    [TestFixture]
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This code will execute");
            Root R = new Root(), R1;
            string Filename = Path.GetTempFileName();
            try
            {
                #region with explicit Descendant type
                Console.WriteLine("This code will execute");
                using (Stream Write = new FileStream(Filename, FileMode.Create))
                {
                    XmlSerializer Serializer = new XmlSerializer(typeof(Root), new Type[] { typeof(Descendant) });
                    Serializer.Serialize(Write, R);
                }

                using (Stream Read = new FileStream(Filename, FileMode.Open))
                {
                    XmlSerializer Serializer = new XmlSerializer(typeof(Root), new Type[] { typeof(Descendant) });
                    R1 = (Root)Serializer.Deserialize(Read);
                }
                #endregion with explicit Descendant type

                #region withOUT explicit Descendant type
                Console.WriteLine("This code throws exceptions");
                try
                {
                    using (Stream Write = new FileStream(Filename, FileMode.Create))
                    {
                        XmlSerializer Serializer = new XmlSerializer(typeof(Root));
                        Serializer.Serialize(Write, R); // this will throw an InvalidOperationException
                    }

                    using (Stream Read = new FileStream(Filename, FileMode.Open))
                    {
                        XmlSerializer Serializer = new XmlSerializer(typeof(Root));
                        R1 = (Root)Serializer.Deserialize(Read);
                    }
                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("This code threw an InvalidOperationException, as expected");
                }
                #endregion withOUT explicit Descendant type
            }
            finally
            {
                File.Delete(Filename);
            }
            Console.WriteLine("OK.");
            Console.WriteLine("This sort of thing really belongs in NUnit ....");
            Console.ReadLine();
        }

        [Test]
        public void ExtraBindings()
        {
            SerializeDeserialize(delegate
            {
                return new XmlSerializer(typeof(Root), new Type[] { typeof(Descendant) });
            });
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void NoExtraBindings()
        {
            SerializeDeserialize(delegate { return new XmlSerializer(typeof(Root)); });
        }

        private delegate XmlSerializer NewSerializer();

        private static void SerializeDeserialize(NewSerializer newSerializer)
        {
            Root R = new Root(), R1;
            string Filename = Path.GetTempFileName();
            try
            {
                using (Stream Write = new FileStream(Filename, FileMode.Create))
                {
                    XmlSerializer Serializer = newSerializer(); // new XmlSerializer(typeof(Root));
                    Serializer.Serialize(Write, R);
                }

                using (Stream Read = new FileStream(Filename, FileMode.Open))
                {
                    XmlSerializer Serializer = newSerializer(); // new XmlSerializer(typeof(Root));
                    R1 = (Root)Serializer.Deserialize(Read);
                }
                Assert.AreEqual(9, R1.Nine);
            }
            finally
            {
                File.Delete(Filename);
            }
        }
    }

    public class Root
    {
        public Ancestor Late1 = new Child();
        public Ancestor Late2 = new GrandChild();

        public Ancestor LateBoundTrouble = new Descendant();
        public object Nine = 9;
    }

    //    [XmlInclude(typeof(Descendant))] // this attribute will make the NoExtraBindings test fail, by not throwing an exception
    [XmlInclude(typeof(Child)), XmlInclude(typeof(GrandChild))]
    public abstract class Ancestor
    {
    }

    public class Descendant : Ancestor
    {
    }

    public class Child : Ancestor
    {
    }

    //[XmlInclude(typeof(Program))] // legal, but sort of pointless!
    public class GrandChild : Child
    {
        public Friend Frank = new Friend();
    }

    public class Friend
    {
    }
}
