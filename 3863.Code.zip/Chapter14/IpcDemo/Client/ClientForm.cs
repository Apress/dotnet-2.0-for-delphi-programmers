using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Library;

namespace Client
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();
        }

        private void Client_Load(object sender, EventArgs e)
        {
            System.Diagnostics.Process Server = new System.Diagnostics.Process();
            Server.StartInfo.FileName = "Server.exe";
            Server.Start();

            string Request = String.Format("ipc://{0}/{1}", Remote.Name, Remote.Verb);
            Proxy = (Remote)Activator.GetObject(typeof(Remote), Request);
            MessageBox.Show((Proxy.GetType() == typeof(Remote)).ToString());
            //MessageBox.Show(Proxy.GetType().AssemblyQualifiedName);
            //Type TT = typeof(Client).GetType();
            //MessageBox.Show(TT.ToString());
        }

        private Remote Proxy;

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            Proxy.ButtonDown();
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            Proxy.ButtonUp();
        }
    }
}