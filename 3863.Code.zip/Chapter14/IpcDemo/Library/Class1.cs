using System;

namespace Library
{
    public interface IRemote
    {
        void ButtonDown();

        void ButtonUp();
    }
}
