using System;

namespace Library
{
    public abstract class Remote: MarshalByRefObject
    {
        public const string Name = "ipctest";

        public const string Verb = "remote";

        public abstract void ButtonDown();

        public abstract void ButtonUp();
    }
}
