// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;

using Library;

namespace Server
{
    public partial class Server : Form
    {
        public Server()
        {
            InitializeComponent();
        }

        private void Server_Load(object sender, EventArgs e)
        {
            Form = this;

            IpcChannel Channel = new IpcChannel(Remote.Name);
            ChannelServices.RegisterChannel(Channel);
            RemotingConfiguration.RegisterWellKnownServiceType(
                typeof(ServerSideObject),
                Remote.Verb,
                WellKnownObjectMode.Singleton);
        }

        public static Server Form;
    }

    class ServerSideObject : Remote
    {
        public override void ButtonDown()
        {
            Server.Form.BeginInvoke((MethodInvoker)delegate
            {
                Server.Form.StatusLbl.Text = "Down";
            });
        }

        public override void ButtonUp()
        {
            Server.Form.BeginInvoke((MethodInvoker)delegate
            {
                Server.Form.StatusLbl.Text = "Up";
            });
        }
}
}