﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Collections;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

#endregion

namespace DeserializationCallback
{
    class Program
    {
        static void Main(string[] args)
        {
            Root R = new Root();
            R.Populate();

            string Filename = Path.GetTempFileName();
            try
            {
                using (Stream Write = new FileStream(Filename, FileMode.Create))
                {
                    BinaryFormatter Serializer = new BinaryFormatter();
                    Serializer.Serialize(Write, R);
                }

                using (Stream Read = new FileStream(Filename, FileMode.Open))
                {
                    BinaryFormatter Serializer = new BinaryFormatter();
                    Serializer.Deserialize(Read);
                }
            }
            finally
            {
                File.Delete(Filename);
            }

            Console.ReadLine();
        }
    }

    [Serializable]
    public class Root : IDeserializationCallback
    {
        public ArrayList List = new ArrayList();

        public void Populate()
        {
            // Create a circular list
            Node C = new Node("C");
            Node B = new Node("B", C);
            Node A = new Node("A", B);
            C.Next = A;

            // populate the List member
            List.AddRange(new Node[] { C, B, A, B, C });
        }

        #region IDeserializationCallback Members

        public void OnDeserialization(object sender)
        {
            Console.WriteLine("Root.OnDeserialization (sender {0}= null)", sender == null ? "=" : "!");
        }

        #endregion
    }

    [Serializable]
    public class Node : IDeserializationCallback
    {
        public string Text;
        public Node Next;

        public Node(string Text): this(Text, null) { }

        public Node(string Text, Node Next)
        {
            this.Text = Text;
            this.Next = Next;
        }

        #region IDeserializationCallback Members

        public void OnDeserialization(object sender)
        {
            Console.WriteLine("Node {0}.OnDeserialization (sender {1}= null)", Text, sender == null ? "=" : "!");
        }

        #endregion
    }
}
