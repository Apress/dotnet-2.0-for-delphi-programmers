﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

#endregion

namespace BinarySerialization
{
    class Program
    {
        static void Main(string[] args)
        {
            const string Filename = "serialized.bin";

            Data One = new Data(), Two = new Data();
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                BinaryFormatter Serializer = new BinaryFormatter();
                Serializer.Serialize(Write, One);
                Serializer.Serialize(Write, Two);
            }

            Data OneA, TwoA;
            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                BinaryFormatter Serializer = new BinaryFormatter();
                OneA = (Data)Serializer.Deserialize(Read);
                TwoA = (Data)Serializer.Deserialize(Read);
            }

            Console.WriteLine("One: {0}, {1}", One.SerialNumber == OneA.SerialNumber, One.CreationTime == OneA.CreationTime);
            Console.WriteLine("Two: {0}, {1}", One.SerialNumber == OneA.SerialNumber, One.CreationTime == OneA.CreationTime);
            Console.WriteLine("new Data().SerialNumber == {0}", new Data().SerialNumber);
            Console.ReadLine();
        }
    }

    [Serializable]
    class Data
    {
        private static int CreatedThisSession = 0;
        public int SerialNumber;
        public DateTime CreationTime;

        public Data()
        {
            SerialNumber = ++CreatedThisSession;
            CreationTime = DateTime.Now;
        }
    }
}
