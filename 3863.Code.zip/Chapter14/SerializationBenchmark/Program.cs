﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Collections;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;

using System.Diagnostics;
using Shemitz.Utilities;

#endregion

namespace SerializationBenchmark
{
    class Program
    {
        static void Main(string[] args)
        {
            Root R = new Root();
            R.Populate();

//            Console.WriteLine(((Node)R.List[2]).bogus);

            string Filename = Path.GetTempFileName();
            try
            {
                using (new Benchmark(null))
                    new XmlSerializer(typeof(Node));
                using (new Benchmark("First 'new XmlSerializer(typeof(Root))'"))
                    new XmlSerializer(typeof(Root));
                using (new Benchmark("Second 'new XmlSerializer(typeof(Root))'"))
                    new XmlSerializer(typeof(Root));
                using (new Benchmark("Third 'new XmlSerializer(typeof(Root))'"))
                    new XmlSerializer(typeof(Root));

                    //                using (new Benchmark(null))
                {
                    Root R1;
                    R1 = BinaryFormat(Filename, R);
//                    Console.WriteLine(((Node)R1.List[2]).bogus);
                    Debug.Assert(R.Equals(R1));
                    Debug.Assert(Object.ReferenceEquals(R.StringA, R.StringB));
                    Debug.Assert(Object.ReferenceEquals(R1.StringA, R1.StringB));
                    Debug.Assert(Object.ReferenceEquals(R.ArrayA, R.ArrayB));
                    Debug.Assert(Object.ReferenceEquals(R1.ArrayA, R1.ArrayB));
//                    Debug.Assert(R.Hash == R.Hash2);
//                    Debug.Assert(R1.Hash == R1.Hash2);
                    Console.WriteLine("BinaryFormat: ListTest == {0}", R1.ListTest());
                    Console.WriteLine("Binary file size = {0}\n", new FileInfo(Filename).Length);

                    R1 = SoapFormat(Filename, R);
                    Debug.Assert(R.Equals(R1));
//                    Console.WriteLine(File.ReadAll(Filename));
//                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine("SoapFormat: ListTest == {0}", R1.ListTest());
                    Console.WriteLine("SOAP file size = {0}\n", new FileInfo(Filename).Length);

                    R.BreakCycle(); // XmlSerializer can't handle cyclic references!
                    R1 = XmlFormat(Filename, R);
                    Debug.Assert(R.Equals(R1));
                    Debug.Assert(Object.ReferenceEquals(R.StringA, R.StringB));
                    Debug.Assert(!Object.ReferenceEquals(R1.StringA, R1.StringB));
                    Debug.Assert(Object.ReferenceEquals(R.ArrayA, R.ArrayB));
                    Debug.Assert(!Object.ReferenceEquals(R1.ArrayA, R1.ArrayB));
//                    Debug.Assert(R.Hash == R.Hash2);
//                    Debug.Assert(R1.Hash != R1.Hash2);
//                    Console.WriteLine(File.ReadAll(Filename));
                    Console.WriteLine("XmlFormat: ListTest == {0}", R1.ListTest());
                    Console.WriteLine("XML file size = {0}\n", new FileInfo(Filename).Length);
                    R.JoinCycle();

//                    R1 = SoapXml(Filename, R);
//                    Debug.Assert(R.Equals(R1));
////                    Console.WriteLine(File.ReadAll(Filename));
//                    Console.WriteLine("SOAP/XML Binary file size = {0}", new FileInfo(Filename).Length);

                }

                using (new Benchmark("BinaryFormatter"))
                    BinaryFormat(Filename, R);
                using (new Benchmark("SoapFormatter"))
                    SoapFormat(Filename, R);
                R.BreakCycle(); // XmlSerializer can't handle cyclic references!
                using (new Benchmark("XmlSerializer"))
                    XmlFormat(Filename, R);
//                using (new Benchmark("SOAP/XmlSerializer"))
//                    SoapXml(Filename, R);
            }
            finally
            {
                File.Delete(Filename);
            }

            Console.ReadLine();
        }

        static Root BinaryFormat(string Filename, Root R)
        {
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                BinaryFormatter Serializer = new BinaryFormatter();
                Serializer.Serialize(Write, R);
            }

            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                BinaryFormatter Serializer = new BinaryFormatter();
                return (Root)Serializer.Deserialize(Read);
            }
        }

        static Root SoapFormat(string Filename, Root R)
        {
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                SoapFormatter Serializer = new SoapFormatter();
                Serializer.Serialize(Write, R);
            }

            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                SoapFormatter Serializer = new SoapFormatter();
                return (Root)Serializer.Deserialize(Read);
            }
        }

        static Root XmlFormat(string Filename, Root R)
        {
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                XmlSerializer Serializer = new XmlSerializer(typeof(Root), new Type[] { typeof(Node), typeof(Latebound) });
                Serializer.Serialize(Write, R);
            }

            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                XmlSerializer Serializer = new XmlSerializer(typeof(Root), new Type[] { typeof(Node), typeof(Latebound) });
                return (Root)Serializer.Deserialize(Read);
            }
        }

        static Root SoapXml(string Filename, Root R)
        {
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                XmlTypeMapping Mapping = new SoapReflectionImporter().
                    ImportTypeMapping(typeof(Root));
                XmlSerializer Serializer = new XmlSerializer(Mapping);
                // throws an InvalidOperationException: "XML fragments cannot be saved to this writer unless it was created with a ConformanceLevel set to Fragment. Token StartElement in state EndRootElement would result in an invalid XML document."
                Serializer.Serialize(Write, R);
            }

            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                XmlTypeMapping Mapping = new SoapReflectionImporter().
                    ImportTypeMapping(typeof(Root));
                XmlSerializer Serializer = new XmlSerializer(Mapping);
                return (Root)Serializer.Deserialize(Read);
            }
        }
    }

    [Serializable]
    public class Root //: IDeserializationCallback
    {
        private int nine = 9;
        public int Nine { get { return nine; } set { nine = value; } }

        public ArrayList List = new ArrayList();

//        public Hashtable Hash = new Hashtable();
//        public Hashtable Hash2;

        public string StringA = "this is a string";
        public string StringB;

//        [NonSerialized]
        public object ObjectA;

        public int[] ArrayA = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        public int[] ArrayB;

        public void Populate()
        {
            StringB = StringA; // the same string
            ArrayB = ArrayA; // the same array

            ObjectA = new Latebound();

//            // populate the Hashtable-s
//            for (int I = 0; I < 100; I++)
//                Hash[I.ToString()] = I;
//            Hash2 = Hash;

            // Create a circular list
            Node C = new Node("C");
            Node B = new Node("B", C);
            Node A = new Node("A", B);
            C.Next = A;

            // populate the List member
            List.Add("this is a string");
            List.Add(42);
            List.AddRange(new Node[] { A, B, C });
        }

        public override bool Equals(object obj)
        {
            Root R = obj as Root;
            if (R == null)
                throw new NotImplementedException();

            // Simple field matches?
            if (Nine != R.Nine || List.Count != R.List.Count)
                return false;
//            if (Hash.Count != R.Hash.Count)
//                return false;

//            // Check the hash tables
//            foreach (object Key in Hash.Keys)
//            {
//                if (!R.Hash.ContainsKey(Key))
//                    return false;
//                object V = Hash[Key], V1 = R.Hash[Key];
//                if ((V == null) != (V1 == null))
//                    return false;
//                if (V != null && !V.Equals(V1))
//                    return false;
//            }
            
            // Check the lists
            for (int I = 0; I < List.Count; I++)
                if (! List[I].Equals(R.List[I]))
                    return false;

            // OK
            return true;
        }

        public bool ListTest()
        {
            Node A = (Node)List[2];
            Node B = (Node)List[3];
            return A.Next == B;
        }

        public void BreakCycle()
        {
            Node A = (Node)List[2];
            A.Next = null;
        }

        public void JoinCycle()
        {
            Node A = (Node)List[2];
            Node C = (Node)List[4];
            A.Next = C;
        }

        #region IDeserializationCallback Members

        public void OnDeserialization(object sender)
        {
            Console.WriteLine("Root.OnDeserialization");
        }

        #endregion
    }

    [Serializable]
    public class Node //: IDeserializationCallback
    {
        public string Text;
        public Node Next;

        [NonSerialized]
        public int bogus = -1;

        public Node()
        {
//            Console.WriteLine("new Node()");
        }

        public Node(string Text): this(Text, null) { }

        public Node(string Text, Node Next): this()
        {
            this.Text = Text;
            this.Next = Next;
        }

        public override bool Equals(object obj)
        {
            Node N = obj as Node;
            if (N == null)
                throw new NotImplementedException();
            bool NextMatch;
            if (Next == null && N.Next == null)
                NextMatch = true;
            else
            {
                if ((Next == null) != (N.Next == null))
                    NextMatch = false;
                else
                    NextMatch = Next.Text == N.Next.Text;
            }
            return (Text == N.Text) & NextMatch;
        }

        #region IDeserializationCallback Members

        public void OnDeserialization(object sender)
        {
            Console.WriteLine("Node.OnDeserialization");
        }

        #endregion
    }

    [Serializable]
    public class Latebound
{
    public int NumberNine = 9;
}
}
