// <copyright file="XmlSerializationTest.cs" company="MetaPropeller" author="Vladimir Klisic">
//
// Copyright 2005 Vladimir Klisic
// mailto:vladimir.klisic@free.fr
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any
// damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute
// it freely, subject to the following restrictions:
//
//  1. The origin of this software must not be misrepresented; you must
//     not claim that you wrote the original software. If you use this
//     software in a product, an acknowledgment in the product documentation
//     would be appreciated but is not required.
//  2. Altered source versions must be plainly marked as such, and must
//     not be misrepresented as being the original software.
//  3. This notice may not be removed or altered from any source distribution.
//
// </copyright>
//
// <history>
//  <change who=�Vladimir Klisic� date=�2005.03.15�>Initial version</change>
//  <change who=�Hallvard Vassbotn� date=�2005.05.25�>
// 	  Replaced Hashtable with IDictionary to make it more generally useful
// 	  Moved code to separate .cs file from the test code
//	  Changed the namespace to Shemitz.Collections
// </change>
// <history>

using System;
using System.Collections;

namespace Shemitz.Collections
{
	/// <summary>
	/// A wrapper for any IDictionary instance to make it XMLSerializable
	/// It implements ICollection in a way the XMLSerilizer expects with
	/// type safe Add function and default property.
	/// </summary>
	public class XMLSerializableDictionary : ICollection
	{
		private IDictionary _dictionary;
		private IDictionaryEnumerator _enumerator = null;
		private int _position = -1;

		public XMLSerializableDictionary(IDictionary dictionary)
		{
			_dictionary = dictionary;
			_position = -1;
		}
		// Serialization: XmlSerializer uses this one to get one item at the time
		public DictionaryEntry this[int index]
		{
		get
		{
				if (_enumerator == null)  // lazy initialization
					_enumerator = _dictionary.GetEnumerator();

				// Accessing an item that is before the current position is something that
				// shouldn't normally happen because XmlSerializer calls indexer with a constantly
				// increasing index that starts from zero.
				// Trying to go backward requires the reset of the enumerator, followed by appropriate
				// number of increments. (Enumerator acts as a forward-only iterator.)
				if (index < _position)
				{
					_enumerator.Reset();
					_position = -1;
		}

				while (_position < index)
				{
					_enumerator.MoveNext();
					_position++;
				}
				return _enumerator.Entry;
			}
		}
		// Deserialization: XmlSerializer uses this one to write content back
		public void Add(DictionaryEntry de)
		{
			_dictionary[de.Key] = de.Value;
		}

		// The rest is a simple redirection to dictionary's ICollection implementation
		public int Count { get { return _dictionary.Count; } }
		public bool IsSynchronized { get { return _dictionary.IsSynchronized; } }
		public object SyncRoot { get { return _dictionary.SyncRoot; } }
		public void CopyTo(Array array, int index) { _dictionary.CopyTo(array, index); }
		public IEnumerator GetEnumerator() { return _dictionary.GetEnumerator(); }
	}
}
