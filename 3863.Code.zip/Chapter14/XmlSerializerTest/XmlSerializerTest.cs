// <copyright file="XmlSerializationTest.cs" company="MetaPropeller" author="Vladimir Klisic">
//
// Copyright 2005 Vladimir Klisic
// mailto:vladimir.klisic@free.fr
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any
// damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute
// it freely, subject to the following restrictions:
//
//  1. The origin of this software must not be misrepresented; you must
//     not claim that you wrote the original software. If you use this
//     software in a product, an acknowledgment in the product documentation
//     would be appreciated but is not required.
//  2. Altered source versions must be plainly marked as such, and must
//     not be misrepresented as being the original software.
//  3. This notice may not be removed or altered from any source distribution.
//
// </copyright>
//
// <history>
//  <change who=�Vladimir Klisic� date=�2005.03.15�>Initial version</change>
//  <change who=�Hallvard Vassbotn� date=�2005.05.25�>Moved wrapper class to XMLSerializableDictionary.cs</change>
// <history>

using System;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Shemitz.Collections;

namespace XmlSerializerTest
{

  public class MyType
  {
	// This one can't be serialized
	private Hashtable _items = new Hashtable();
	// But this one can
    public XMLSerializableDictionary _hashtableSerializationProxy;

    public MyType()
    {
      // First add some items
      _items["1"] = "one";
			_items["2"] = "two";
			_items["3"] = "three";

      // Alternatively, hashtable can be assigned at some later time (not implemented
			// in this sample)
			_hashtableSerializationProxy = new XMLSerializableDictionary(_items);
    }
  }

  class EntryPoint
  {
    [STAThread]
    static void Main(string[] args)
    {
      // Note: try/catch/finally blocks omitted for clarity

      MyType myType = new MyType(); // contains three items

			// Serialize
			XmlSerializer xs = new XmlSerializer(typeof(XmlSerializerTest.MyType));

      String xmlFile = Path.GetTempFileName();
			using (TextWriter w = new StreamWriter(xmlFile, false))
			{
        xs.Serialize(w, myType);
      }

      // Deserialize
      MyType myType2 = null;
      using (TextReader r = new StreamReader(xmlFile)) 
      {
        myType2 = (MyType) xs.Deserialize(r);
      }

      File.Delete(xmlFile);
    }
	}
}
