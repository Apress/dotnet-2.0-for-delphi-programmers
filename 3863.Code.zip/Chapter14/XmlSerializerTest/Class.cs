using System;
using System.Collections;

namespace Shemitz.Collections
{
	/// <summary>
	/// Summary description for Class.
	/// </summary>
	public class DictionarySerializationProxy : ICollection
	{
	private IDictionary _dictionary;
	private IDictionaryEnumerator _enumerator = null;
	private int _position = -1;

	public DictionarySerializationProxy(IDictionary dictionary)
	{
		_dictionary = dictionary;
		_position = -1;
	}
	// Serialization: XmlSerializer uses this one to get one item at the time
	public DictionaryEntry this[int index]
	{
		get
		{
		if (_enumerator == null)  // lazy initialization
			_enumerator = _dictionary.GetEnumerator();

		// Accessing an item that is before the current position is something that
		// shouldn't normally happen because XmlSerializer calls indexer with a constantly
				// increasing index that starts from zero.
				// Trying to go backward requires the reset of the enumerator, followed by appropriate
				// number of increments. (Enumerator acts as a forward-only iterator.)
				if (index < _position)
				{
					_enumerator.Reset();
					_position = -1;
		}

        while (_position < index)
        {
          _enumerator.MoveNext();
          _position++;
        }
        return _enumerator.Entry;
      }
    }
    // Deserialization: XmlSerializer uses this one to write content back
    public void Add(DictionaryEntry de) 
    {
      _dictionary[de.Key] = de.Value;
    }
    
    // The rest is a simple redirection to dictionary's ICollection implementation
    public int Count { get { return _dictionary.Count; } }
    public bool IsSynchronized { get { return _dictionary.IsSynchronized; } }
    public object SyncRoot { get { return _dictionary.SyncRoot; } }
    public void CopyTo(Array array, int index) { _dictionary.CopyTo(array, index); }
    public IEnumerator GetEnumerator() { return _dictionary.GetEnumerator(); }
  }
}
