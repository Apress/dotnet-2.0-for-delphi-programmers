namespace Chatlet
{
    partial class ChatletForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChatletForm));
            this.MachineNames = new System.Windows.Forms.ComboBox();
            this.MachineNamesLabel = new System.Windows.Forms.Label();
            this.MachinePanel = new System.Windows.Forms.Panel();
            this.DisconnectButton = new System.Windows.Forms.Button();
            this.StatusLabel = new System.Windows.Forms.Label();
            this.TypingBox = new System.Windows.Forms.TextBox();
            this.RTF = new System.Windows.Forms.RichTextBox();
            this.MachinePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MachineNames
            // 
            this.MachineNames.FormattingEnabled = true;
            this.MachineNames.Location = new System.Drawing.Point(142, 3);
            this.MachineNames.Name = "MachineNames";
            this.MachineNames.Size = new System.Drawing.Size(140, 21);
            this.MachineNames.TabIndex = 0;
            this.MachineNames.SelectedIndexChanged += new System.EventHandler(this.MachineNames_SelectedIndexChanged);
            // 
            // MachineNamesLabel
            // 
            this.MachineNamesLabel.Location = new System.Drawing.Point(3, 6);
            this.MachineNamesLabel.Name = "MachineNamesLabel";
            this.MachineNamesLabel.Size = new System.Drawing.Size(111, 18);
            this.MachineNamesLabel.TabIndex = 1;
            this.MachineNamesLabel.Text = "Available &Machines";
            this.MachineNamesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MachinePanel
            // 
            this.MachinePanel.BackColor = System.Drawing.Color.White;
            this.MachinePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MachinePanel.Controls.Add(this.DisconnectButton);
            this.MachinePanel.Controls.Add(this.StatusLabel);
            this.MachinePanel.Controls.Add(this.MachineNamesLabel);
            this.MachinePanel.Controls.Add(this.MachineNames);
            this.MachinePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.MachinePanel.Location = new System.Drawing.Point(0, 0);
            this.MachinePanel.Name = "MachinePanel";
            this.MachinePanel.Size = new System.Drawing.Size(518, 28);
            this.MachinePanel.TabIndex = 2;
            // 
            // DisconnectButton
            // 
            this.DisconnectButton.Enabled = false;
            this.DisconnectButton.Location = new System.Drawing.Point(430, 1);
            this.DisconnectButton.Name = "DisconnectButton";
            this.DisconnectButton.Size = new System.Drawing.Size(75, 23);
            this.DisconnectButton.TabIndex = 3;
            this.DisconnectButton.Text = "Disconnect";
            this.DisconnectButton.Click += new System.EventHandler(this.DisconnectButton_Click);
            // 
            // StatusLabel
            // 
            this.StatusLabel.AutoSize = true;
            this.StatusLabel.ForeColor = System.Drawing.Color.Red;
            this.StatusLabel.Location = new System.Drawing.Point(300, 7);
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(74, 13);
            this.StatusLabel.TabIndex = 2;
            this.StatusLabel.Text = "Not connected";
            // 
            // TypingBox
            // 
            this.TypingBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypingBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.TypingBox.Enabled = false;
            this.TypingBox.Location = new System.Drawing.Point(0, 246);
            this.TypingBox.Name = "TypingBox";
            this.TypingBox.Size = new System.Drawing.Size(518, 20);
            this.TypingBox.TabIndex = 3;
            this.TypingBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TypingBox_KeyPress);
            // 
            // RTF
            // 
            this.RTF.BackColor = System.Drawing.Color.White;
            this.RTF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RTF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RTF.Location = new System.Drawing.Point(0, 28);
            this.RTF.Name = "RTF";
            this.RTF.ReadOnly = true;
            this.RTF.Size = new System.Drawing.Size(518, 218);
            this.RTF.TabIndex = 4;
            this.RTF.Text = "";
            // 
            // ChatletForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 266);
            this.Controls.Add(this.RTF);
            this.Controls.Add(this.TypingBox);
            this.Controls.Add(this.MachinePanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChatletForm";
            this.Text = "Chatlet";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChatletForm_FormClosing);
            this.MachinePanel.ResumeLayout(false);
            this.MachinePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox MachineNames;
        private System.Windows.Forms.Label MachineNamesLabel;
        private System.Windows.Forms.Panel MachinePanel;
        private System.Windows.Forms.RichTextBox RTF;
        private System.Windows.Forms.Label StatusLabel;
        private System.Windows.Forms.Button DisconnectButton;
        internal System.Windows.Forms.TextBox TypingBox;

    }
}

