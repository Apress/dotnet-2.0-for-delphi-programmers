using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels.Http;

namespace Chatlet
{
    public partial class ChatletForm : Form
    {
        public ChatletForm()
        {
            InitializeComponent();

            Debug.Assert(Instance == null);
            Instance = this;
        }

        /// <summary>
        /// Let Remote class put data on the form
        /// </summary>
        internal static ChatletForm Instance;

        private const int Port = 0x1226; // Port numbers must be >= ushort.MinValue and <= ushort.MaxValue
        private const string URI = "Chatlet.message.object";

        private Remote RemoteInstance;

        #region Load

        private void Form1_Load(object sender, EventArgs e)
        {
            MachineNames.Items.AddRange(GetMachineNames());
            RegisterAsServer();

            //System.Threading.Thread GuiThread = System.Threading.Thread.CurrentThread;
            //RTF.Text = String.Format("GUI Thread = {0}, ApartmentState = {1}\n",
            //    GuiThread.ManagedThreadId, GuiThread.GetApartmentState());
        }

        #region GetMachineNames

        private string[] GetMachineNames()
        {
            string MachineName = Environment.MachineName;

            List<string> Result = new List<string>();
            foreach (Match Machine in Regex.Matches(GetNetView(), @"\\\\(\S+)\s"))
            {
                string NetworkName = Machine.Groups[1].Value;
                if (string.Compare(MachineName, NetworkName, true) != 0)
                    Result.Add(NetworkName);
            }
            
            return Result.ToArray();
        }

        private string GetNetView()
        {
            Process NetView = new Process();
            NetView.StartInfo.UseShellExecute = false;
            NetView.StartInfo.RedirectStandardOutput = true;
            NetView.StartInfo.FileName = "net";
            NetView.StartInfo.Arguments = "view";
            NetView.Start();
            return NetView.StandardOutput.ReadToEnd();
        }

        #endregion GetMachineNames

        private void RegisterAsServer()
        {
            TcpChannel Channel = new TcpChannel(Port);
            ChannelServices.RegisterChannel(Channel);
            RemotingConfiguration.RegisterWellKnownServiceType(
                typeof(Remote), 
                URI,
                WellKnownObjectMode.Singleton);
            RemotingConfiguration.CustomErrorsMode = CustomErrorsModes.Off;
        }

        #endregion Load

        #region Connect

        private bool VisualConnectionMode
        {
            get
            {   return _VisualConnectionMode;  }
            set
            {
                _VisualConnectionMode = value;
                MachineNames.Enabled = !value;
                TypingBox.Enabled = value;
                DisconnectButton.Enabled = value;
                if (value)
                    TypingBox.Focus();
            }
        }
        private bool _VisualConnectionMode = false;

        private Remote CreateObjectOn(object MachineName)
        {
            string Request = String.Format("tcp://{0}:{1}/{2}", MachineName, Port, URI);
            return (Remote) Activator.GetObject(typeof(Remote), Request);
        }

        private void MachineNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MachineNames.SelectedIndex >= 0)
            {
                object OtherMachine = MachineNames.Items[MachineNames.SelectedIndex];

                RemoteInstance = CreateObjectOn(OtherMachine);
                string OtherMachineName;
                try
                {
                    //TODO: There MUST be a way to set the timeout behavior?
                    OtherMachineName = RemoteInstance.MachineName; // (try to) talk to the other machine within the exception block
                }
                catch (/*System.Net.Sockets.Socket*/Exception E)
                {
                    AddLine(E.Message, Color.Purple);
                    MachineNames.SelectedIndex = -1;
                    RemoteInstance = null; // should be, anyway
                    return;
                }
                StatusLabel.Text = "Connected to " + OtherMachineName; //OtherMachine.ToString();
                StatusLabel.ForeColor = Color.Blue;

                AddLine("Connected to " + OtherMachineName /*RemoteInstance.MachineName*/, Color.Red);

                VisualConnectionMode = true;

                // Tell the remote machine to connect back to me - calls ConnectBackTo, on the remote machine
                RemoteInstance.ConnectToClient(Environment.MachineName);
            }
        }

        /// <summary>
        /// Called from Remote.ConnectToClient:
        /// remote machine has a client relationship with me, 
        /// now I need to establish a client relationship with the remote machine
        /// </summary>
        /// <param name="Name">Remote machine's name</param>
        internal void ConnectBackto(string Name)
        {
            RemoteInstance = CreateObjectOn(Name);
            AddLine("Connected back to " + RemoteInstance.MachineName, Color.Red);

            // ConnectBackFrom has to use InvokeAddline, because ConnectBackto is called while Originating Machine is
            // waiting for ConnectToClient to return
            RemoteInstance.ConnectBackFrom(Environment.MachineName);

            StatusLabel.Text = "Connected to " + Name;
            StatusLabel.ForeColor = Color.Blue;

            VisualConnectionMode = true;
        }

        #endregion Connect

        #region Disconnect

        /// <summary>
        /// Break the connection and reset visuals.
        /// </summary>
        internal void Disconnect()
        {
            RemoteInstance = null;
            VisualConnectionMode = false;
            StatusLabel.Text = "Not connected";
            StatusLabel.ForeColor = Color.Red;
            MachineNames.SelectedIndex = -1;
        }

        private void DisconnectButton_Click(object sender, EventArgs e)
        {
            RemoteInstance.Disconnect();
            Disconnect();
        }

        private void ChatletForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (RemoteInstance != null)
                RemoteInstance.Disconnect();
        }

        #endregion Disconnect

        #region Chat code ...

        internal void AddLine(string Message, Color MessageColor)
        {
            RTF.SelectionStart = RTF.Text.Length;
            RTF.SelectionColor = MessageColor;
            RTF.SelectedText = Message + '\n';
            //RTF.SelectedText = String.Format("({1}) {0}\n", Message, System.Threading.Thread.CurrentThread.ManagedThreadId);
        }

        internal void InvokeAddline(string Message, Color MessageColor)
        {
            RTF.BeginInvoke((MethodInvoker)delegate
            {
                AddLine(Message, MessageColor);
            });
        }

        private void TypingBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                string Line = TypingBox.Text;
                AddLine(Line, Color.Blue);
                RemoteInstance.ShowMessage(Line);
                TypingBox.Text = "";
            }
        }

        #endregion Chat code ...

    }
}