// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Chatlet
{
    /// <summary>
    /// The object that Chatlet instances share with each other
    /// </summary>
    public class Remote : MarshalByRefObject
    {
        /// <summary>
        /// The remote form ... from the proxy's point of view
        /// </summary>
        private ChatletForm Form; 

        public Remote()
        {
            Form = ChatletForm.Instance;
        }

        /// <summary>
        /// The machine that initiated the relationship is now a client to the remote machine's server;
        /// the remote machine must now become a client to the initiating machine.
        /// </summary>
        /// <param name="Name"></param>
        public void ConnectToClient(string Name)
        {
            Form.Invoke((MethodInvoker)delegate {
                // Announce incoming request
                Form.AddLine("Connection request from " + Name, Color.Red);

                // Be a client to the remote machine's server ...
                Form.ConnectBackto(Name);
            });
        }

        /// <summary>
        /// The initiating machine now has a proxy for the remote machine; the remote machine should show this on its form.
        /// </summary>
        /// <param name="Name"></param>
        public void ConnectBackFrom(string Name)
        {
            Form.InvokeAddline("Connect-back from " + Name, Color.Red);
        }

        /// <summary>
        /// Send a chat line to the remote machine.
        /// </summary>
        /// <param name="Message"></param>
        public void ShowMessage(string Message)
        {
            Form.Invoke((MethodInvoker)delegate
            {
                Form.AddLine(Message, Color.Black);

                Form.TypingBox.Focus();
            });
        }

        /// <summary>
        /// Tell the remote machine that I'm hanging up.
        /// </summary>
        public void Disconnect()
        {
            Form.Invoke((MethodInvoker)delegate { 
                Disconnect(); 
            });
        }

        /// <summary>
        /// The remote machine's name
        /// </summary>
        public string MachineName
        {
            get { return Environment.MachineName; }
        }
    }
}