using System;

namespace Library
{
    /// <summary>
    /// The object that Chatlet instances share with each other
    /// </summary>
    public class Message : MarshalByRefObject
    {
        public void ConnectToClient(string Name)
        {
        }

        public void ShowMessage(string Message)
        {
        }
    }
}