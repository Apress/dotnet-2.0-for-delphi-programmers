// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading;

using Shim;

namespace AppDomainDemo
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
            #region callbacks

            using (AutoUnloadDomain FirstCallbackDomain = new AutoUnloadDomain("CALLBACK"))
            {
                FirstCallbackDomain.Domain.DoCallBack((CrossAppDomainDelegate)delegate
                {
                    ShowAssemblies("Assemblies loaded in CALLBACK domain, on entry");
                    Assembly.LoadFrom("EmptyAssembly.dll");
                    ShowAssemblies("Assemblies loaded in CALLBACK domain, after loading EmptyAssembly");
                });
            }

            using (AutoUnloadDomain SecondCallbackDomain = new AutoUnloadDomain("SHIMMED"))
            {
                SecondCallbackDomain.Domain.DoCallBack(Gateway.Shimmed);
            }

            #endregion callback

            #region ExecuteDomain

            using (AutoUnloadDomain ExecuteDomain = new AutoUnloadDomain("EXECUTE"))
            {
                Console.WriteLine("Unloadable .NET application returned {0}",
                    ExecuteDomain.Domain.ExecuteAssembly("UnloadableApp.exe"));
                //new Thread((ThreadStart)delegate
                //{
                //    ExecuteDomain.Domain.ExecuteAssembly("GuiApp.exe");
                //});
                //Console.WriteLine("GuiApp application returned {0}",
                //    ExecuteDomain.Domain.ExecuteAssembly("GuiApp.exe"));
            }
            
            (new Thread((ThreadStart)delegate
            {
                using (AutoUnloadDomain ExecuteDomain = new AutoUnloadDomain("Gui1"))
                {
                    ExecuteDomain.Domain.ExecuteAssembly("GuiApp.exe");
                }
            })).Start();

            (new Thread((ThreadStart)delegate
            {
                using (AutoUnloadDomain ExecuteDomain = new AutoUnloadDomain("Gui2"))
                {
                    ExecuteDomain.Domain.ExecuteAssembly("AnotherGuiApp.exe");
                }
            })).Start();

            (new Thread((ThreadStart)delegate
            {
                using (AutoUnloadDomain ExecuteDomain = new AutoUnloadDomain("Gui3"))
                {
                    ExecuteDomain.Domain.ExecuteAssembly("GuiApp.exe");
                }
            })).Start();
            #endregion ExecuteDomain

            #region Plugin

            using (AutoUnloadDomain ProxyDomain = new AutoUnloadDomain("PLUGIN"))
            {
                Gateway Proxy = (Gateway)ProxyDomain.Domain.CreateInstanceAndUnwrap("Shim", "Shim.Gateway");
                Debug.Assert(Proxy != null);

                ShowAssemblies("Assemblies loaded in the default domain, after creating proxy");
                Console.WriteLine();

                IMatch MatchPluginProxy = Proxy.LoadAndGetIMatchPluginProxy("Plugin.dll");
                if (MatchPluginProxy == null)
                    Console.WriteLine("Load failed");
                else
                {
                    Match M = MatchPluginProxy.MatchThis("Though the tough cough and hiccough, plough them through");
                    if (!M.Success)
                        Console.WriteLine("Match failed");
                    else
                    {
                        Console.WriteLine("Match succeeded at position {0}. ({1} characters - \"{2}\")",
                            M.Index, M.Length, M.Value);

                        Match Next = M.NextMatch();
                        if (!Next.Success)
                            Console.WriteLine("NextMatch failed");
                        else
                            Console.WriteLine("NextMatch succeeded at position {0}. ({1} characters - \"{2}\")",
                                Next.Index, Next.Length, Next.Value);
                    }

                    Proxy.ReportAssemblies("Assemblies loaded in the Plugin AppDomain");
                }

                ShowAssemblies("Assemblies loaded in the default domain, after proxy calls");
            }

            #endregion Plugin

            #region Visual Studio detect/warn

            if (RunningInVisualStudio())
            {
                Console.WriteLine(@"
This project really should not be run within Visual Studio, as the hosting
process seems to adversely affect GUI apps running in AppDomains.

Also, the output can be somewhat easier to read if you run it outside
of Visual Studio, as running a hosted console app loads various 
VisualStudio.HostingProcess and WinForms assemblies that a console app 
doesn�t load when run from, say, Windows Explorer.");
            }

            #endregion Visual Studio detect/warn

            Console.ReadLine();
		}


        private class AutoUnloadDomain : IDisposable
        {
            public AutoUnloadDomain(string Name)
            {
                ShowAssemblies("Assemblies loaded in default domain, before creating {0} domain", Name);
                Domain = AppDomain.CreateDomain(Name);
                this.Name = Name;
            }

            public AppDomain Domain;
            private string Name;

            #region IDisposable Members

            public void Dispose()
            {
                AppDomain.Unload(Domain);
                ShowAssemblies("Assemblies loaded in default domain, after unloading {0} domain", Name);
            }

            #endregion
        }

		static void ShowAssemblies()
		{
			ShowAssemblies(null);
		}

		static void ShowAssemblies(string Tag)
		{
			if (Tag != null)
				Console.WriteLine("\n{0}\n", Tag);
			foreach (Assembly LoadedAssembly in AppDomain.CurrentDomain.GetAssemblies())
				Console.WriteLine("\t{0}", LoadedAssembly.GetName().Name);
		}

        static void ShowAssemblies(string TagPattern, params object[] Elements)
        {
            ShowAssemblies(String.Format(TagPattern, Elements));
        }

        private static bool RunningInVisualStudio()
        {
            foreach (Assembly LoadedAssembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                string Name = LoadedAssembly.GetName().Name;
                if (Regex.IsMatch(Name, "VisualStudio", RegexOptions.IgnoreCase))
                    return true;
            }
            // else
            return false;
        }
    }
}
