// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;

namespace UnloadableApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nAssemblies loaded in the unloadable app's AppDomain\n");

            foreach (Assembly LoadedAssembly in AppDomain.CurrentDomain.GetAssemblies())
                Console.WriteLine("\t{0}", LoadedAssembly.GetName().Name);

            //return 1226;
        }
    }
}
