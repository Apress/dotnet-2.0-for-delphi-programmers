// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace AnotherGuiApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ( new Thread((ThreadStart)delegate
            {
                using (AutoUnloadDomain GUI = new AutoUnloadDomain("launch"))
                {
                    GUI.Domain.ExecuteAssembly("AnotherGuiApp.exe");
                }


            })).Start();
        }

        private class AutoUnloadDomain : IDisposable
        {
            public AutoUnloadDomain(string Name)
            {
                Domain = AppDomain.CreateDomain(Name);
                this.Name = Name;
            }

            public AppDomain Domain;
            private string Name;

            #region IDisposable Members

            public void Dispose()
            {
                AppDomain.Unload(Domain);
            }

            #endregion
        }

    }
}