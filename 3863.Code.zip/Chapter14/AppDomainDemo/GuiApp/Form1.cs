// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GuiApp
{
    public partial class GuiApp : Form
    {
        public GuiApp()
        {
            InitializeComponent();
        }

        private void GuiApp_Load(object sender, EventArgs e)
        {
            //string[] Args = Environment.GetCommandLineArgs();

            //Text = Args[Math.Min(2, Args.Length) - 1];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TopLabel.Text = DateTime.Now.ToString();
        }
    }
}