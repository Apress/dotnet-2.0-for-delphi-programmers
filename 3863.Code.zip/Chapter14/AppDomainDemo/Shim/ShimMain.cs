// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Shim
{
    public interface IMatch
    {
        Match MatchThis(string Target);
    }

	/// <summary>
	/// A class that exists in both the original and new AppDomain.
	/// </summary>
    public class Gateway : MarshalByRefObject
    {
        public IMatch LoadAndGetIMatchPluginProxy(string AssemblyFilename)
        {
            Assembly Dynamic = Assembly.LoadFrom(AssemblyFilename);
            Type TypeofIMatch = typeof(IMatch);
            foreach (Type Exported in Dynamic.GetExportedTypes())
                if (TypeofIMatch.IsAssignableFrom(Exported))
                {
                    ConstructorInfo Constructor = Exported.GetConstructor(Type.EmptyTypes);
                    if (Constructor != null)
                        // Type supports IMatch and has an no-parameter constructor
                        return (IMatch)Constructor.Invoke(null);
                }
            // if no matches
            return null;
        }

        public void ReportAssemblies(string Tag)
        {
            Console.WriteLine("\n{0}\n", Tag);

            foreach (Assembly LoadedAssembly in AppDomain.CurrentDomain.GetAssemblies())
                Console.WriteLine("\t{0}\t{1}", AppDomain.CurrentDomain.FriendlyName, LoadedAssembly.GetName().Name);
            foreach (Assembly LoadedAssembly in AppDomain.CurrentDomain.ReflectionOnlyGetAssemblies())
                Console.WriteLine("\t{0}\t{1}\t(r)", AppDomain.CurrentDomain.FriendlyName, LoadedAssembly.GetName().Name);
        }

        public static void Shimmed()
        {
            Gateway G = new Gateway();
            G.ReportAssemblies("Assemblies loaded in SHIMMED domain, on entry");
            Assembly.LoadFrom("EmptyAssembly.dll");
            G.ReportAssemblies("Assemblies loaded in SHIMMED domain, after loading EmptyAssembly");
        }
    }
}
