﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Soap;

#endregion

namespace XmlSerialization
{
    class Program
    {
        static void Main(string[] args)
        {
            const string Filename = "serialized.txt";

            Data One = new Data();
            using (Stream Write = new FileStream(Filename, FileMode.Create))
            {
                XmlSerializer Serializer = Data.Serializer();
                Serializer.Serialize(Write, One);
            }

            Data OneA;
            using (Stream Read = new FileStream(Filename, FileMode.Open))
            {
                XmlSerializer Serializer = Data.Serializer();
                OneA = (Data)Serializer.Deserialize(Read);
            }

            Console.WriteLine("One: {0}, {1}", One.SerialNumber == OneA.SerialNumber, One.CreationTime == OneA.CreationTime);
            Console.WriteLine("new Data().SerialNumber == {0}", new Data().SerialNumber);
            Console.ReadLine();
        }
    }

    public class Data
    {
        private static int CreatedThisSession = 0;
        public readonly int SerialNumber;
        public DateTime CreationTime;

        public Data()
        {
            SerialNumber = ++CreatedThisSession;
            CreationTime = DateTime.Now;
        }

        public static XmlSerializer Serializer()
        {
            return new XmlSerializer(typeof(Data));
        }
    }
}
