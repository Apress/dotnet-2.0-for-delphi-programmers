// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;
using System.Threading;

namespace LockDemo
{
	/// <summary>
	/// Contains the app entry point
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// create a simple list

			// The list is so huge because Consumer.ThreadProc is so cheap: 
			// it's not very likely to yield between unlocking and relocking, 
			// so without a very large list, only one thread ever gets to consume 
			// items. With a more expensive consumer (ie, one it would make sense
			// to paralellize on a multi-processor machine) a thread would be MUCH
			// more likely to yield between unlocking and relocking.

			int[] Data = new int[2500000];
			for (int I = 0; I < Data.Length; I++)
				Data[I] = I;

			const int ThreadCount = 5;

			// Initialize Consumer objects
			IEnumerator Enumerator = Data.GetEnumerator(); // call it ONCE
			Consumer[] Consumers = new Consumer[ThreadCount];
			for (int I = 0; I < ThreadCount; I++)
				Consumers[I] = new Consumer(Enumerator);

			// Create threads
			Thread[] Threads = new Thread[ThreadCount];
			for (int I = 0; I < ThreadCount; I++)
				Threads[I] = new Thread(Consumers[I].ThreadProc);

			// Start the threads
			foreach (Thread T in Threads)
				T.Start();

			// Wait for the threads to finish
			foreach (Thread T in Threads)
				T.Join();

			// Display the results
			for (int I = 0; I < ThreadCount; I++)
				Consumers[I].Display("Consumer " + I.ToString());

			Console.ReadLine();
		}
	}

	class Consumer
	{
		private IEnumerator Enumerator;
		private  ArrayList List = new ArrayList();

		public Consumer(IEnumerator Enumerator)
		{
			this.Enumerator = Enumerator;
		}

		public ThreadStart ThreadProc
		{
			get	{	return new ThreadStart(threadProc);	}
		}

		public void Display(string Tag)
		{
			Console.WriteLine("{0}: {1} elements", Tag, List.Count);
		}

		private void threadProc()
		{
			object Current;
			do 
			{
				lock (Enumerator)
					Current = Enumerator.MoveNext() ? Enumerator.Current : null;
				if (Current != null)
					List.Add(Current);
			} 
			while (Current != null);
		}
	}
}
