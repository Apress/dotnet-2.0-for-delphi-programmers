// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;
using Shemitz.Utilities;

namespace ForeachAsFor
{
    class Program
    {
        /// <summary>
        /// Implements a foreach loop using a for loop
        /// </summary>
        static void Main(string[] args)
        {
            int[] A = new int[] { 1, 2, 3, 4, 5 };
            int Total = 0;

            for (
                IEnumerator E = A.GetEnumerator(); // init
                E.MoveNext(); // test
                ) // the test advances
            {
                ReadOnly<int> LoopControlVariable = new ReadOnly<int>((int)E.Current);
                {
                    // Loop body
                    Total += LoopControlVariable.Value;
                }
            }

            Console.WriteLine(Total);

            //Total = 0;
            //IEnumerator E1 = A.GetEnumerator();
            //while (E1.MoveNext())
            //{
            //    ReadOnly<int> LoopControlVariable = new ReadOnly<int>((int)E1.Current);
            //    {
            //        // Loop body
            //        Total += LoopControlVariable.Value;
            //    }
            //}

            //Console.WriteLine(Total);
            Console.ReadLine();
        }
    }
}
