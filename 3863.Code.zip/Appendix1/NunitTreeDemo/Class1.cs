// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace NunitTreeDemo
{
    [TestFixture]
    public class Group1
    {
        [Test]
        public void Test1() { string Foo = "foo"; string Bar = "bar"; string foobar = Foo + Bar; Assert.Ignore(); }

        [Test]
        public void Test2() { }
    }

    [TestFixture, Ignore]
    public class Group2
    {
        [Test]
        public void Test1() { }

        [Test]
        public void Test2() { }
    }
}
