// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;
using System.Collections.Generic;

namespace MakeGenericTypeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Type I = typeof(int);
            Console.WriteLine("typeof(int).IsGenericType = {0}\n\ttypeof(int).IsGenericTypeDefinition = {1}, ", 
                I.IsGenericType, I.IsGenericTypeDefinition);

            Type L0 = typeof(List<>);
            Console.WriteLine("typeof(List<>).IsGenericType = {0}\n\ttypeof(List<>).IsGenericTypeDefinition = {1}, ",
                L0.IsGenericType, L0.IsGenericTypeDefinition);
            foreach (Type P in L0.GetGenericArguments())
                Console.WriteLine("{0} - {1}", P, P.IsGenericParameter);

            Type L1 = L0.MakeGenericType(typeof(int));
            Console.WriteLine("typeof(List<int>).IsGenericType = {0}\n\ttypeof(List<int>).IsGenericTypeDefinition = {1}, ",
                L1.IsGenericType, L1.IsGenericTypeDefinition);
            Type L2 = typeof(List<int>);

            Console.WriteLine(L1 == L2);
            Console.WriteLine(L2.GetGenericTypeDefinition() == L0);

            ConstructorInfo C = L1.GetConstructor(Type.EmptyTypes);
            List<int> L = (List<int>)C.Invoke(null);
            L.Add(1);

            Console.WriteLine(L[0]);

            Console.WriteLine(typeof(List<int>).GetGenericTypeDefinition() == typeof(List<>));
            Console.ReadLine();
        }
    }
}
