﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Reflection;
using System.Text;

#endregion

namespace Shemitz.Reflection
{
    /// <summary>
    /// Wraps ConstructorInfo location and invocation in some friendlier syntax.
    /// </summary>
    public class Constructor
    {
        /// <summary>
        /// Wrap a Constructor around a <see cref="ConstructorInfo"/>.
        /// </summary>
        /// <param name="Info">The <see cref="ConstructorInfo"/> to Invoke</param>
        public Constructor(ConstructorInfo Info)
        {
            this.Info = Info;
        }
        private ConstructorInfo Info;

        /// <summary>
        /// Find a constructor by prototype
        /// </summary>
        /// <param name="T">The type to construct</param>
        /// <param name="Parameters">Optional prototype</param>
        public Constructor(Type T, params Type[] Parameters) : 
            this(T.GetConstructor(Parameters ?? Type.EmptyTypes))
        {}

        /// <summary>
        /// Invoke, with optional parameters
        /// </summary>
        /// <param name="Parameters">Optional parameters</param>
        /// <returns><see cref="object"/>, which must be cast to right type</returns>
        public object Invoke(params object[] Parameters)
        {
            return Info.Invoke(Parameters);
        }
    }

    /// <summary>
    /// Wraps MethodInfo location and invocation in some friendlier syntax.
    /// </summary>
    public class Wrappers
    {
        /// <summary>
        /// Wrap a Method around a <see cref="MethodInfo"/>.
        /// </summary>
        /// <param name="Info">The <see cref="MethodInfo"/> to Invoke</param>
        public Wrappers(MethodInfo Info)
        {
            this.Info = Info;
        }
        private MethodInfo Info;

        /// <summary>
        /// Find a Method by name.
        /// </summary>
        /// <param name="T">The type that has the method</param>
        /// <param name="Name">The methods name</param>
        public Wrappers(Type T, string Name) : this(T.GetMethod(Name)) { }

        /// <summary>
        /// Find a Method by name and prototype.
        /// </summary>
        /// <param name="T">The type that has the method</param>
        /// <param name="Name">The methods name</param>
        /// <param name="Parameters">Parameter types</param>
        public Wrappers(Type T, string Name, params Type[] Parameters) : 
            this(T.GetMethod(Name, Parameters ?? Type.EmptyTypes))
        // Calling new Wrappers(Type, string) will call the explicit (Type, string) overload - I only 
        // default Parameters so you can call (Type, string, null) instead of (Type, string, Type.EmptyTypes)
        { }

        /// <summary>
        /// Invoke an instance method, with parameters
        /// </summary>
        /// <param name="Instance"></param>
        /// <param name="Parameters"></param>
        public object Invoke(object Instance, params object[] Parameters)
        {
            return Info.Invoke(Instance, Parameters);
        }

        /// <summary>
        /// Invoke an instance method, without parameters
        /// </summary>
        /// <param name="Instance"></param>
        public object Invoke(object Instance)
        {
            return Info.Invoke(Instance, null);
        }

        /// <summary>
        /// Invoke a static method, with parameters
        /// </summary>
        /// <param name="Parameters"></param>
        public object StaticInvoke(params object[] Parameters)
        {
            return Info.Invoke(null, Parameters);
        }

        /// <summary>
        /// Invoke a static method, without parameters
        /// </summary>
        public object StaticInvoke()
        {
            return Info.Invoke(null, null);
        }

        /// <summary>
        /// Access to the wrapped MethodInfo
        /// </summary>
        public MethodInfo MethodInfo
        {
            get { return Info; }
        }
    }
}
