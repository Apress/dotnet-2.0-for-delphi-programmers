﻿namespace ManifestResources
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PictureCaption = new System.Windows.Forms.Label();
            this.Image = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Image)).BeginInit();
            this.SuspendLayout();
// 
// PictureCaption
// 
            this.PictureCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.PictureCaption.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PictureCaption.Location = new System.Drawing.Point(0, 0);
            this.PictureCaption.Name = "PictureCaption";
            this.PictureCaption.Size = new System.Drawing.Size(413, 18);
            this.PictureCaption.TabIndex = 0;
            this.PictureCaption.Text = "This will be set at runtime, from the Caption resource";
            this.PictureCaption.TextAlign = System.Drawing.ContentAlignment.TopCenter;
// 
// Image
// 
            this.Image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Image.Location = new System.Drawing.Point(0, 18);
            this.Image.Name = "Image";
            this.Image.Size = new System.Drawing.Size(413, 472);
            this.Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Image.TabIndex = 1;
            this.Image.TabStop = false;
// 
// Form1
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(413, 490);
            this.Controls.Add(this.Image);
            this.Controls.Add(this.PictureCaption);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Embedded Resources";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Image)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label PictureCaption;
        private System.Windows.Forms.PictureBox Image;
    }
}

