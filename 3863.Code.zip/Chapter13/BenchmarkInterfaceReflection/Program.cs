﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Reflection;
using Shemitz.Utilities;

#endregion

namespace BenchmarkInterfaceReflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Type TypeofIFred = typeof(IFred);
            Type TypeofFred = typeof(Fred);

            const int Repetitions = 1000;

            Method ByName = delegate()
            {
                for (int I = 0; I < Repetitions; I++)
                    if (TypeofFred.GetInterface("IFred") == null)
                        throw new NotImplementedException();
            };
            Method ByAssignability = delegate()
            {
                for (int I = 0; I < Repetitions; I++)
                    if (!TypeofIFred.IsAssignableFrom(TypeofFred))
                        throw new NotImplementedException();
            };

            using (new Benchmark(null))
            {
                ByName();
                ByAssignability();
            }

            Benchmark BenchByName, BenchByAssignability;

            using (BenchByName = new Benchmark("By name"))
                ByName();

            using (BenchByAssignability = new Benchmark("By assignability"))
                ByAssignability();

            Console.WriteLine("By name is {0:f2} times slower than by assignment",
                BenchByName.Seconds / BenchByAssignability.Seconds);
        }
    }

    delegate void Method();

    interface IFred
    {
    }

    interface IEthel
    {
    }

    interface ILucy
    {
    }

    interface IRicky
    {
    }

    class Fred : IFred//, IEthel, ILucy, IRicky
    {
    }
}
