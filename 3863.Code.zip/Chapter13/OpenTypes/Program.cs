﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace OpenTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Type OpenList = typeof(List<>);
            Type ClosedList = typeof(List<int>);

            Type OpenDictionary = typeof(Dictionary<,>);
            Type ClosedDictionary = typeof(Dictionary<Type, string>);

            foreach (Type T in new Type[] {OpenList, ClosedList, OpenDictionary, ClosedDictionary})
                Console.WriteLine("{0}: {1}", T.Name, T.ContainsGenericParameters ? "open" : "closed");

            Dictionary<Type, string> TypeNames = (Dictionary<Type, string>)Activator.CreateInstance(ClosedDictionary);
            TypeNames[OpenList] = OpenList.Name;
            Console.WriteLine("\n{0}", TypeNames[OpenList]);
            Console.WriteLine(TypeNames.GetType() == ClosedDictionary);
        }
    }
}
