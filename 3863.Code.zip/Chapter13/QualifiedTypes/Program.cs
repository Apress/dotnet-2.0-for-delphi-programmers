﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace QualifiedTypes
{
    class Base { }
    class Derived : Base { }

    class Program
    {
        static readonly Type ProgramType1 = typeof(Program);
        static readonly Type ProgramType2 = typeof(QualifiedTypes.Program);
        static readonly Type BaseType1 = typeof(Base);
        static readonly Type BaseType2 = typeof(QualifiedTypes.Base);
        static readonly Type DerivedType1 = typeof(Derived);
        static readonly Type DerivedType2 = typeof(QualifiedTypes.Derived);

        static void Main(string[] args)
        {
            bool QualNeutral = (BaseType1 == BaseType2) & (DerivedType1 == DerivedType2);
            bool SameBase = BaseType2 == typeof(Base);
            bool SameDerived = DerivedType1 == typeof(QualifiedTypes.Derived);

            Console.WriteLine("{0}: {1}, {2}", QualNeutral, SameBase, SameDerived);
            Console.WriteLine(BaseType1.IsAssignableFrom(DerivedType1));
            Console.WriteLine(ProgramType1 == ProgramType2); // prints True
        }
    }
}
