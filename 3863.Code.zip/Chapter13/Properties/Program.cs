﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Reflection;
using System.Text;

#endregion

namespace Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Type SimpleType = typeof(Simple);

            PropertyInfo ThisProperty = SimpleType.GetProperty("Item");
            Console.WriteLine(ThisProperty != null);

            ThisProperty = SimpleType.GetProperty("Fred", typeof(int));
            Console.WriteLine(ThisProperty != null);

            ThisProperty = SimpleType.GetProperty("Fred", typeof(string));
            Console.WriteLine(ThisProperty != null);

            ThisProperty = SimpleType.GetProperty("Item", typeof(string));
            Console.WriteLine(ThisProperty != null);

            ThisProperty = SimpleType.GetProperty("Item", new Type[] { typeof(string) });
            Console.WriteLine(ThisProperty != null);

            ThisProperty = SimpleType.GetProperty("Item", typeof(string), new Type[] { typeof(string) });
            Console.WriteLine(ThisProperty != null);
            
            Console.ReadLine();
        }
    }

    class Simple
    {
        public string Fred
        {
            get { return "Fred"; }
        }

//        public int this[int Index]
//        {
//            get { return Index; }
//        }

        public string this[string Index]
        {
            get { return Index; }
        }
    }
}
