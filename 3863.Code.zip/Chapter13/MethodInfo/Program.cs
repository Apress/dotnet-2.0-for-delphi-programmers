﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Security.Permissions;
using System.Reflection;
using Shemitz.Reflection;

#endregion

[assembly: ReflectionPermission(SecurityAction.RequestMinimum, 
    MemberAccess = true, TypeInformation = true)]

namespace Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            Type SimpleType = typeof(Simple);
            Simple SimpleInstance = new Simple();

            MethodInfo OneOverload = SimpleType.GetMethod("OneOverload");
            Console.WriteLine(OneOverload != null);
            if (OneOverload != null)
            {
                Console.WriteLine(OneOverload.ReturnType);
                OneOverload.Invoke(SimpleInstance, null);
            }

            Wrappers OneOverload2 = new Wrappers(SimpleType, "OneOverload");
            OneOverload2.Invoke(SimpleInstance);

            try
            {
                MethodInfo TwoOverloads = SimpleType.GetMethod("TwoOverloads");
                Console.WriteLine("Should never get here!");
//                Console.WriteLine(TwoOverloads != null);
//                if (TwoOverloads != null)
//                    TwoOverloads.Invoke(SimpleInstance, null);
            }
            catch (AmbiguousMatchException)
            {
                Console.WriteLine("SimpleType.GetMethod(\"TwoOverloads\") threw an AmbiguousMatchException");
            }

            MethodInfo NullProc = SimpleType.GetMethod("TwoOverloads", Type.EmptyTypes);
            NullProc.Invoke(null, null);

            Wrappers NullProc2 = new Wrappers(SimpleType, "TwoOverloads", Type.EmptyTypes);
            NullProc2.StaticInvoke();

            Subroutine NullProc3 = (Subroutine)Delegate.CreateDelegate(typeof(Subroutine), NullProc2.MethodInfo);
            NullProc3();

            Constructor SimpleConstructor = new Constructor(SimpleType);
            SimpleInstance = (Simple)SimpleConstructor.Invoke();

            MethodInfo StringFn = SimpleType.GetMethod("TwoOverloads", new Type[] {typeof(string)});
            string S = (string)StringFn.Invoke(SimpleInstance, new object[] { "string value" });
            Console.WriteLine(S);

            Wrappers StringFn2 = new Wrappers(SimpleType, "TwoOverloads", typeof(string));
            Console.WriteLine((string)StringFn2.Invoke(SimpleInstance, "another string value"));

            Console.ReadLine();
        }
    }

    delegate void Subroutine();

    class Simple
    {
        public void OneOverload() 
        { 
            Console.WriteLine("OneOverload"); 
        }

        public static void TwoOverloads() 
        {
            Console.WriteLine("public static void TwoOverloads()");
        }

        public string TwoOverloads(string S) { return S; }
    }
}
