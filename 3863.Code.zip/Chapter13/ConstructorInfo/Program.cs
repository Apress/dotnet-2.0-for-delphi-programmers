﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Reflection;

#endregion

namespace Constructors
{
    class Program
    {
        static void Main(string[] args)
        {
            Type SimpleType = typeof(Simple);

            ConstructorInfo NoParams = SimpleType.GetConstructor(Type.EmptyTypes);
            Simple Default = (Simple)NoParams.Invoke(null);
            Console.WriteLine(Default.Text);

            ConstructorInfo OneString = SimpleType.GetConstructor(new Type[] { typeof(string) });
            Simple Explicit = (Simple)OneString.Invoke(new object[] { "Explicit" });
            Console.WriteLine(Explicit.Text);
        }
    }

    class Simple
    {
        public Simple(): this("default") { }

        public Simple(string Text)
        {
            this.text = Text;
        }

        public string Text
        {
            get { return text; }
        }
        private string text;
    }
}
