// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using Shemitz.Utilities; // Utility code in the ..\..\Common directory

namespace Delegates
{
	interface IEmpty 
	{
		void EmptyCall();
	}
	delegate void EmptyCall();

	interface IPassAlong
	{
		string PassAlong(string S);
	}
	delegate string PassAlong(string S);


	class TestClass: IEmpty, IPassAlong
	{
		const int Repetitions = 10000;
		const string TestString = "Test string";

		[STAThread]
		static void Main(string[] args)
		{
			using (new Benchmark("JIT benchmark code"))
			{
			}
			using (new Benchmark("Empty benchmark"))
			{
			}
			Console.WriteLine();

			TestClass Instance = new TestClass();
			IEmpty TestInterface1 = Instance;
			EmptyCall TestDelegate1 = new EmptyCall(Instance.EmptyCall);

			// jit it
			TestInterface1.EmptyCall();
			TestDelegate1();

			using (new Benchmark("TestInterface.EmptyCall"))
			{
				for (int I = 0; I < Repetitions; I++)
					TestInterface1.EmptyCall();
			}
			using (new Benchmark(" TestDelegate.EmptyCall"))
			{
				for (int I = 0; I < Repetitions; I++)
					TestDelegate1();
			}

			Console.WriteLine();

			IPassAlong TestInterface2 = Instance;
			PassAlong TestDelegate2 = new PassAlong(Instance.PassAlong);

			// jit it
			TestInterface2.PassAlong(TestString);
			TestDelegate2(TestString);

			using (new Benchmark("TestInterface.PassAlong"))
			{
				for (int I = 0; I < Repetitions; I++)
					TestInterface2.PassAlong(TestString);
			}
			using (new Benchmark(" TestDelegate.PassAlong"))
			{
				for (int I = 0; I < Repetitions; I++)
					TestDelegate2(TestString);
			}


			Console.ReadLine();
		}

		public void EmptyCall() {}

		public string PassAlong(string S)
		{
			return S;
		}

	}
}

