// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

namespace NullableBooleans
{
    static class Program
    {
        static void Main(string[] args)
        {
bool? NullableBool;
bool NormalBool = true;
NullableBool = null;
NullableBool = NormalBool;
NormalBool = (bool) NullableBool;
NullableBool = null;
//NormalBool = (bool)NullableBool;
NormalBool = NormalBool == NullableBool;
NormalBool = NormalBool != NullableBool;

            bool? Foo = true;
            bool T = true, F = false;
            Console.WriteLine(Foo == T);
            Console.WriteLine(Foo == F);
            Console.WriteLine(Foo == null);
            Console.WriteLine();

            T = F;

            int? I = 46, J = 1, sum, N = null;
            Console.WriteLine("I == I = {0}", I == I);
            Console.WriteLine("I == 46 = {0}", I == 46);
            sum = I + J;
            Console.WriteLine("46 + 1 = {0}", State<int>(sum));
            sum = I + N;
            Console.WriteLine("46 + null = {0}", State<int>(sum));
            Console.WriteLine();

            //Console.WriteLine("(I? I = 46) > null: {0}", I > null);


            bool?[] BoolValues = new bool?[] { true, false, null };
            int?[] IntValues = new int?[] { -1, 0, 1, null };
            float?[] FloatValues = new float?[] { 1.2f, 2.3f, null };

            Table<bool>("&", delegate(bool? Left, bool? Right) { return Left & Right; }, BoolValues);
            Table<bool>("|", delegate(bool? Left, bool? Right) { return Left | Right; }, BoolValues);
            Table<bool>("^", delegate(bool? Left, bool? Right) { return Left ^ Right; }, BoolValues);

            Table<bool>("==", delegate(bool? Left, bool? Right) { return Left == Right; }, BoolValues);
            Table<bool>("!=", delegate(bool? Left, bool? Right) { return Left != Right; }, BoolValues);

            Table<int>(">", delegate(int? Left, int? Right) { return Left > Right; }, IntValues);
            Table<int>("<", delegate(int? Left, int? Right) { return Left < Right; }, IntValues);

            Table<float>(">", delegate(float? Left, float? Right) { return Left > Right; }, FloatValues);
            Table<float>("<", delegate(float? Left, float? Right) { return Left < Right; }, FloatValues);

            Console.ReadLine();
        }

        delegate bool? NullableTest<T>(T? Left, T? Right) where T : struct;

        static void Table<T>(string Tag, NullableTest<T> Operator, T?[] Values) where T : struct
        {
            Console.WriteLine("The {0} Table", Tag);

            Console.Write("\t");
            foreach (T? Col in Values)
                Console.Write("{0}\t", State(Col));
            Console.WriteLine();

            foreach (T? Row in Values)
            {
                Console.Write("{0}\t", State(Row));
                foreach (T? Col in Values)
                {
                    Console.Write("{0}\t", State(Operator(Row, Col)));
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        static string State<T>(T? NullableValue) where T : struct
        {
            return NullableValue.HasValue
                ? NullableValue.Value.ToString()
                : "null";
        }

    }
}
