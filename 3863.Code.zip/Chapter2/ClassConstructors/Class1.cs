using System;

// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

namespace ClassConstructors
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			Random R = new Random();
			if (R.Next(100) < 50)
				A.I = 1;
			else
				B.C = 2;
			Console.ReadLine();
		}
	}

	class A
	{
		[Obsolete("foo", false)]
		public static int I = 99;
		static A()
		{
			Console.WriteLine("static A()");
		}
	}

	class B
	{
		public static int C;
		static B()
		{
			Console.WriteLine("static B()");
		}
	}

	class C
	{
		public static int CC;
	}

}
