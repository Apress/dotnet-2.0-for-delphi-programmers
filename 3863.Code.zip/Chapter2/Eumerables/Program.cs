// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;
using System.Reflection;

namespace Eumerables
{
    class Program
    {
        static void Main(string[] args)
        {
            Type Enumerable = typeof(IEnumerable);
            int Enumerables = 0;
            foreach (Assembly A in AppDomain.CurrentDomain.GetAssemblies())
                foreach (Type T in A.GetExportedTypes())
                    if (!T.IsInterface && Enumerable.IsAssignableFrom(T))
                    {
                        Console.WriteLine(T.FullName);
                        Enumerables++;
                    }
            Console.WriteLine("\n{0} types implement IEnumerable", Enumerables);
            Console.ReadLine();
        }
    }
}
