using System;

namespace Consumer
{
	/// <summary>
	/// Summary description for Class2.
	/// </summary>
	class Class2
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
		}
	}
}
