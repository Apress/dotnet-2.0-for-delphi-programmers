using System;
using delphiLayer;

namespace csharpLayer
{
	public class TopClass: MiddleClass
	{
		public TopClass()
		{
			Console.WriteLine("Here we are in the C# layer");
		}

		public int CSharp = 1;
	}
}
