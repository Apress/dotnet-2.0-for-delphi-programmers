using System;
using csharpLayer;

namespace Consumer
{
	class Consumer
	{
		[STAThread]
		static void Main(string[] args)
		{
		  TopClass Instance = new TopClass();
		  Console.WriteLine("Instance.VB = {0}", Instance.VB);
		  Console.WriteLine("Instance.VB = {0}", Instance.Delphi);
		  Console.WriteLine("Instance.VB = {0}", Instance.CSharp);

		  Console.ReadLine();
		}
	}
}
