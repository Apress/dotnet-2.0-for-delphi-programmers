Imports System

namespace vbLayer

    public class BaseClass

    	sub New()
	    	Console.WriteLine("Here we are in the Visual Basic constructor")
    	end sub

	    public VB as integer = -1

    end class

end namespace
