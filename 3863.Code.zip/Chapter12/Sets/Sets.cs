﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections.Generic;
using NUnit.Framework; // http://www.nunit.org/download.html

#endregion

namespace Sets
{
    /// <summary>
    /// A Set can hold any (non-negative) number of items. An item is either in the Set or not; 
    /// multiple additions have no effect. A Set is unordered: enumerating the Keys is not 
    /// guaranteed to be either sorted or in insertion order.
    /// </summary>
    /// <typeparam name="K"></typeparam>
    public class Set<K>
    {
        private Dictionary<K, object> Hash = new Dictionary<K, object>();

        public Set() {}

        public Set(K Key)
        {
            Hash[Key] = null;
        }

        public Set(params K[] Keys)
        {
            foreach (K Key in Keys)
                Hash[Key] = null;
        }

        public bool this[K Key]
        {
            get { return Hash.ContainsKey(Key); }
            set
            {
                if (value)
                    Hash[Key] = null;
                else
                    Hash.Remove(Key);
            }
        }

        public void Add(K Key)
        {
            Hash[Key] = null;
        }

        public void Add(params K[] Keys)
        {
            foreach (K Key in Keys)
                Hash[Key] = null;
        }

        public bool Contains(K Key)
        {
            return Hash.ContainsKey(Key);
        }

        public bool Contains(params K[] Keys)
        {
            foreach (K Key in Keys)
                if (!Hash.ContainsKey(Key))
                    return false;
            return true;
        }

        public ICollection<K> Keys
        { get { return Hash.Keys; } }

        public int Count
        { get { return Hash.Count; } }

        public static Set<K> operator &(Set<K> Left, Set<K> Right)
        {
            Set<K> Result = new Set<K>();

            foreach (K Key in Left.Keys)
                if (Right[Key])
                    Result[Key] = true;

            return Result;
        }

        public static Set<K> operator |(Set<K> Left, Set<K> Right)
        {
            Set<K> Result = new Set<K>();

            foreach (K Key in Left.Keys)
                Result[Key] = true;
            foreach (K Key in Right.Keys)
                Result[Key] = true; // not worth doing the ContainsKey() test

            return Result;
        }

        public static Set<K> operator ^(Set<K> Left, Set<K> Right)
        {
            Set<K> Result = new Set<K>();

            foreach (K Key in Left.Keys)
                if (!Right[Key])
                    Result[Key] = true;
            foreach (K Key in Right.Keys)
                if (!Left[Key])
                    Result[Key] = true;

            return Result;
        }

        public static bool operator ==(Set<K> Left, Set<K> Right)
        {
            foreach (K Key in Left.Keys)
                if (!Right[Key])
                    return false;
            foreach (K Key in Right.Keys)
                if (!Left[Key])
                    return false;
            return true;
        }

        public static bool operator !=(Set<K> Left, Set<K> Right)
        {
            return !(Left == Right);
        }

        public static bool operator >=(Set<K> Left, Set<K> Right)
        {
            // Are all elements in Right also in Left?
            foreach (K Key in Right.Keys)
                if (!Left[Key])
                    return false;
            return true;
        }

        public static bool operator >(Set<K> Left, Set<K> Right)
        {
            return (Left >= Right) && (Left.Count > Right.Count);
        }

        public static bool operator <(Set<K> Left, Set<K> Right)
        {
            return !(Left >= Right);
        }

        public static bool operator <=(Set<K> Left, Set<K> Right)
        {
            return !(Left > Right);
        }

        override public int GetHashCode()
        {
            return Keys.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            Set<K> That = obj as Set<K>;
            if (That != null)
                return this == That;
            else
                throw new NotImplementedException();
        }

        public override string ToString()
        {
            System.Text.StringBuilder Result = new System.Text.StringBuilder("[");
            bool Separate = false;
            foreach (K Key in Keys)
            {
                if (Separate)
                    Result.Append(", ");
                else
                    Separate = true;
                Result.Append(Key);
            }
            Result.Append("]");
            return Result.ToString();
        }

        /// <summary>
        /// Returns a new, empty Set. Returns a new Set every time because this Set is NOT read-only.
        /// </summary>
        /// <value>A new Set with no members</value>
        public static Set<K> Empty
        {   get {   return new Set<K>();    }   }
    }

    [TestFixture]
    public class Tests
    {
        public Tests() { }

        [Test]
        public void Creation()
        {
            Set<int> This = new Set<int>(1, 2, 3, 4, 5, 6, 7, 8, 9);
            Assert.AreEqual(9, This.Count);
        }

        [Test]
        public void Contains()
        {
            Set<int> This = new Set<int>(1, 2, 3, 4, 5, 6, 7, 8, 9);
            Assert.IsTrue(This.Contains(7));
            Assert.IsFalse(This.Contains(77));
            Assert.IsTrue(This.Contains(1, 3, 5, 7));
            Assert.IsFalse(This.Contains(1, 2, 3, 10, 20, 30));
        }

        [Test]
        public void Intersection()
        {
            Set<int> This = new Set<int>(1, 2, 3, 4, 5, 6, 7, 8, 9);
            Set<int> That = new Set<int>(-5, -3, -1, 1, 3, 5, 7, 9);
            Set<int> Result = This & That;
            Assert.AreEqual(5, Result.Count);
            Assert.IsTrue(Result == new Set<int>(9, 7, 5, 3, 1));
        }

        [Test]
        public void Union()
        {
            Set<int> This = new Set<int>(1, 2, 3);
            Set<int> That = new Set<int>(4, 5, 6);
            Set<int> Result = This | That;
            Assert.AreEqual(6, Result.Count);
            Assert.IsTrue(Result == new Set<int>(1, 6, 2, 5, 3, 4, 1, 2, 3, 4, 5, 6));
        }

        [Test]
        public void Xor()
        {
            Set<int> This = new Set<int>(1, 2, 3, 4);
            Set<int> That = new Set<int>(3, 4, 5, 6);
            Set<int> Result = This ^ That;
            Assert.AreEqual(4, Result.Count);
            Assert.IsTrue(Result == new Set<int>(1, 2, 5, 6));
        }

        [Test]
        public void Empty()
        {
            Set<string> Empty = Set<string>.Empty;
            Assert.AreEqual(0, Empty.Count);
            Assert.AreEqual("[]", Empty.ToString());
        }

        [Test]
        public void Comparisons()
        {
            Set<double> This = new Set<double>(1.1, 2.2, 3.3);
            Set<double> That = new Set<double>(1.1, 2.2, 3.3);
            Assert.IsFalse(That != This, That.ToString() + " != " + This.ToString());
            Assert.IsTrue(This >= That, This.ToString() + " >= " + That.ToString());
            Assert.IsFalse(This > That, This.ToString() + " > " + That.ToString());
            This.Add(4.4);
            Assert.IsFalse(That == This, That.ToString() + " == " + This.ToString());
            Assert.IsTrue(That < This, That.ToString() + " < " + This.ToString());
            Assert.IsTrue(That <= This, That.ToString() + " <= " + This.ToString());
        }
    }
}
