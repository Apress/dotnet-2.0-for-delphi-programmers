﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Sets
{
    public class Set<K>: Dictionary<K, object>
    {
        public Set() {}

        public Set(params K[] Keys)
        {
            foreach (K Key in Keys)
                this[Key] = true;
        }

        public new bool this[K Key]
        {
            get { return base.ContainsKey(Key); }
            set { base[Key] = null; }
        }

        public static Set<K> operator &(Set<K> Left, Set<K> Right)
        {
            Set<K> Result = new Set<K>();
            foreach (K Key in Left.Keys)
                if (Right[Key])
                    Result[Key] = true;
            return Result;
        }


    }
}
