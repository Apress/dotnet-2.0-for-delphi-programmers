// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;

namespace Wrong
{
	class Wrong : IEnumerable, IEnumerator
	{
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		private int[] Data = new int[] { 1, 2, 3, 4, 5 };
		private int Pointer = -1;

		public object Current
		{
			get { return Data[Pointer]; }
		}

		public bool MoveNext()
		{
			return ++Pointer < Data.Length;
		}

		public void Reset()
		{
			Pointer = -1;
		}
	}
}
