using System;
using System.Collections;

namespace Wrong
{
	class Wrong : IEnumerable, IEnumerator
	{
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		private int[] Data = new int[] { 1, 2, 3, 4, 5 };
		private int Pointer = -1;

		public object Current
		{
			get { return Data[Pointer]; }
		}

		public bool MoveNext()
		{
			return ++Pointer < Data.Length;
		}

		public void Reset()
		{
			Pointer = -1;
		}
	}
}
