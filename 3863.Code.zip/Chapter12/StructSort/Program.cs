﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using Shemitz.Utilities;

#endregion

namespace StructSort
{
  class Program
  {
    delegate void Method();

    static void Main(string[] args)
    {
      Name[] Names = new Name[Data.Length];
      Method Reset = delegate { Data.CopyTo(Names, 0); };
      Method Show = delegate
      {
        foreach (Name N in Names)
          Console.Write("{0}\t", N);
        Console.WriteLine();
      };
      Method LateBound = delegate { Array.Sort(Names); };
      Method EarlyBound = delegate { Array.Sort<Name>(Names); };

      Reset();
      Show();
      Array.Sort(Names);
      Show();

      Reset();
      Array.Sort<Name>(Names);
      Show();

      Reset();
      Array.Sort<Name>(Names, delegate(Name This, Name That)
      {
          int Last = String.Compare(This.Last, That.Last);
          if (Last != 0)
              return -Last;
          else
              return -String.Compare(This.First, That.First);
      });
      Show();

      Console.WriteLine();

      using (new Benchmark(null))
      {
        Reset();
        EarlyBound();
        Reset();
        LateBound();
      }
      Reset();
      using (new Benchmark("Late bound"))
        LateBound();
      Reset();
      using (new Benchmark("Early bound"))
        EarlyBound();

      Console.ReadLine();
    }

    static Name[] Data = { new Name("Fred", "Opper"), new Name("Tom", "Jones"), new Name("Luke", "Skywalker"), new Name("Bilbo", "Baggins") };
  }

  struct Name : IComparable, IComparable<Name>
  {
    public string First, Last;

    public Name(string First, string Last)
    {
      this.First = First;
      this.Last = Last;
    }

    public override string ToString()
    {
      return First + " " + Last;
    }

    #region IComparable Members

    // This method is not called, because Sort(Names) uses the IComparable<Name> predicate
    public int CompareTo(object obj)
    {
      //throw new Exception("This method is not called, because Sort(Names) uses the IComparable<Name> predicate");

      // Can't use as - Name is a struct
      if (!(obj is Name))
        throw new ArgumentException("Parameter is not a Name");
      Name Other = (Name) obj;
      int CompareLast = Last.CompareTo(Other.Last);
      if (CompareLast != 0)
        return CompareLast;
      else
        return First.CompareTo(Other.First);
    }

    #endregion

    #region IComparable<Name> Members

    public int CompareTo(Name Other)
    {
      int CompareLast = Last.CompareTo(Other.Last);
      if (CompareLast != 0)
        return CompareLast;
      else
        return First.CompareTo(Other.First);
    }

    public bool Equals(Name Other)
    {
      return First == Other.First && Last == Other.Last;
    }

    #endregion
  }
}
