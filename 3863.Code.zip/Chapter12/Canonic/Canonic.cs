﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;

#endregion

namespace Canonic
{
    /// <summary>
    /// Acts like String.Intern(), but interns to a localizable table
    /// </summary>
    public class Interner : Hashtable
    {
        public object Uniquify(object O)
        {
            if (ContainsKey(O))
                return this[O];
            else
                return this[O] = O;
        }

        public string Intern(string S)
        {
            return (string)Uniquify(S);
        }
    }

    /// <summary>
    /// The generic version of the Interner class - less casting.
    /// </summary>
    public class Interner2 : Dictionary<string, string>
    {
        public string Intern(string S)
        {
            if (ContainsKey(S))
                return this[S];
            else
                return this[S] = S;
        }
    }
}
