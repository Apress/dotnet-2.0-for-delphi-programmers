﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Sorted
{
    class Program
    {
        static void Main(string[] args)
        {
            Sortable<int> Data = new Sortable<int>(new int[] { 1, 0, 2, 9, 3, 8, 4, 7, 5, 6 });
            foreach (int I in Data) 
                Console.Write(I);
            Console.WriteLine();
            foreach (int I in Data.Sorted())
                Console.Write(I);
            Console.WriteLine();

            Hashtable Hash = new Hashtable();
            foreach (DictionaryEntry P in Hash) ;
            foreach (int I in Hash.Keys) ;
            foreach (int I in Hash.Values) ;
            Console.ReadLine();
        }
    }

    class Sortable<T> : List<T>
    {
        public Sortable() {}

        public Sortable(IEnumerable<T> List): base(List) {}

        public IEnumerable<T> Sorted()
        {
            return Sorted(null);
        }

public IEnumerable<T> Sorted(Comparison<T> comparison)
{
    List<T> Copy = new List<T>(this);
    if (comparison == null)
        Copy.Sort();
    else
        Copy.Sort(comparison);
    return Copy;
}
    }
}
