﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Shemitz.Utilities;

#endregion

namespace ArraySort
{
  class Program
  {
    delegate void Method();

    const int Repetitions = 100;

    private static void Run(Method Setup, Method M)
    {
      for (int I = 0; I < Repetitions; I++)
      {
        Setup();
        M();
      }
    }

    static void Main(string[] args)
    {
      #region value types
      int[] unsortedIntegers = new int[] { 0, 1, 3, 5, 7, 9, 2, 4, 6, 8 }, Integers = new int[10];
      Method ResetIntegers = delegate { unsortedIntegers.CopyTo(Integers, 0); };

      ResetIntegers();
      Array.Sort<int>(Integers, delegate(int x, int y) { return x - y; });
      Show<int>("inline ascending", Integers);

      ResetIntegers();
      Array.Sort<int>(Integers, delegate(int x, int y) { return y - x; });
      Show<int>("inline descending", Integers);

//      /* any of */
//      Array.Sort(Integers, new DescendingOrder());
//      Show<int>("a", Integers);
//      ResetIntegers();
//      /*   or  */
//      Array.Sort(Integers, new DescendingOrder<int>());
//      Show<int>("b", Integers);
//      ResetIntegers();
//      /*   or  */
//      Array.Sort<int>(Integers, new DescendingOrder<int>());
//      Show<int>("c", Integers);

      ResetIntegers();
      Show<int>("unsorted", Integers);
      Array.Sort(Integers); // ascending order
      Show<int>("heterogeneous sort", Integers);

      ResetIntegers();
      Array.Sort<int>(Integers); // ascending order
      Show<int>("strongly-typed (generic) sort", Integers);

      ResetIntegers();
      Array.Sort(Integers, Unique<DescendingOrder>.Instance); // descending order
      Show<int>("heterogeneous descending order", Integers);

      double[] unsortedDoubles = new double[] { 4.4, 5.5, 6.6, 7.7, 1.1, 2.2, 3.3 }, Doubles = new double[7];
      Method ResetDoubles = delegate { unsortedDoubles.CopyTo(Doubles, 0); };

      ResetDoubles();
      Show<double>("unsorted doubles", Doubles);

      ResetDoubles();
      Array.Sort(Doubles);
      Show<double>("heterogeneous sort", Doubles);

      ResetDoubles();
      Array.Sort(Doubles, Unique<DescendingOrder>.Instance); // descending order
      Show<double>("heterogeneous sort down", Doubles);

      ResetIntegers();
      Array.Sort<int>(Integers, Unique<DescendingOrder<int>>.Instance); // descending order
      Show<int>("strongly-typed (generic) descending order", Integers);
      Console.WriteLine();
      #endregion

      #region strings
      string[] unsortedStrings = new string[] { "Tom", "Dick", "Harry" }, Strings = new string[3];
      Method ResetStrings = delegate { unsortedStrings.CopyTo(Strings, 0); };

      ResetStrings();
      Show<string>("unsorted", Strings);

      ResetStrings();
      Array.Sort(Strings); // ascending order
      Show<string>("heterogeneous sort", Strings);

      ResetStrings();
      Array.Sort(Strings, Unique<DescendingOrder>.Instance);
      Show<string>("heterogeneous descending order", Strings);

      ResetStrings();
      Array.Sort<string>(Strings, Unique<DescendingOrder<string>>.Instance); // descending order
      Show<string>("strongly-typed (generic) descending order", Strings);

      Console.WriteLine();
      #endregion

      #region key/item
      string[] s3 = {"one", "two", "three"};
      int[] i3 = {1, 2, 3, 4, 5, 6};

      Console.WriteLine("string key & int item");
      Array.Sort(s3, i3);
      foreach (string s in s3)
        Console.Write("\t{0}", s);
      Console.WriteLine();
      foreach (int i in i3)
        Console.Write("\t{0}", i);

      Console.WriteLine("\n\nint key & string item");
      Array.Sort(i3, s3, 0, 3);
      foreach (string s in s3)
        Console.Write("\t{0}", s);
      Console.WriteLine();
      foreach (int i in i3)
        Console.Write("\t{0}", i);
      Console.WriteLine('\n');
      #endregion key/item
      
      #region ascending benchmarks
      Method HeterogeneousIntSort = delegate { Array.Sort(Integers); },
          GenericIntSort = delegate { Array.Sort<int>(Integers); },
          HeterogeneousDoubleSort = delegate { Array.Sort(Doubles); },
          GenericDoubleSort = delegate { Array.Sort<double>(Doubles); },
          HeterogeneousStringSort = delegate { Array.Sort(Strings); },
          GenericStringSort = delegate { Array.Sort<string>(Strings); };
      using (new Benchmark(null)) // jit
      {
        Run(ResetIntegers, HeterogeneousIntSort);
        Run(ResetIntegers, GenericIntSort);
        Run(ResetDoubles, HeterogeneousDoubleSort);
        Run(ResetDoubles, GenericDoubleSort);
        Run(ResetStrings, HeterogeneousStringSort);
        Run(ResetStrings, GenericStringSort);
      }
      using (new Benchmark("HeterogeneousIntSort"))
        Run(ResetIntegers, HeterogeneousIntSort);
      using (new Benchmark("GenericIntSort"))
        Run(ResetIntegers, GenericIntSort);
      using (new Benchmark("HeterogeneousDoubleSort"))
        Run(ResetDoubles, HeterogeneousDoubleSort);
      using (new Benchmark("GenericDoubleSort"))
        Run(ResetDoubles, GenericDoubleSort);
      using (new Benchmark("HeterogeneousStringSort"))
        Run(ResetStrings, HeterogeneousStringSort);
      using (new Benchmark("GenericStringSort"))
        Run(ResetStrings, GenericStringSort);

      Console.WriteLine();
      #endregion

      #region descending benchmarks
      Method HeterogeneousIntDown = delegate { Array.Sort(Integers, Unique<DescendingOrder>.Instance); },
MixedIntDown = delegate { Array.Sort(Integers, Unique<DescendingOrder<int>>.Instance); },
GenericIntDown = delegate { Array.Sort<int>(Integers, Unique<DescendingOrder<int>>.Instance); },
HeterogeneousDoubleDown = delegate { Array.Sort(Doubles, Unique<DescendingOrder>.Instance); },
MixedDoubleDown = delegate { Array.Sort<double>(Doubles, Unique<DescendingOrder<double>>.Instance); },
GenericDoubleDown = delegate { Array.Sort<double>(Doubles, Unique<DescendingOrder<double>>.Instance); },
          HeterogeneousStringDown = delegate { Array.Sort(Strings, Unique<DescendingOrder>.Instance); },
          GenericStringDown = delegate { Array.Sort<string>(Strings, Unique<DescendingOrder<string>>.Instance); };
      using (new Benchmark(null)) // jit
      {
        Run(ResetIntegers, HeterogeneousIntDown);
        Run(ResetIntegers, MixedIntDown);
        Run(ResetIntegers, GenericIntDown);
        Run(ResetDoubles, HeterogeneousDoubleDown);
        Run(ResetDoubles, MixedDoubleDown);
        Run(ResetDoubles, GenericDoubleDown);
        Run(ResetStrings, HeterogeneousStringDown);
        Run(ResetStrings, GenericStringDown);
      }
      using (new Benchmark("HeterogeneousIntDown"))
        Run(ResetIntegers, HeterogeneousIntDown);
      using (new Benchmark("MixedIntDown"))
        Run(ResetIntegers, MixedIntDown);
      using (new Benchmark("GenericIntDown"))
        Run(ResetIntegers, GenericIntDown);

      Console.WriteLine();

      using (new Benchmark("HeterogeneousDoubleDown"))
        Run(ResetDoubles, HeterogeneousDoubleDown);
      using (new Benchmark("MixedDoubleDown"))
        Run(ResetDoubles, MixedDoubleDown);
      using (new Benchmark("GenericDoubleDown"))
        Run(ResetDoubles, GenericDoubleDown);

      Console.WriteLine();

      using (new Benchmark("HeterogeneousStringDown"))
        Run(ResetStrings, HeterogeneousStringDown);
      using (new Benchmark("GenericStringDown"))
        Run(ResetStrings, GenericStringDown);
      #endregion
      Console.ReadLine();
    }

    static void Show<T>(string Tag, T[] Items)
    {
      Console.Write("{0}\n\t", Tag);
      foreach (T Item in Items)
        Console.Write("{0} ", Item);
      Console.WriteLine();
    }

    private class DescendingOrder : IComparer
    {
      #region IComparer Members

      public int Compare(object x, object y)
      {
        IComparable Comparable = x as IComparable;
        if (Comparable != null)
          return -Comparable.CompareTo(y);
        throw new ArgumentException(String.Format("Can't compare {0} and {1}", x.GetType(), y.GetType()));
      }

      #endregion
    }

    private class DescendingOrder<T> : IComparer<T> where T : IComparable<T>
    {

      #region IComparer<T> Members

      public int Compare(T x, T y)
      {
        return -x.CompareTo(y);
      }

      public bool Equals(T x, T y)
      {
        return x.Equals(y);
      }

      public int GetHashCode(T obj)
      {
        return obj.GetHashCode();
      }

      #endregion
    }
  }
}
