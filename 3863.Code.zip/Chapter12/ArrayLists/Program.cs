﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Text;

#endregion

namespace ArrayLists
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList List = new ArrayList(new object[] { 1, 2, 3 });
            int[] IntArray = (int[])List.ToArray(typeof(int));
            foreach (int I in IntArray)
                Console.Write("{0}\t", I);
            Console.WriteLine();

            List = new ArrayList(new object[] { 1, "2", 3 });
            IntArray = (int[])List.ToArray(typeof(int));
        }
    }
}
