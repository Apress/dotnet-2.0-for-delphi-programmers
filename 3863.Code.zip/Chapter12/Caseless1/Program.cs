﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Text;

#endregion

namespace Caseless1
{
    class Program
    {
        static void Main(string[] args)
        {
            Caseless Hash = new Caseless();

            Hash["ThIs"] = "This Caseless Hashtable";
            Hash[1] = "can still use non-string keys";
            Console.WriteLine("{0} {1}.", Hash["thiS"], Hash[1]);
            Console.ReadLine();
        }
    }

    class Caseless : Hashtable
    {
        public Caseless(): 
            base(
                new CaseInsensitiveHashCodeProvider(), 
                new CaseInsensitiveComparer() )
        { }
    }

}
