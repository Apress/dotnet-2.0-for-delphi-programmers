﻿#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Pooling
{
    public class Pool<T> where T: class, IEnumerable, new()
    {
        public static IEnumerable Get()
        {
            lock (DeadEnumerators)
                if (DeadEnumerators.Count == 0)
                {
                    Console.WriteLine("Creating a new enumerator");
                    return new Wrapper();
                }
                else
                {
                    Console.WriteLine("Reusing an enumerator");
                    return DeadEnumerators.Pop();
                }
        }

        private static Stack<Wrapper> DeadEnumerators = new Stack<Wrapper>();

        private class Wrapper : IEnumerable, IEnumerator, IDisposable
        {
            private IEnumerator Enumerator = new T().GetEnumerator();

            #region IEnumerable Members

            public IEnumerator GetEnumerator()
            {
                return this;
                /// Normally, it's a very bad thing for GetEnumerator() to return "this" -
                /// it's OK, here, because we can only get Wrapper instances through Pool<>.Get
                /// which is designed to be threadsafe and to ensure that a Wrapper is either new or has been Reset().
            }

            #endregion

            #region IEnumerator Members
            public object Current
            {
                get { return Enumerator.Current; }
            }


            public bool MoveNext()
            {
                return Enumerator.MoveNext();
            }

            public void Reset()
            {
                Enumerator.Reset();
            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {
                Console.WriteLine("\nSaving a dead enumerator");
                Enumerator.Reset();
                lock (DeadEnumerators)
                    DeadEnumerators.Push(this);
            }

            #endregion

        }
    }

    class Enumerable : IEnumerable
    {
        private static int[] Data = new int[] { 1, 2, 3, 4, 5 };

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return Data.GetEnumerator();
        }

        #endregion
    }

    class Program
    {
        const int Repetitions = 5;

        static void Main(string[] args)
        {
            Console.WriteLine("native enumerator");
            foreach (int Item in new Enumerable())
                Console.Write(Item);
            Console.WriteLine('\n');

            Console.WriteLine("pooled enumerator");
            for (int Repetition = 1; Repetition <= Repetitions; Repetition++)
            {
                Console.WriteLine("Pass {0}", Repetition);
                foreach (int Item in Pool<Enumerable>.Get())
                    Console.Write(Item);
                Console.WriteLine();

            }

            Console.ReadLine();
        }
    }
}
