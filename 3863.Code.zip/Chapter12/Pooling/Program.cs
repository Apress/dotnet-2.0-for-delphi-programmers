﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Shemitz.Trace;

#endregion

namespace Pooling
{
    public class Pool<D, E> where E : IEnumerable<D>, new()
    {
        public static IEnumerable<D> Get()
        {
            lock (DeadEnumerators)
                if (DeadEnumerators.Count == 0)
                {
                    Trace.Line("Creating a new enumerator");
                    return new Wrapper();
                }
                else
                {
                    Trace.Line("Reusing an enumerator");

                    Wrapper Enumerator = DeadEnumerators.Pop();
                    
                    Enumerator.Reset();

                    return Enumerator;
                }
        }

        private static Stack<Wrapper> DeadEnumerators = new Stack<Wrapper>();

        private class Wrapper : IEnumerable<D>, IEnumerator<D>, IDisposable
        {
            private IEnumerator<D> Enumerator = new E().GetEnumerator();

            #region IEnumerable Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this;
                /// Normally, it's a very bad thing for GetEnumerator() to return "this" -
                /// it's OK, here, because we can only get Wrapper instances through Pool<>.Get
                /// which is designed to be threadsafe and to ensure that a Wrapper is either new or has been Reset().
            }

            public IEnumerator<D> GetEnumerator()
            {
                return this;
                /// Normally, it's a very bad thing for GetEnumerator() to return "this" -
                /// it's OK, here, because we can only get Wrapper instances through Pool<>.Get
                /// which is designed to be threadsafe and to ensure that a Wrapper is either new or has been Reset().
            }

            #endregion

            #region IEnumerator Members

            object IEnumerator.Current
            {
                get { return Enumerator.Current; }
            }

            public D Current
            {
                get { return Enumerator.Current; }
            }

            public bool MoveNext()
            {
                return Enumerator.MoveNext();
            }

            public void Reset()
            {
                Enumerator.Reset();
            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {
                Trace.Line("\nSaving a dead enumerator");
                lock (DeadEnumerators)
                    DeadEnumerators.Push(this);
            }

            #endregion

        }
    }

    class Enumerable : IEnumerable<int>
    {
        private static int[] Data = new int[] { 1, 2, 3, 4, 5 };

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            return Data.GetEnumerator();
        }

        public IEnumerator<int> GetEnumerator()
        {
            return new ManualTypedEnumerator(Data);
        }

        private class ManualTypedEnumerator : IEnumerator<int>
        {
            public ManualTypedEnumerator(int[] Data)
            {
                this.Data = Data;
                Reset();
            }

            private int[] Data;
            private int Index;

            #region IEnumerator<int> Members

            public int Current
            {
                get { return Data[Index]; }
            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {
            }

            #endregion

            #region IEnumerator Members

            object IEnumerator.Current
            {
                get { return Current; }
            }

            public bool MoveNext()
            {
                return ++Index < Data.Length;
            }

            public void Reset()
            {
                Index = -1;
            }

            #endregion
        }
        #endregion
    }

    class Program
    {
        const int Repetitions = 5;

        static void Main(string[] args)
        {
            Console.WriteLine("native enumerator");
            foreach (int Item in new Enumerable())
                Console.Write(Item);
            Console.WriteLine('\n');

            Console.WriteLine("pooled enumerator");
            for (int Repetition = 1; Repetition <= Repetitions; Repetition++)
            {
                Console.WriteLine("Pass {0}", Repetition);
                foreach (int Item in Pool<int, Enumerable>.Get())
                    Console.Write(Item);
                Console.WriteLine();

            }

            Console.ReadLine();
        }
    }
}
