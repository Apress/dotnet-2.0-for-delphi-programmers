﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Disposable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("raw foreach");
            foreach (object O in new Manual()) ;
            foreach (int I in new Automatic()) 
                Console.Write(I);

            Console.WriteLine("\nforeach within a using");
            using (Manual M = new Manual())
                foreach (object O in M) ;
            using (Automatic A = new Automatic())
                foreach (int I in A)
                    Console.Write(I);
            Console.ReadLine();
        }
    }

    class Automatic :  IEnumerable, IDisposable
    {

        public IEnumerator GetEnumerator()
        {
            Console.WriteLine("code before any yield return ....");
            foreach (int I in new int[] { 1, 2, 3, 4, 5 })
                yield return I;
            Console.WriteLine("\ncode after last yield return ....");
            yield break;
        }

        #region IDisposable Members

        public void Dispose()
        {
            Console.WriteLine("Automatic.Dispose - called by using, not foreach");
        }

        #endregion
    }

    class Manual : IEnumerable, IDisposable
    {
        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return new Enumerator();
        }

        #endregion

        private class Enumerator : IEnumerator, IDisposable
        {
            #region IDisposable Members

            public void Dispose()
            {
                Console.WriteLine("Manual.Enumerator.Dispose");
            }

            #endregion

            #region IEnumerator Members

            object IEnumerator.Current
            {
                get { throw new global::System.NotImplementedException(); }
            }

            bool IEnumerator.MoveNext()
            {
                return false;
            }

            void IEnumerator.Reset()
            {
                throw new NotImplementedException();
            }

            #endregion
        }

        #region IDisposable Members

        public void Dispose()
        {
            Console.WriteLine("Manual.Dispose - called by using, not foreach");
        }

        #endregion

    }
}
