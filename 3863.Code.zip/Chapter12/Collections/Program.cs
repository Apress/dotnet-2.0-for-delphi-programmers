﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using Shemitz.Utilities;

#endregion

namespace lists
{
    public class Program
    {
        const int Elements = 1000;

        static void Main(string[] args)
        {
            BenchLists();
            Console.WriteLine();

            BenchDoubleIntHashes();
            Console.WriteLine();

            BenchIntIntHashes();
            Console.ReadLine();
        }

        private static void BenchLists()
        {
            int Element;
            #region Definitions
            Method Untyped = delegate
            {
                ArrayList UntypedList = new ArrayList(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    UntypedList.Add(Index);
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)UntypedList[Index];
            };
            Method Typed = delegate
            {
                List<int> TypedList = new List<int>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    TypedList.Add(Index);
                for (int Index = 0; Index < Elements; Index++)
                    Element = TypedList[Index];
            };
            Method Boxed = delegate
            {
                List<object> BoxedList = new List<object>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    BoxedList.Add(Index);
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)BoxedList[Index];
            };
            #endregion Definitions

            #region jit
            using (new Benchmark(null))
            {
                Untyped();
                Typed();
                Boxed();
            }
            #endregion

            using (new Benchmark("Untyped list"))
                Untyped();

            using (new Benchmark("Typed list"))
                Typed();

            using (new Benchmark("Boxed list"))
                Boxed();
        }

        private static void BenchDoubleIntHashes()
        {
            int Element;
            #region Definitions
            Method UntypedHashes = delegate
            {
                Hashtable Untyped = new Hashtable(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Untyped[Index + 0.1] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)Untyped[Index + 0.1];
            };
            Method TypedHashes = delegate
            {
                Dictionary<double, int> Typed = new Dictionary<double, int>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Typed[Index + 0.1] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = Typed[Index + 0.1];
            };
            Method BoxedHashes = delegate
            {
                Dictionary<object, object> Boxed = new Dictionary<object, object>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Boxed[Index + 0.1] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)Boxed[Index + 0.1];
            };
            #endregion Definitions

            #region jit
            using (new Benchmark(null))
            {
                UntypedHashes();
                TypedHashes();
                BoxedHashes();
            }
            #endregion

            using (new Benchmark("Untyped double/int hashes"))
                UntypedHashes();

            using (new Benchmark("Typed double/int hashes"))
                TypedHashes();

            using (new Benchmark("Boxed double/int hashes"))
                BoxedHashes();
        }

        private static void BenchIntIntHashes()
        {
            int Element;
            #region Definitions
            Method UntypedHashes = delegate
            {
                Hashtable Untyped = new Hashtable(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Untyped[Index * 3] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)Untyped[Index * 3];
            };
            Method TypedHashes = delegate
            {
                Dictionary<int, int> Typed = new Dictionary<int, int>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Typed[Index * 3] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = Typed[Index * 3];
            };
            Method BoxedHashes = delegate
            {
                Dictionary<object, object> Boxed = new Dictionary<object, object>(Elements);
                for (int Index = 0; Index < Elements; Index++)
                    Boxed[Index * 3] = Index;
                for (int Index = 0; Index < Elements; Index++)
                    Element = (int)Boxed[Index * 3];
            };
            #endregion Definitions

            #region jit
            using (new Benchmark(null))
            {
                UntypedHashes();
                TypedHashes();
                BoxedHashes();
            }
            #endregion

            using (new Benchmark("Untyped int/int hashes"))
                UntypedHashes();

            using (new Benchmark("Typed int/int hashes"))
                TypedHashes();

            using (new Benchmark("Boxed int/int hashes"))
                BoxedHashes();
        }
    }
}
