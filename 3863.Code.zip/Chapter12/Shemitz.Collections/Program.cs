﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using Shemitz.Collections.Generic;
using Shemitz.Utilities;
using NUnit.Framework;

#endregion

namespace UseFilters
{
    #region Executable benchmarks
    class Program
    {
        const int Repetitions = 100000;

        static void Main(string[] args)
        {
            #region Fragments
            Method autoFilter = delegate
            {
                for (int I = 0; I < Repetitions; I++)
                    foreach (int O in autoApply.FindAll<int>(test.Data, test.Odd)) ;
            };
            Method manualFilter = delegate
            {
                for (int I = 0; I < Repetitions; I++)
                    foreach (int O in manualApply.FindAll<int>(test.Data, test.Odd)) ;
            };
            Method autoMap = delegate
            {
                for (int I = 0; I < Repetitions; I++)
                    foreach (double D in autoApply.Map<double, int>(test.Data, test.ToDouble)) ;
            };
            Method manualMap = delegate
            {
                for (int I = 0; I < Repetitions; I++)
                    foreach (double D in manualApply.Map<double, int>(test.Data, test.ToDouble)) ;
            };
            using (new Benchmark(null))
            {
                autoFilter();
                manualFilter();
                autoMap();
                manualMap();
            }
            #endregion Fragments

            Benchmark Filter1, Filter2, Map1, Map2;

            using (Filter1 = new Benchmark("autoFilter"))
                autoFilter();
            using (Filter2 = new Benchmark("manualFilter"))
                manualFilter();
            Console.WriteLine("{0:p} slower\n", Filter1.Seconds / Filter2.Seconds - 1);

            using (Map1 = new Benchmark("autoMap"))
                autoMap();
            using (Map2 = new Benchmark("manualMap"))
                manualMap();
            Console.WriteLine("{0:p} slower", Map1.Seconds / Map2.Seconds - 1);

            Console.ReadLine();
        }
    }
    #endregion Executable benchmarks

    #region NUnit tests
    delegate T                    Find<T>        (IEnumerable<T> Items, Predicate<T> Test);
    delegate IEnumerable<T>       FindAll<T>          (IEnumerable<T> Items, Predicate<T> Test);
    delegate IEnumerable<OutType> Map<OutType, InType>(IEnumerable<InType> Items, Mapper<OutType, InType> Map);

    [TestFixture]
    public class AutoVsManualTests
    {
        [Test]
        public void applyOdd()
        {
            test.applyOdd(Apply.FindAll<int>);
            test.applyOdd(autoApply.FindAll<int>);
            test.applyOdd(manualApply.FindAll<int>);
        }

        [Test]
        public void mapToDouble()
        {
            test.mapToDouble(Apply.Map<double, int>);
            test.mapToDouble(autoApply.Map<double, int>);
            test.mapToDouble(manualApply.Map<double, int>);
        }
    }

    [TestFixture]
    public class PredicatesTests
    {
        [Test]
        public void Even()
        {
            test.applyFilter(Apply.FindAll<int>, Predicates<int>.Not(test.Odd), 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20);
            test.applyFilter(autoApply.FindAll<int>, Predicates<int>.Not(test.Odd), 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20);
            test.applyFilter(manualApply.FindAll<int>, Predicates<int>.Not(test.Odd), 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20);
        }

        [Test]
        public void Equality()
        {
            Assert.AreEqual(11, Apply.Find<int>(test.Data, Predicates<int>.Equal(11)));
            Assert.AreEqual(11, autoApply.Find<int>(test.Data, Predicates<int>.Equal(11)));
            Assert.AreEqual(11, manualApply.Find<int>(test.Data, Predicates<int>.Equal(11)));

            Assert.AreEqual(0, Apply.Find<int>(test.Data, Predicates<int>.Equal(121)));
            Assert.AreEqual(0, autoApply.Find<int>(test.Data, Predicates<int>.Equal(121)));
            Assert.AreEqual(0, manualApply.Find<int>(test.Data, Predicates<int>.Equal(121)));
        }

        [Test]
        public void InEquality()
        {
            IEnumerable<int> Odd = autoApply.FindAll<int>(test.Data, test.Odd);

            Assert.AreEqual(1, Apply.Find<int>(Odd, Predicates<int>.NotEqual(121)));
            Assert.AreEqual(1, autoApply.Find<int>(Odd, Predicates<int>.NotEqual(121)));
            Assert.AreEqual(1, manualApply.Find<int>(Odd, Predicates<int>.NotEqual(121)));
        }
    }

    // sort, reverse, firstN
    [TestFixture]
    public class Operators
    {
        [Test]
        public void ReverseSortAndTrim()
        {
            IEnumerable<int> Reversed = Operator.Reverse<int>(test.Data);
            test.Expect<int>(Reversed, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0);

            IEnumerable<int> Shortened = Operator.FirstN<int>(Reversed, 5);
            test.Expect<int>(Shortened, 20, 19, 18, 17, 16);

            IEnumerable<int> Sorted = Operator.Sorted<int>(Reversed);
            test.Expect<int>(Sorted, test.Data);
        }
    }

    class test
    {
        public static int[] Data = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };

        public static bool Odd(int I)
        {
            return (I & 1) != 0;
        }

        public static double ToDouble(int I)
        {
            return I;
        }

        public static void applyOdd(FindAll<int> Method)
        {
            applyFilter(Method, Odd, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19);
        }

        public static void Expect<T>(IEnumerable<T> Enumerable, params T[] Expected)
        {
            List<T> Output = new List<T>();
            foreach (T Item in Enumerable)
                Output.Add(Item);
            Assert.AreEqual(Expected.Length, Output.Count, "Enumeration doesn't match expected length");
            for (int I = 0; I < Expected.Length; I++)
                Assert.AreEqual(Expected[I], Output[I], "Enumeration doesn't match expected value");
        }

        public static void applyFilter(FindAll<int> Method, Predicate<int> P, params int[] results)
        {
            Expect<int>(Method(Data, P), results);
        }

        public static void mapToDouble(Map<double, int> Method)
        {
            List<double> Output = new List<double>();
            foreach (double D in Method(Data, ToDouble))
                Output.Add(D);
            Assert.AreEqual(Data.Length, Output.Count);
            for (int I = 0; I < Output.Count; I++)
                Assert.AreEqual((double)I, Output[I]);
        }
    }
    #endregion NUnit tests
}
