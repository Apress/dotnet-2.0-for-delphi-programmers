using System;
using System.Collections.Generic;
using Shemitz.Collections;

class Pipeline
{
    private static Random ThisRandom = new Random();

public static IEnumerable<d> Transform(IEnumerable<a> InputStream)
{
    IEnumerable<a> SomeA = Apply.FindAll<a>(InputStream,
        delegate(a Item) { return ThisRandom.Next(5) < 4; });
    IEnumerable<b> BStream = Apply.Map<b, a>(SomeA,
        delegate(a Item) { return new b(); });
    IEnumerable<c> CStream = Apply.Map<c, b>(BStream,
        delegate(b Item) { return new c(); });
    IEnumerable<c> SomeC = Apply.FindAll<c>(CStream,
        delegate(c Item) { return ThisRandom.Next(5) < 4; });
    return Apply.Map<d, c>(SomeC,
        delegate(c Item) { return new d(); });
}

    public static IEnumerable<d> Transform2(IEnumerable<a> InputStream)
    {
        foreach (a Item in InputStream)
        if (ThisRandom.Next(4) < 4)
        {
            // make a b
            // make a c
            if (ThisRandom.Next(4) < 4)
            {
                yield return new d();
            }

        }
    }

}

class a {}
class b {}
class c {}
class d {}
