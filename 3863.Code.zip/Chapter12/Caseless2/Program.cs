﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Caseless2
{
    class Program
    {
        static void Main(string[] args)
        {
            Caseless2 Hash = new Caseless2();

            Hash["ThIs"] = "The Caseless2 Hashtable";
            Hash[1] = "can still use non-string keys";
            Console.WriteLine("{0} {1}.", Hash["thiS"], Hash[1]);

            Caseless3 Dictionary = new Caseless3();
            Dictionary["ThIs"] = "The Caseless3 Dictionary";
            Dictionary["1"] = "can only use string keys";
            Console.WriteLine("{0} {1}.", Dictionary["This"], Dictionary["1"]);

            Console.ReadLine();
        }
    }

    class Caseless2 : Hashtable
    {
        public Caseless2(): base(CaselessComparer) { }

        /// The Caseless1 project creates new hash and comparison objects for each instance
        /// of the Caseless class. This project uses a single instance for all instances of
        /// its Caseless class. The tradeoff is that this singleton then lasts forever.
        private static IKeyComparer CaselessComparer = new Comparer();

        private class Comparer: IKeyComparer
        {

            bool IKeyComparer.Equals(object x, object y)
            {
                string X = x as string, Y = y as string;
                if (X != null && Y != null)
                    return String.Compare(X, Y, true) == 0;
                else
                    return x.Equals(y);
            }

            int IComparer.Compare(object x, object y)
            {
                string X = x as string, Y = y as string;
                if (X != null && Y != null)
                    return String.Compare(X, Y, true);
                else
                    throw new NotImplementedException();
            }

            int IHashCodeProvider.GetHashCode(object obj)
            {
                string S = obj as string;
                if (S != null)
                    return S.ToLower().GetHashCode();
                else
                    return obj.GetHashCode();
            }
        }
    }

    class Caseless3 : Dictionary<string, object>
    {
        public Caseless3(): base(CaselessComparer) { }

        private static IComparer<string> CaselessComparer = new Comparer();

        private class Comparer : IComparer<string>
        {
            #region IComparer<string> Members

            int IComparer<string>.Compare(string x, string y)
            {
                return String.Compare(x, y, true);
            }

            bool IComparer<string>.Equals(string x, string y)
            {
                return String.Compare(x, y, true) == 0;
            }

            int IComparer<string>.GetHashCode(string obj)
            {
                return obj.ToLower().GetHashCode();
            }

            #endregion
        }
    }
}
