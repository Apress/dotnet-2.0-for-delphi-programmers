﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace EmptyArrays
{
    class Program
    {
        private static bool IsOdd(int N)
        {
            return (N & 1) != 0;
        }

        static void Main(string[] args)
        {
            int[] Empty = new int[0];
            Console.WriteLine(Array.TrueForAll<int>(Empty, IsOdd));
            Console.WriteLine(Array.Exists<int>(Empty, IsOdd));
            Console.WriteLine("{0} ({1})", Array.Find<int>(Empty, IsOdd) == default(int), default(int));
            int[] All1 = Array.FindAll<int>(Empty, IsOdd);
            int[] All2 = Array.FindAll<int>(new int[] {0, 2, 4, 6, 8}, IsOdd);
            Console.WriteLine("{0}, {1}", All1.Length, All2.Length);
            Console.ReadLine();
        }
    }
}
