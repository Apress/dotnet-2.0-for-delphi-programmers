using System;
using System.Collections;

namespace CollectionTests
{
	class I: ICollection
	{
		private IEnumerable Enumerable;

		public IEnumerator GetEnumerator()
		{
			return Enumerable.GetEnumerator();
		}

		public void CopyTo(Array Target, int Offset)
		{
			foreach (object O in Enumerable)
				Target.SetValue(O, Offset++);
//			throw new NotImplementedException();
		}

		public int Count
		{
			get
			{
//				throw new NotImplementedException();
				int Result = 0;
				foreach (object O in Enumerable)
					Result++;
				return Result;
			}
		}

		public bool IsSynchronized
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public object SyncRoot
		{
			get
			{
				return Enumerable;
			}
		}

		public static ICollection Collection(IEnumerable Enumerable)
		{
			I Result = new I();
			Result.Enumerable = Enumerable;
			return Result;
		}
	}

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			ICollection Collection = I.Collection(new int[] {1, 2, 3, 4, 5});
			ArrayList List = new ArrayList(Collection);
//			success is running without any errors
//			Console.ReadLine();
		}
	}
}
