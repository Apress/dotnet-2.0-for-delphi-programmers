﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Text.RegularExpressions;

#endregion

namespace MatchResult
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex SSN = new Regex(@"(\d{3}) - (\d{2}) - (\d{4})", 
                RegexOptions.IgnorePatternWhitespace);

            Match M = SSN.Match("123-45-6789");

            Console.WriteLine(Object.ReferenceEquals(M, M.Groups[0]));
            Console.WriteLine(Object.ReferenceEquals(M, M.Captures[0]));

            Console.ReadLine();
        }
    }
}
