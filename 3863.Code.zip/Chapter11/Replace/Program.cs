﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Text.RegularExpressions;

#endregion

namespace Replace
{
    class Program
    {
        public static string Replace(string Pattern, Match M)
        {
            object[] Groups = new object[M.Groups.Count];
            M.Groups.CopyTo(Groups, 0);
            return String.Format(Pattern, Groups);
        }

        public static string Replace(string Input, Regex R, string Pattern)
        {
            // Create an object[] with an entry for every capture group in R
            object[] Groups = new object[R.GetGroupNumbers().Length];

            // Pass R.Replace a C# 2.0 anonymous method
            return R.Replace(Input, delegate(Match M)
            {
                M.Groups.CopyTo(Groups, 0);
                return String.Format(Pattern, Groups);
            });
        }

        public static string QuoteHtmlAttributes(string HTML)
        {
            string MatchUnquoted = @"
(?<= < [a-zA-Z_] \w+ \s+ [^>]* )    # open HTML tag to left

  (?<Attribute> [a-zA-Z_] \w+ ) =   # optional attribute=
  (?<Value>     [^""\s]+       )    # an unquoted value

(?= [^>]* > )                       # close HTML tag to right";
            // (?<= ) is a 'Zero-width positive lookbehind assertion' -
            // match only if there is an open HTML tag to the left,
            // but do not include the tag (or any previous attributes) in the match

            // (?= ) is a 'Zero-width positive lookahead assertion' -
            // match only if there is an open HTML tag to the right,
            // but do not include the tag (or any subsequent attributes) in the match

            return Regex.Replace(HTML, MatchUnquoted, "$1=\"$2\"", 
                RegexOptions.IgnorePatternWhitespace);
        }

        static void Main(string[] args)
        {
            Regex SSN = new Regex(@"(\d{3}) - (\d{2}) - (\d{4})",
                RegexOptions.IgnorePatternWhitespace);

            Match M = SSN.Match("123-45-6789");
            Console.WriteLine(Replace("[field.1={1}, field.2={2}, field.3={3}]", M));

            string S = SSN.Replace(@"Sample SSN 000-45-6789 is void because it has an all-zero field.
Sample SSN 123-00-6789 is void because it has an all-zero field
Sample SSN 123-45-0000 is void because it has an all-zero field
",
                "[field.1=$1, field.2=$2, field.3=$3 ]");
            Console.WriteLine(S);
            Console.WriteLine(Replace(@"Sample SSN 000-45-6789 is void because it has an all-zero field.
Sample SSN 123-00-6789 is void because it has an all-zero field
Sample SSN 123-45-0000 is void because it has an all-zero field
",
                SSN,
                "[field.1={1}, field.2={2}, field.3={3} ]"));

            string UnquotedHtml = "<table border=0 width=\"100%\" cellspacing=0 cellpadding=0>";
            Console.WriteLine(UnquotedHtml);
            Console.WriteLine(QuoteHtmlAttributes(UnquotedHtml));
            Console.ReadLine();
        }
    }
}
