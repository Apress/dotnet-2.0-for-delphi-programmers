﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Text.RegularExpressions;
using Precompiled.Regexs; // you need to run ResgexAssembly to generate the StandardRegexes assembly
using Shemitz.Utilities;

#endregion

namespace Consumer
{
    class Program
    {
        static void Main(string[] args)
        {
            using (new Benchmark()) ;
            Regex Precompiled, CompiledHere, Interpreted;

            using (new Benchmark("Creating precompiled"))
                Precompiled = new MatchingParens();
            string Pattern = Precompiled.ToString();
            RegexOptions Options = Precompiled.Options;

            using (new Benchmark("Creating & compiling"))
                CompiledHere = new Regex(Pattern, Options | RegexOptions.Compiled);

            using (new Benchmark("Creating an interpreted Regex"))
                Interpreted = new Regex(Pattern, Options & ~RegexOptions.Compiled);

            string Text = "(()";
            const int Repetitions = 1;

            using (new Benchmark("\nRunning precompiled"))
                for (int I = 0; I < Repetitions; I++)
                    Precompiled.Match(Text);

            using (new Benchmark("Running precompiled again"))
                for (int I = 0; I < Repetitions; I++)
                    Precompiled.Match(Text);

            using (new Benchmark("\nRunning just-compiled"))
                for (int I = 0; I < Repetitions; I++)
                    CompiledHere.Match(Text);

            using (new Benchmark("Running just-compiled again"))
                for (int I = 0; I < Repetitions; I++)
                    CompiledHere.Match(Text);

            using (new Benchmark("\nRunning interpreted"))
                for (int I = 0; I < Repetitions; I++)
                    Interpreted.Match(Text);

            using (new Benchmark("Running interpreted again"))
                for (int I = 0; I < Repetitions; I++)
                    Interpreted.Match(Text);

            Console.ReadLine();
        }
    }
}
