﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Reflection;
using System.Text.RegularExpressions;

#endregion

namespace RegexAssembly
{
    class Program
    {
        static void Main(string[] args)
        {
            string Namespace = "Precompiled.Regexs";
            RegexCompilationInfo[] StandardRegexs = {
                new RegexCompilationInfo(".+", RegexOptions.None,
                    "EachLine", Namespace, false),
                new RegexCompilationInfo(@"\d{3} - \d{2} - \d{4}", RegexOptions.IgnorePatternWhitespace,
                    "SocialSecurityNumber", Namespace, true),
                new RegexCompilationInfo(@"
                    \(                     # a literal (

                    (?:                   # non-capture group
                        (?<Stack>  \( )   # on nested (, push empty capture
                    | (?<-Stack> \) )   # on nested ), pop empty capture
                    | [^()]             # anything except ( or )
                    )*                    # any number of chars between parens

                    (?(Stack)              # if stack not empty:
                        ^                  # then, match beginning of string (ie, fail)
                    | \) )               # else, match literal )", RegexOptions.IgnorePatternWhitespace,
                    "MatchingParens", Namespace, true)
            };
            Regex.CompileToAssembly(StandardRegexs, new AssemblyName("StandardRegexes"));
            Console.WriteLine("OK");
        }
    }
}
