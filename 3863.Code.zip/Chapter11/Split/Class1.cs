// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Diagnostics;
using Shemitz.Utilities;

namespace ExtractTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string MethodName = "System.String.Split";
			string[] MethodComponents = MethodName.Split('.');
			string MethodName2 = String.Join(".", MethodComponents);
			Debug.Assert(! Object.ReferenceEquals(MethodName, MethodName2)); // different addr
			Debug.Assert(MethodName == MethodName2); // same value

			string path = @"c:\Program Files\Shazzubt\Read Me.txt";
			Split Parsed = new Split(path, ':', '\\', '.');

			Console.WriteLine(path);
			string Pattern = "{0,5} {1, 5} {2, 5}";
			Console.WriteLine("{0} words, 2nd is {1} long", Parsed.Length, Parsed[1].Length);
			Console.WriteLine();
			Console.WriteLine(Pattern, "Index", "Before", "After");
			for (int Index = 0; Index < Parsed.Length; Index++)
				Console.WriteLine(Pattern, Index, 
					Index > 0 ? Parsed.Before(Index): '_', 
					Index < Parsed.Length - 1 ? Parsed.After(Index): '_');

//			Console.WriteLine("First delimiter is {0}, second is {1}", Parsed.After(1), Parsed.Before(3));
			Console.ReadLine();
		}
	}
}
