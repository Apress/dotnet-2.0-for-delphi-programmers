// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using Shemitz.Utilities;
using System.Collections.Generic;

namespace Replacement
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		const string BaseString = "%now% %is% %the% %time% %for% %all% %the% %good% %dogs% %to% %roll% %over%. ";
		const int ExtraPatterns = 20 - 12; // Increase the number of replacement ops / 'width' of regex alternation
		const int Sentences = 50; // repeats of BaseString
		const int Powers = 3; // 2 = 1 and 10 repetations, 3=1, 10, 100, &c
		
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string Value;
			#region Patterns
			string[] Patterns = 
				{"%now%", "%is%", "%the%", "%time%", "%for%", "%all%", "%the%", "%good%", "%dogs%", "%to%", "%roll%", "%over%"};

			string[] Replacements =
				{"N0W", "1s", "thE", "t1me", "for", "a11", "THE", "g00d", "d0gs", "t0", "r011", "0ver"};

            List<string> L = new List<string>(ExtraPatterns + Patterns.Length);
			L.AddRange(Patterns);
			for (int Index = 0; Index < ExtraPatterns; Index++)
				L.Add(Index.GetHashCode().ToString());
			Patterns = L.ToArray();

			L.Clear();
			L.AddRange(Replacements);
			for (int Index = 0; Index < ExtraPatterns; Index++)
				L.Add(Index.ToString());
			Replacements = L.ToArray();
			#endregion Patterns

			#region Setup (JIT all code)
            Method _NaiveReplace = delegate { NaiveReplace(BaseString, Patterns, Replacements); };
            Method _StringBuilderReplace = delegate { StringBuilderReplace(BaseString, Patterns, Replacements); };
            Method _RegexReplace_None = delegate { RegexReplace(BaseString, Patterns, Replacements, RegexOptions.None); };
            Method _RegexReplace_Compiled = delegate { RegexReplace(BaseString, Patterns, Replacements, RegexOptions.Compiled); };
            Method _PatternReplace = delegate { PatternReplace(BaseString, Patterns, Replacements, RegexOptions.Compiled); };

            using (new Benchmark())
            {
                _NaiveReplace();
                _StringBuilderReplace();
                _RegexReplace_None();
                _RegexReplace_Compiled();
                _PatternReplace();
            }

            //using (new Benchmark("Setup"))
            //{
            //    Value = BaseString;
            //    Console.WriteLine(Value);

            //    Value = NaiveReplace(Value, Patterns, Replacements);
            //    Console.WriteLine(Value);

            //    Value = BaseString;
            //    Value = StringBuilderReplace(Value, Patterns, Replacements);
            //    Console.WriteLine(Value);
				
            //    Value = BaseString;
            //    Value = RegexReplace(Value, Patterns, Replacements, RegexOptions.None);
            //    Console.WriteLine(Value);

            //    Value = BaseString;
            //    Value = RegexReplace(Value, Patterns, Replacements, RegexOptions.Compiled);
            //    Console.WriteLine(Value);

            //    Value = BaseString;
            //    Value = PatternReplace(Value, Patterns, Replacements, RegexOptions.None);
            //    Console.WriteLine(Value);

            //    Value = BaseString;
            //    Value = PatternReplace(Value, Patterns, Replacements, RegexOptions.Compiled);
            //    Console.WriteLine(Value);
            //}
			#endregion Setup (JIT all code)

			#region Sentences
			StringBuilder TextBuilder = new StringBuilder(BaseString, BaseString.Length * Sentences);
			for (int Index = 1; Index < Sentences; Index++)
				TextBuilder.Append(BaseString);
			string Text = TextBuilder.ToString();
			#endregion Sentences

			Console.WriteLine("\n{0} sentences, {1} symbols", Sentences, Patterns.Length);

            int Repetitions = 1;
            for (int Power = 0; Power < Powers; Power++)
            {
                Console.WriteLine();
                //new FragmentTimer("N

                Fragment.Timer("NaiveReplace", _NaiveReplace, Repetitions);
                Fragment.Timer("StringBuilderReplace", _StringBuilderReplace, Repetitions);
                Fragment.Timer("RegexReplace_None", _RegexReplace_None, Repetitions);
                Fragment.Timer("RegexReplace_Compiled", _RegexReplace_Compiled, Repetitions);
                Fragment.Timer("PatternReplace", _PatternReplace, Repetitions);

                //using (new Benchmark("NaiveReplace - " + Repetitions.ToString() + " repetitions\t\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        NaiveReplace(Text, Patterns, Replacements);
                //using (new Benchmark("StringBuilderReplace - " + Repetitions.ToString() + " repetitions\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        StringBuilderReplace(Text, Patterns, Replacements);
                //using (new Benchmark("RegexReplace - " + Repetitions.ToString() + " repetitions\t\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        RegexReplace(Text, Patterns, Replacements, RegexOptions.None);
                //using (new Benchmark("Compiled RegexReplace - " + Repetitions.ToString() + " repetitions\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        RegexReplace(Text, Patterns, Replacements, RegexOptions.Compiled);
                //using (new Benchmark("PatternReplace - " + Repetitions.ToString() + " repetitions\t\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        PatternReplace(Text, Patterns, Replacements, RegexOptions.None);
                //using (new Benchmark("Compiled PatternReplace - " + Repetitions.ToString() + " repetitions\t"))
                //    for (int Index = 0; Index < Repetitions; Index++)
                //        PatternReplace(Text, Patterns, Replacements, RegexOptions.Compiled);
                Repetitions *= 10;
            }

			Console.WriteLine("\nDone");
			Console.ReadLine();
		}

		static string NaiveReplace(string Value, string[] Patterns, string[] Replacements)
		{
			if (Patterns.Length != Replacements.Length)
				throw new Exception("Patterns.Length != Replacements.Length");
			for (int Index = 0; Index < Patterns.Length; Index++)
				Value = Value.Replace(Patterns[Index], Replacements[Index]);
			return Value;
		}

		static string StringBuilderReplace(string Value, string[] Patterns, string[] Replacements)
		{
			if (Patterns.Length != Replacements.Length)
				throw new Exception("Patterns.Length != Replacements.Length");
			StringBuilder Result = new StringBuilder(Value);
			for (int Index = 0; Index < Patterns.Length; Index++)
				Result.Replace(Patterns[Index], Replacements[Index]);
			return Result.ToString();
		}

		static string RegexReplace(string Value, string[] Patterns, string[] Replacements, RegexOptions Options)
		{
			if (Patterns.Length != Replacements.Length)
				throw new Exception("Patterns.Length != Replacements.Length");
			StringBuilder Pattern = new StringBuilder();
			Hashtable Symbols = new Hashtable(Patterns.Length);
			for (int Index = 0; Index < Patterns.Length; Index++)
				//				if (Symbols[Patterns[Index]] == null)
			{
				string ThisPattern = Patterns[Index];
				Pattern.Append(Pattern.Length > 0 ? "|" + ThisPattern : ThisPattern);
				Symbols[ThisPattern] = Replacements[Index];
			}

			Regex R = new Regex(Pattern.ToString(), Options);
			RegexReplacer Replacer = new RegexReplacer(Symbols);

			return R.Replace(Value, new MatchEvaluator(Replacer.MatchEvaluator));
		}

		static string PatternReplace(string Value, string[] Patterns, string[] Replacements, RegexOptions Options)
		{ // string x = new string('\t', 4);
			if (Patterns.Length != Replacements.Length)
				throw new Exception("Patterns.Length != Replacements.Length");
			Hashtable Symbols = new Hashtable(Patterns.Length);
			for (int Index = 0; Index < Patterns.Length; Index++)
				Symbols[Patterns[Index]] = Replacements[Index];

			Regex R = new Regex(@"%\w+%", Options);
			RegexReplacer Replacer = new RegexReplacer(Symbols);

			return R.Replace(Value, new MatchEvaluator(Replacer.MatchEvaluator));
		}

//		static string CompiledRegexReplace(string Value, string[] Patterns, string[] Replacements)
//		{
//			if (Patterns.Length != Replacements.Length)
//				throw new Exception("Patterns.Length != Replacements.Length");
//			string Pattern = "";
//			Hashtable Symbols = new Hashtable(Patterns.Length);
//			for (int Index = 0; Index < Patterns.Length; Index++)
//				if (Symbols[Patterns[Index]] == null)
//				{
//					if (Pattern != "")
//						Pattern += "|";
//					Pattern += Patterns[Index];
//					Symbols[Patterns[Index]] = Replacements[Index];
//				}
//
//			Regex R = new Regex(Pattern, RegexOptions.Compiled);
//			RegexReplacer Replacer = new RegexReplacer(Symbols);
//
//			return R.Replace(Value, new MatchEvaluator(Replacer.MatchEvaluator));
//		}

		private class RegexReplacer
		{
			public RegexReplacer(Hashtable symbols)
			{
				this.symbols = symbols;
			}

			private Hashtable symbols;

			public string MatchEvaluator(Match match)
			{
				return (string) symbols[match.Value];
			}
		}

	}
}
