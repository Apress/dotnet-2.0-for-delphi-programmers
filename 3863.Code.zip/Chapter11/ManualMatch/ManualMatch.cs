// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Text.RegularExpressions;
using Shemitz.Utilities;

namespace ManualMatch
{
	class ManualMatch
	{
		[STAThread]
		static void Main(string[] args)
		{
			string Text = "this is a %token% as is %this% but %not% this%";
			Substring Token = FindToken(Text);
			while (Token != null)
			{
				Console.WriteLine(Token.ToString());
				Token = FindToken(Text, Token.Index + Token.Length);
			}

			Console.WriteLine();

			Regex Interpreted, Compiled;
			using (new Benchmark("jit benchmark code, and compile regexs")) 
			{
				Interpreted = new Regex("% [a-z_] [a-z_0-9]* %", 
					RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
				MatchCollection C = Interpreted.Matches(Text);
				foreach (Match M in C)
					Console.WriteLine(M.Value);

				Compiled = new Regex("% [a-z_] [a-z_0-9]* %", 
					RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Compiled);
				C = Compiled.Matches(Text);
				foreach (Match M in C)
					Console.WriteLine(M.Value);
			}

			Console.WriteLine();

			using (new Benchmark("Manual code"))
			{
				/*Substring*/ Token = FindToken(Text);
				while (Token != null)
					Token = FindToken(Text, Token.Index + Token.Length);
			}

			using (new Benchmark("Interpreted regex"))
				Interpreted.Matches(Text);

			using (new Benchmark("Compiled regex"))
				Compiled.Matches(Text);

			Console.ReadLine();
		}

		static Substring FindToken(string Text)
		{
			return FindToken(Text, 0);
		}

		private enum TokenStates  
			{FindFirstLiteral, FindAphabeticChar, FindAlphanumericChar, FindSecondLiteral};

		static Substring FindToken(string Text, int Index)
		{
			TokenStates State = TokenStates.FindFirstLiteral;
			int MatchStart = -1; // an error value, if you try SubString.ToString()
			while (true) // we return out
			{
				if (Index >= Text.Length)
					return null; // no match
				switch (State)
				{
					case TokenStates.FindFirstLiteral:
						if (Text[Index++] == '%')
						{
							MatchStart = Index - 1; // we use this if FindSecondLiteral succeeds
							State = TokenStates.FindAphabeticChar;
						}
						break;
					case TokenStates.FindAphabeticChar:
						char ThisChar = Text[Index++];
//						if (((ThisChar >= 'a' && ThisChar <= 'z') || (ThisChar >= 'A' && ThisChar <= 'Z')) || 
//							ThisChar == '_')
						if (Char.IsLetter(ThisChar) || ThisChar == '_')
							State = TokenStates.FindAlphanumericChar;
						else
							return null;
						break;
					case TokenStates.FindAlphanumericChar:
						ThisChar = Text[Index];
//						if (((ThisChar >= 'a' && ThisChar <= 'z') || (ThisChar >= 'A' && ThisChar <= 'Z')) || 
//							(ThisChar >= '0' && ThisChar <= '9') || ThisChar == '_')
						if (Char.IsLetter(ThisChar) || Char.IsDigit(ThisChar) || ThisChar == '_')
							Index++;
						else
							State = TokenStates.FindSecondLiteral;
						break;
					case TokenStates.FindSecondLiteral:
						if (Text[Index++] == '%')
							return new Substring(Text, MatchStart, Index - MatchStart);
						else
							State = TokenStates.FindFirstLiteral;
						break;
				}
			}
		}
	}

	class Substring
	{
		public Substring(string Base, int Index, int Length)
		{
			this.baseString = Base;
			this.index = Index;
			this.length = Length;
		}

		public override string ToString()
		{
			return Base.Substring(Index, Length);
		}

		public string Base	{	get	{	return baseString;	}	}
		private string baseString;
        
		public int Index	{	get	{	return index;		}	}
		private int index;

		public int Length	{	get	{	return length;		}	}
		private int length;
		}
}
