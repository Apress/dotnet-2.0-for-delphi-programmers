using System;

namespace ConsoleApplication2
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string Text = "this is a %token% as is %this%";
			Substring Match = FindToken(Text);
			if (Match != null)
			{
				Console.WriteLine(Match.ToString());
				Match = FindToken(Text, Match.Index + Match.Length);
				if (Match != null)
					Console.WriteLine(Match.ToString());
			}
			Console.ReadLine();
		}

		static Substring FindToken(string Text)
		{
			return FindToken(Text, 0);
		}

		private enum TokenStates  
			{FindFirstLiteral, FindAphabeticChar, FindAlphanumericChar, FindSecondLiteral};

		static Substring FindToken(string Text, int Index)
		{
			TokenStates State = TokenStates.FindFirstLiteral;
			int MatchStart = -1; // an error value, if you try SubString.ToString()
			while (true) // we return out
			{
				if (Index >= Text.Length)
					return null; // no match
				switch (State)
				{
					case TokenStates.FindFirstLiteral:
						if (Text[Index++] == '%')
						{
							MatchStart = Index - 1; // we use this if FindSecondLiteral succeeds
							State = TokenStates.FindAphabeticChar;
						}
						break;
					case TokenStates.FindAphabeticChar:
						char ThisChar = Text[Index++];
						if (Char.IsLetter(ThisChar) || ThisChar == '_')
							State = TokenStates.FindAlphanumericChar;
						else
							return null;
						break;
					case TokenStates.FindAlphanumericChar:
						ThisChar = Text[Index];
						if (Char.IsLetter(ThisChar) || Char.IsDigit(ThisChar) || ThisChar == '_')
							Index++;
						else
							State = TokenStates.FindSecondLiteral;
						break;
					case TokenStates.FindSecondLiteral:
						if (Text[Index++] == '%')
							return new Substring(Text, MatchStart, Index - MatchStart);
						else
							State = TokenStates.FindFirstLiteral;
						break;
				}
			}
		}
	}

	class Substring
	{
		public Substring(string Base, int Index, int Length)
		{
			this.baseString = Base;
			this.index = Index;
			this.length = Length;
		}

		public override string ToString()
		{
			return Base.Substring(Index, Length);
		}

		public string Base	{	get	{	return baseString;	}	}
		private string baseString;
        
		public int Index	{	get	{	return index;		}	}
		private int index;

		public int Length	{	get	{	return length;		}	}
		private int length;
		}
}
