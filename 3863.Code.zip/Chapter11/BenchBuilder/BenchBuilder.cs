// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Text;
using Shemitz.Utilities;

namespace BenchBuilder
{
	/// <summary>
	/// Summary description for BenchBuilder.
	/// </summary>
	class BenchBuilder
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			using (new Benchmark("jit"))
			{
//				Console.WriteLine(ProperCase1("jon"));
//				Console.WriteLine(ProperCase2("jon"));
				ProperCase1("jon");
				ProperCase2("jon");
			}

			const int Repetitions = 1;
			using (new Benchmark("Inline"))
			{
				for (int I = 0; I < Repetitions; I++)
					ProperCase1("jon");
			}
			using (new Benchmark("StringBuilder"))
			{
				for (int I = 0; I < Repetitions; I++)
					ProperCase2("jon");
			}
			Console.ReadLine();
		}

		private static string ProperCase1(string ThisString)
		{
			return Char.ToUpper(ThisString[0]) + ThisString.Substring(1);
		}

		private static string ProperCase2(string ThisString)
		{
			StringBuilder Builder = new StringBuilder(ThisString);
			Builder[0] = Char.ToUpper(Builder[0]);
			return Builder.ToString();
		}
	}
}
