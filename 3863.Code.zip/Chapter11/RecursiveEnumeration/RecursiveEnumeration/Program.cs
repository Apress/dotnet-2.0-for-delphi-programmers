﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.IO;
using System.Collections.Generic;
using Shemitz.Utilities;

#endregion

namespace RecursiveEnumeration
{
    class Program
    {
        static void Main(string[] args)
        {
            string ProjectDirectory = Directory.GetCurrentDirectory() + @"\..\.."; // assuming VS

            //string Source = TextFile.Read(ProjectDirectory + @"\Program.cs");
            //TextFile.Write16(ProjectDirectory + @"\Program.16.cs", Source);

            foreach (string S in Enumerate.FileNames(ProjectDirectory))
                Console.WriteLine(S);

            Console.WriteLine();

            foreach (FileSystemInfo File in Enumerate.Files(ProjectDirectory))
                Console.WriteLine(File.FullName);

            Console.WriteLine();

            //using (new Benchmark("jit"))
            //{
            //    Enumerate.FileNames(ProjectDirectory);
            //    Enumerate.Files(ProjectDirectory);
            //    Enumerate.Files2(ProjectDirectory);
            //}
            //using (new Benchmark("static"))
            //    Enumerate.FileNames(ProjectDirectory);
            //using (new Benchmark("instance.attributes"))
            //    Enumerate.Files(ProjectDirectory);
            //using (new Benchmark("instance.is"))
            //    Enumerate.Files(ProjectDirectory);

            //using (new Benchmark("instance.is"))
            //    Enumerate.Files(ProjectDirectory);
            //using (new Benchmark("instance.attributes"))
            //    Enumerate.Files(ProjectDirectory);
            //using (new Benchmark("static"))
            //    Enumerate.FileNames(ProjectDirectory);

            Console.ReadLine();
        }
    }

    class Enumerate
    {
        public static IEnumerable<string> FileNames(string Path)
        {
            return FileNames(Path, "*");
        }

        public static IEnumerable<string> FileNames(string Path, string Pattern)
        {
            string[] Entries = Directory.GetFileSystemEntries(Path, Pattern);
            foreach (string Entry in Entries)
            {
                if (!Directory.Exists(Entry))
                    yield return Entry;
                else
                    foreach (string Child in FileNames(Entry, Pattern))
                        yield return Child;
            }
        }

        public static IEnumerable<FileSystemInfo> Files(string Path)
        {
            return Files(Path, "*");
        }

        public static IEnumerable<FileSystemInfo> Files(string Path, string Pattern)
        {
            return Files(new DirectoryInfo(Path), Pattern);
        }

        public static IEnumerable<FileSystemInfo> Files(DirectoryInfo Directory, string Pattern)
        {
            FileSystemInfo[] Entries = Directory.GetFileSystemInfos(Pattern);
            foreach (FileSystemInfo Entry in Entries)
            {
                if (Entry is FileInfo)
                    yield return Entry;
                else
                    foreach (FileSystemInfo Child in Files((DirectoryInfo)Entry, Pattern))
                        yield return Child;
            }
        }

        public static IEnumerable<FileSystemInfo> Files2(string Path)
        {
            return Files2(Path, "*");
        }

        public static IEnumerable<FileSystemInfo> Files2(string Path, string Pattern)
        {
            return Files2(new DirectoryInfo(Path), Pattern);
        }

        public static IEnumerable<FileSystemInfo> Files2(DirectoryInfo Directory, string Pattern)
        {
            FileSystemInfo[] Entries = Directory.GetFileSystemInfos(Pattern);
            foreach (FileSystemInfo Entry in Entries)
            {
                yield return Entry;
//                if ((Entry.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                if (Entry is DirectoryInfo)
//                if (Entry.GetType() == typeof(DirectoryInfo))
                    foreach (FileSystemInfo Child in Files((DirectoryInfo)Entry, Pattern))
                        yield return Child;
            }
        }

    }
}
