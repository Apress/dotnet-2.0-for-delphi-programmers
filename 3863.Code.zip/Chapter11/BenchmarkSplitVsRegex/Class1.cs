// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Text.RegularExpressions;
using Shemitz.Utilities;

namespace BenchmarkSplitVsRegex
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		const int MaxRepetitions = 10000;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
        {
//            MatchesVsSplit();
            ExtractFirstLine();

            Console.ReadLine();
		}

        private static void MatchesVsSplit()
        {
            #region create stuff
            string path = @"c:\Program Files\Shazzubt\Read Me.txt";
            char[] delimitersArray = { ':', '\\', '.' };
            string delimitersRegex = @"
				
				  (?<left> [^\.\\:]* ) 
				  [\.\\:] 

			";
            Regex Interpreted = new Regex(delimitersRegex,
                RegexOptions.IgnorePatternWhitespace
                | RegexOptions.ExplicitCapture
                );
            Regex Compiled = new Regex(delimitersRegex,
                RegexOptions.IgnorePatternWhitespace
                | RegexOptions.ExplicitCapture
                | RegexOptions.Compiled);
			#endregion create stuff

			#region jit it before we do benchmarks
//			string[] A;
//			MatchCollection Matches;
            using (new Benchmark("jit"))
            {
                /* A = */
                path.Split(delimitersArray);
//				Console.WriteLine(A.Length);

//				Console.WriteLine("Interpreted");
                /*Matches = */
                Interpreted.Matches(path);
                /*Matches = */
                Compiled.Matches(path);
//				Console.WriteLine(Matches.Count);
//				foreach (Match match in Matches)
//				{
//					Console.Write("\"" + match.Groups[1].ToString() + "\" ");
////					Console.WriteLine("\n{0} groups, {1} captures. ", match.Groups.Count, match.Captures.Count);
//				}
//				Console.WriteLine();
////				Console.WriteLine("{0} groups, {1} captures. ", Matches.Groups.Count, Matches.Captures.Count);
//
////				Console.WriteLine("\nCompiled");
////				Matches = Compiled.Match(path);
////				Console.WriteLine(Matches.Success);
////				foreach (Group G in Matches.Groups)
////					Console.Write("\"" + G.ToString() + "\" ");
////				Console.WriteLine();
////				Console.WriteLine("{0} groups, {1} captures. ", Matches.Groups.Count, Matches.Captures.Count);
            }
            #endregion jit it before we do benchmarks

            #region benchmarks

            for (int Repetitions = 1; Repetitions <= MaxRepetitions; Repetitions *= 10)
            {
                Console.WriteLine("\n{0} repetition{1}", Repetitions,
                    Repetitions != 1 ? "s" : ""
                    );

                GC.Collect();

                using (new Benchmark("Interpreted"))
                {
                    for (int index = 0; index < Repetitions; index++)
                        Interpreted.Matches(path);
                    //					GC.Collect();
                }

                using (new Benchmark("Compiled"))
                {
                    for (int index = 0; index < Repetitions; index++)
                        Compiled.Matches(path);
//					GC.Collect();
                }

                using (new Benchmark("String.Split"))
                {
                    for (int index = 0; index < Repetitions; index++)
                        path.Split(delimitersArray);
//					GC.Collect();
                }

				#region order matters
//				using (new Benchmark("String.Split"))
//				{
//					for (int index = 0; index < Repetitions; index++)
//						path.Split(delimitersArray);
////					GC.Collect();
//				}
//
//				using (new Benchmark("Interpreted"))
//				{
//					for (int index = 0; index < Repetitions; index++)
//						Interpreted.Matches(path);
////					GC.Collect();
//				}
//
//				using (new Benchmark("Compiled"))
//				{
//					for (int index = 0; index < Repetitions; index++)
//						Compiled.Matches(path);
////					GC.Collect();
//				}
                #endregion order matters
            }

                #endregion benchmarks
        }

        private static void ExtractFirstLine()
        {
            #region Create things
            Regex iFirstLine = new Regex(".+", RegexOptions.None);
            Regex cFirstLine = new Regex(".+", RegexOptions.Compiled);
            string SingleLine = "This is a single, rather short line of text";
            const int Iterations = 10, LinesPerIteration = 10;
            string Text = SingleLine + "\n" + SingleLine, First;
            #endregion Create things

            #region jit 
            using (new Benchmark("jit"))
            {
//                First = Text.Split('\n')[0];
//                First = iFirstLine.Match(Text).Value;
//                First = cFirstLine.Match(Text).Value;
                Console.WriteLine(Text.Split('\n')[0] == iFirstLine.Matches(Text)[0].Value);
                Console.WriteLine(Text.Split('\n')[0] == cFirstLine.Matches(Text)[0].Value);
            }
            #endregion jit

            #region Benchmark
            Text = SingleLine;
            for (int Index = 1; Index <= Iterations; Index++)
            {
                int Length = Text.Split('\n').Length;
                using (new Benchmark("Split {0} line string", (object) Length))
                    for (int I = 0; I < Iterations; I++)
                        First = Text.Split('\n')[0];
                using (new Benchmark("Interpretive regex, {0} line string", (object)Length))
                    for (int I = 0; I < Iterations; I++)
                        First = iFirstLine.Matches(Text)[0].Value;
                using (new Benchmark("Compiled regex, {0} line string", (object)Length))
                    for (int I = 0; I < Iterations; I++)
                        First = cFirstLine.Matches(Text)[0].Value;
                for (int I = 0; I < LinesPerIteration; I++)
                    Text = String.Format("{0}\n{1}", Text, SingleLine);
                Console.WriteLine();
                GC.Collect();
            }
            #endregion Benchmark
        }

    }
}
