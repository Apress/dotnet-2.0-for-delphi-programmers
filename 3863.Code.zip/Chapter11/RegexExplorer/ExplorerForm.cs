// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Reflection;
using Shemitz.Utilities;
using System.Collections.Generic;
//using Shemitz.StdRegex;

namespace RegexExplorer
{
	/// <summary>
	/// Regex Explorer
	/// </summary>
	public class ExplorerForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label ErrorMessage;
        private System.Windows.Forms.TextBox Pattern;
        private System.Windows.Forms.Label OptionsLabel;
        private System.Windows.Forms.Label PatternLabel;
        private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox RegexOptions_CultureInvariant;
		private System.Windows.Forms.CheckBox RegexOptions_ECMAScript;
		private System.Windows.Forms.CheckBox RegexOptions_RightToLeft;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox RegexOptions_IgnorePatternWhitespace;
		private System.Windows.Forms.CheckBox RegexOptions_Singleline;
		private System.Windows.Forms.CheckBox RegexOptions_ExplicitCapture;
		private System.Windows.Forms.CheckBox RegexOptions_Multiline;
		private System.Windows.Forms.CheckBox RegexOptions_IgnoreCase;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.CheckBox RegexOptions_Compiled;
		private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton RegexOptions_None;
        private System.Windows.Forms.OpenFileDialog SearchTextDialog;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.Label VersionLabel;
		private System.Windows.Forms.ContextMenu PatternMenu;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
        private System.Windows.Forms.MenuItem menuItem4;
        private MenuItem menuItem5;
        private Panel centerPanel;
        private Panel leftPanel;
        private Panel rightPanel;
        private Button ReadFileButton;
        private TextBox SearchText;
        private ContextMenu TextMenu;
        private ToolStripMenuItem defaultTextToolStripMenuItem;
        private ToolStripMenuItem hTMLtagswithattributesToolStripMenuItem;
        private ToolStripMenuItem nesteddivtagsToolStripMenuItem;
        private MenuItem menuItem6;
        private MenuItem menuItem7;
        private MenuItem menuItem8;
        private MenuItem menuItem9;
        private SplitContainer TopSplitter;
        private Panel optionsPanel;
        private Panel searchTextPanel;
        private SplitContainer SearchResultsSplitter;
        private Label searchResultsLabel;
        private TreeView searchResults;
        private Label searchTextLabel;
        private MenuItem menuItem10;
        private MenuItem menuItem11;
        private MenuItem menuItem12;
        private CheckBox CopyOnClick;
        private System.ComponentModel.IContainer components;

		public ExplorerForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExplorerForm));
            this.Pattern = new System.Windows.Forms.TextBox();
            this.PatternMenu = new System.Windows.Forms.ContextMenu();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem12 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.OptionsLabel = new System.Windows.Forms.Label();
            this.ErrorMessage = new System.Windows.Forms.Label();
            this.PatternLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RegexOptions_CultureInvariant = new System.Windows.Forms.CheckBox();
            this.RegexOptions_ECMAScript = new System.Windows.Forms.CheckBox();
            this.RegexOptions_RightToLeft = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RegexOptions_IgnorePatternWhitespace = new System.Windows.Forms.CheckBox();
            this.RegexOptions_Singleline = new System.Windows.Forms.CheckBox();
            this.RegexOptions_ExplicitCapture = new System.Windows.Forms.CheckBox();
            this.RegexOptions_Multiline = new System.Windows.Forms.CheckBox();
            this.RegexOptions_IgnoreCase = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.RegexOptions_Compiled = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.RegexOptions_None = new System.Windows.Forms.RadioButton();
            this.SearchTextDialog = new System.Windows.Forms.OpenFileDialog();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.VersionLabel = new System.Windows.Forms.Label();
            this.SearchText = new System.Windows.Forms.TextBox();
            this.TextMenu = new System.Windows.Forms.ContextMenu();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.searchResults = new System.Windows.Forms.TreeView();
            this.CopyOnClick = new System.Windows.Forms.CheckBox();
            this.centerPanel = new System.Windows.Forms.Panel();
            this.ReadFileButton = new System.Windows.Forms.Button();
            this.defaultTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hTMLtagswithattributesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nesteddivtagsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.TopSplitter = new System.Windows.Forms.SplitContainer();
            this.searchTextPanel = new System.Windows.Forms.Panel();
            this.SearchResultsSplitter = new System.Windows.Forms.SplitContainer();
            this.searchTextLabel = new System.Windows.Forms.Label();
            this.searchResultsLabel = new System.Windows.Forms.Label();
            this.optionsPanel = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.centerPanel.SuspendLayout();
            this.TopSplitter.Panel1.SuspendLayout();
            this.TopSplitter.Panel2.SuspendLayout();
            this.TopSplitter.SuspendLayout();
            this.searchTextPanel.SuspendLayout();
            this.SearchResultsSplitter.Panel1.SuspendLayout();
            this.SearchResultsSplitter.Panel2.SuspendLayout();
            this.SearchResultsSplitter.SuspendLayout();
            this.optionsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pattern
            // 
            this.Pattern.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Pattern.AutoSize = false;
            this.Pattern.ContextMenu = this.PatternMenu;
            this.Pattern.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pattern.Location = new System.Drawing.Point(15, 43);
            this.Pattern.Multiline = true;
            this.Pattern.Name = "Pattern";
            this.Pattern.Size = new System.Drawing.Size(489, 96);
            this.Pattern.TabIndex = 1;
            this.Pattern.Text = ".*";
            this.toolTip.SetToolTip(this.Pattern, "(Try right clicking)");
            this.Pattern.WordWrap = false;
            this.Pattern.TextChanged += new System.EventHandler(this.ControlTextChanged);
            // 
            // PatternMenu
            // 
            this.PatternMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem2,
            this.menuItem1,
            this.menuItem10,
            this.menuItem3,
            this.menuItem4,
            this.menuItem9,
            this.menuItem5,
            this.menuItem12,
            this.menuItem11});
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 0;
            this.menuItem2.Tag = ".+";
            this.menuItem2.Text = "At least one of any character";
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 1;
            this.menuItem1.Tag = ".*";
            this.menuItem1.Text = "Any number, of any character";
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 2;
            this.menuItem10.Tag = "(?<>)";
            this.menuItem10.Text = "Named capture group";
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 3;
            this.menuItem3.Tag = "#[IgnorePatternWhitespace]\r\n\\d{3} - \\d{2} - \\d{4}";
            this.menuItem3.Text = "American SSN";
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 4;
            this.menuItem4.Tag = "#[IgnorePatternWhitespace]\r\n% [a-z_] [a-z_0-9]* %";
            this.menuItem4.Text = "Tokens like %this%.";
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 5;
            this.menuItem9.Tag = resources.GetString("menuItem9.Tag");
            this.menuItem9.Text = "Parse a HTML tag, with attributes";
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 6;
            this.menuItem5.Tag = resources.GetString("menuItem5.Tag");
            this.menuItem5.Text = "HTML tag match, with back-reference";
            // 
            // menuItem12
            // 
            this.menuItem12.Index = 7;
            this.menuItem12.Tag = resources.GetString("menuItem12.Tag");
            this.menuItem12.Text = "Match nested parentheses";
            // 
            // menuItem11
            // 
            this.menuItem11.Index = 8;
            this.menuItem11.Tag = resources.GetString("menuItem11.Tag");
            this.menuItem11.Text = "Nested HTML tag match, with attributes";
            // 
            // OptionsLabel
            // 
            //this.OptionsLabel.AutoRelocate = true;
            this.OptionsLabel.BackColor = System.Drawing.Color.Moccasin;
            this.OptionsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OptionsLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.OptionsLabel.Location = new System.Drawing.Point(11, 11);
            this.OptionsLabel.Name = "OptionsLabel";
            this.OptionsLabel.Size = new System.Drawing.Size(396, 23);
            this.OptionsLabel.TabIndex = 11;
            this.OptionsLabel.Text = " Regex Options";
            this.OptionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ErrorMessage
            // 
            this.ErrorMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ErrorMessage.AutoSize = true;
            this.ErrorMessage.BackColor = System.Drawing.Color.Moccasin;
            this.ErrorMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.ErrorMessage.Location = new System.Drawing.Point(400, 16);
            this.ErrorMessage.Name = "ErrorMessage";
            this.ErrorMessage.Size = new System.Drawing.Size(108, 13);
            this.ErrorMessage.TabIndex = 13;
            this.ErrorMessage.Text = "(no error message)";
            this.ErrorMessage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ErrorMessage.Visible = false;
            // 
            // PatternLabel
            // 
            this.PatternLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PatternLabel.BackColor = System.Drawing.Color.Moccasin;
            this.PatternLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PatternLabel.Location = new System.Drawing.Point(15, 13);
            this.PatternLabel.Name = "PatternLabel";
            this.PatternLabel.Size = new System.Drawing.Size(489, 23);
            this.PatternLabel.TabIndex = 0;
            this.PatternLabel.Text = " Regex &Pattern";
            this.PatternLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.RegexOptions_CultureInvariant);
            this.groupBox1.Controls.Add(this.RegexOptions_ECMAScript);
            this.groupBox1.Controls.Add(this.RegexOptions_RightToLeft);
            this.groupBox1.Location = new System.Drawing.Point(11, 135);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 36);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.UseCompatibleTextRendering = true;
            // 
            // RegexOptions_CultureInvariant
            // 
            this.RegexOptions_CultureInvariant.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RegexOptions_CultureInvariant.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_CultureInvariant.Location = new System.Drawing.Point(284, 8);
            this.RegexOptions_CultureInvariant.Name = "RegexOptions_CultureInvariant";
            this.RegexOptions_CultureInvariant.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_CultureInvariant.TabIndex = 13;
            this.RegexOptions_CultureInvariant.Text = "CultureIn&variant";
            this.toolTip.SetToolTip(this.RegexOptions_CultureInvariant, "IgnoreCase in a culture-insensitive way.");
            this.RegexOptions_CultureInvariant.UseVisualStyleBackColor = false;
            this.RegexOptions_CultureInvariant.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_ECMAScript
            // 
            this.RegexOptions_ECMAScript.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_ECMAScript.Location = new System.Drawing.Point(136, 8);
            this.RegexOptions_ECMAScript.Name = "RegexOptions_ECMAScript";
            this.RegexOptions_ECMAScript.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_ECMAScript.TabIndex = 12;
            this.RegexOptions_ECMAScript.Text = "&ECMAScript";
            this.toolTip.SetToolTip(this.RegexOptions_ECMAScript, "Enables ECMAScript-compliant behavior for the expression.");
            this.RegexOptions_ECMAScript.UseVisualStyleBackColor = false;
            this.RegexOptions_ECMAScript.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_RightToLeft
            // 
            this.RegexOptions_RightToLeft.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_RightToLeft.Location = new System.Drawing.Point(4, 8);
            this.RegexOptions_RightToLeft.Name = "RegexOptions_RightToLeft";
            this.RegexOptions_RightToLeft.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_RightToLeft.TabIndex = 11;
            this.RegexOptions_RightToLeft.Text = "&RightToLeft";
            this.toolTip.SetToolTip(this.RegexOptions_RightToLeft, "Reverse the order of the Matches");
            this.RegexOptions_RightToLeft.UseVisualStyleBackColor = false;
            this.RegexOptions_RightToLeft.Click += new System.EventHandler(this.Option_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.RegexOptions_IgnorePatternWhitespace);
            this.groupBox2.Controls.Add(this.RegexOptions_Singleline);
            this.groupBox2.Controls.Add(this.RegexOptions_ExplicitCapture);
            this.groupBox2.Controls.Add(this.RegexOptions_Multiline);
            this.groupBox2.Controls.Add(this.RegexOptions_IgnoreCase);
            this.groupBox2.Location = new System.Drawing.Point(11, 75);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(396, 60);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.UseCompatibleTextRendering = true;
            // 
            // RegexOptions_IgnorePatternWhitespace
            // 
            this.RegexOptions_IgnorePatternWhitespace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.RegexOptions_IgnorePatternWhitespace.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_IgnorePatternWhitespace.Checked = true;
            this.RegexOptions_IgnorePatternWhitespace.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RegexOptions_IgnorePatternWhitespace.Location = new System.Drawing.Point(136, 30);
            this.RegexOptions_IgnorePatternWhitespace.Name = "RegexOptions_IgnorePatternWhitespace";
            this.RegexOptions_IgnorePatternWhitespace.Size = new System.Drawing.Size(239, 24);
            this.RegexOptions_IgnorePatternWhitespace.TabIndex = 10;
            this.RegexOptions_IgnorePatternWhitespace.Text = "IgnorePattern&Whitespace";
            this.toolTip.SetToolTip(this.RegexOptions_IgnorePatternWhitespace, "Ignore whitespace and comments.");
            this.RegexOptions_IgnorePatternWhitespace.UseVisualStyleBackColor = false;
            this.RegexOptions_IgnorePatternWhitespace.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_Singleline
            // 
            this.RegexOptions_Singleline.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_Singleline.Location = new System.Drawing.Point(4, 8);
            this.RegexOptions_Singleline.Name = "RegexOptions_Singleline";
            this.RegexOptions_Singleline.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_Singleline.TabIndex = 7;
            this.RegexOptions_Singleline.Text = "&Singleline";
            this.toolTip.SetToolTip(this.RegexOptions_Singleline, "Without this, . does not match \\n");
            this.RegexOptions_Singleline.UseVisualStyleBackColor = false;
            this.RegexOptions_Singleline.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_ExplicitCapture
            // 
            this.RegexOptions_ExplicitCapture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RegexOptions_ExplicitCapture.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_ExplicitCapture.Location = new System.Drawing.Point(284, 8);
            this.RegexOptions_ExplicitCapture.Name = "RegexOptions_ExplicitCapture";
            this.RegexOptions_ExplicitCapture.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_ExplicitCapture.TabIndex = 11;
            this.RegexOptions_ExplicitCapture.Text = "E&xplicitCapture";
            this.toolTip.SetToolTip(this.RegexOptions_ExplicitCapture, "Anonymous parens are algebraic grouping, only. Capture groups are explicitly name" +
                    "d.");
            this.RegexOptions_ExplicitCapture.UseVisualStyleBackColor = false;
            this.RegexOptions_ExplicitCapture.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_Multiline
            // 
            this.RegexOptions_Multiline.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_Multiline.Location = new System.Drawing.Point(4, 30);
            this.RegexOptions_Multiline.Name = "RegexOptions_Multiline";
            this.RegexOptions_Multiline.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_Multiline.TabIndex = 8;
            this.RegexOptions_Multiline.Text = "&Multiline";
            this.toolTip.SetToolTip(this.RegexOptions_Multiline, "Change ^ and $ to match at start of lines, not just whole string.");
            this.RegexOptions_Multiline.UseVisualStyleBackColor = false;
            this.RegexOptions_Multiline.Click += new System.EventHandler(this.Option_Click);
            // 
            // RegexOptions_IgnoreCase
            // 
            this.RegexOptions_IgnoreCase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.RegexOptions_IgnoreCase.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_IgnoreCase.Location = new System.Drawing.Point(136, 8);
            this.RegexOptions_IgnoreCase.Name = "RegexOptions_IgnoreCase";
            this.RegexOptions_IgnoreCase.Size = new System.Drawing.Size(188, 24);
            this.RegexOptions_IgnoreCase.TabIndex = 9;
            this.RegexOptions_IgnoreCase.Text = "&IgnoreCase";
            this.toolTip.SetToolTip(this.RegexOptions_IgnoreCase, "Case-insensitive matching (culture-sensitive).");
            this.RegexOptions_IgnoreCase.UseVisualStyleBackColor = false;
            this.RegexOptions_IgnoreCase.Click += new System.EventHandler(this.Option_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.RegexOptions_Compiled);
            this.groupBox3.Location = new System.Drawing.Point(263, 41);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(144, 36);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.UseCompatibleTextRendering = true;
            // 
            // RegexOptions_Compiled
            // 
            this.RegexOptions_Compiled.BackColor = System.Drawing.Color.Transparent;
            this.RegexOptions_Compiled.Location = new System.Drawing.Point(32, 8);
            this.RegexOptions_Compiled.Name = "RegexOptions_Compiled";
            this.RegexOptions_Compiled.Size = new System.Drawing.Size(108, 24);
            this.RegexOptions_Compiled.TabIndex = 8;
            this.RegexOptions_Compiled.Text = "&Compiled";
            this.toolTip.SetToolTip(this.RegexOptions_Compiled, "Slow setup; fast repeat use; stays in  memory.");
            this.RegexOptions_Compiled.UseVisualStyleBackColor = false;
            this.RegexOptions_Compiled.Click += new System.EventHandler(this.Option_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.RegexOptions_None);
            this.groupBox4.Location = new System.Drawing.Point(11, 39);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(144, 36);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.UseCompatibleTextRendering = true;
            // 
            // RegexOptions_None
            // 
            this.RegexOptions_None.Location = new System.Drawing.Point(4, 8);
            this.RegexOptions_None.Name = "RegexOptions_None";
            this.RegexOptions_None.Size = new System.Drawing.Size(104, 24);
            this.RegexOptions_None.TabIndex = 2;
            this.RegexOptions_None.Text = "&None";
            this.toolTip.SetToolTip(this.RegexOptions_None, "No options bits set");
            this.RegexOptions_None.Click += new System.EventHandler(this.RegexOptions_None_Click);
            // 
            // SearchTextDialog
            // 
            this.SearchTextDialog.AddExtension = false;
            this.SearchTextDialog.Filter = "Text files|*.txt|All files|*.*";
            this.SearchTextDialog.Title = "Select a text file";
            // 
            // VersionLabel
            // 
            this.VersionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.VersionLabel.BackColor = System.Drawing.Color.Transparent;
            this.VersionLabel.ForeColor = System.Drawing.SystemColors.GrayText;
            this.VersionLabel.Location = new System.Drawing.Point(404, 0);
            this.VersionLabel.Name = "VersionLabel";
            this.VersionLabel.Size = new System.Drawing.Size(100, 23);
            this.VersionLabel.TabIndex = 18;
            this.VersionLabel.Text = "Version {0}";
            this.VersionLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // SearchText
            // 
            this.SearchText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchText.AutoSize = false;
            this.SearchText.ContextMenu = this.TextMenu;
            this.SearchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchText.HideSelection = false;
            this.SearchText.Location = new System.Drawing.Point(9, 38);
            this.SearchText.Multiline = true;
            this.SearchText.Name = "SearchText";
            this.SearchText.Size = new System.Drawing.Size(196, 107);
            this.SearchText.TabIndex = 1;
            this.SearchText.Text = "The text\r\nto search";
            this.toolTip.SetToolTip(this.SearchText, "(Try right clicking)");
            this.SearchText.TextChanged += new System.EventHandler(this.ControlTextChanged);
            // 
            // TextMenu
            // 
            this.TextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem6,
            this.menuItem7,
            this.menuItem8});
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 0;
            this.menuItem6.Tag = "The text \r\nto search";
            this.menuItem6.Text = "Default Text";
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 1;
            this.menuItem7.Tag = "<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n  <tr>\r\n    <td>" +
                "\r\n    </td>\r\n  </tr>\r\n</table>";
            this.menuItem7.Text = "HTML <table> tag, with attributes";
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 2;
            this.menuItem8.Tag = "<div class=\"Outer\">\r\n  <div class=\"Inner\">\r\n    Inner text\r\n  </div>\r\n</div>";
            this.menuItem8.Text = "Nested HTML <div> tags";
            // 
            // searchResults
            // 
            this.searchResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.searchResults.BackColor = System.Drawing.Color.Linen;
            this.searchResults.HideSelection = false;
            this.searchResults.Location = new System.Drawing.Point(3, 38);
            this.searchResults.Name = "searchResults";
            this.searchResults.Size = new System.Drawing.Size(283, 137);
            this.searchResults.TabIndex = 13;
            this.toolTip.SetToolTip(this.searchResults, "Click on nodes to highlight matches");
            this.searchResults.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.searchResults_AfterSelect);
            // 
            // CopyOnClick
            // 
            this.CopyOnClick.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CopyOnClick.AutoSize = true;
            this.CopyOnClick.BackColor = System.Drawing.Color.Moccasin;
            this.CopyOnClick.Location = new System.Drawing.Point(195, 8);
            this.CopyOnClick.Name = "CopyOnClick";
            this.CopyOnClick.Size = new System.Drawing.Size(86, 17);
            this.CopyOnClick.TabIndex = 14;
            this.CopyOnClick.Text = "Copy on click";
            this.CopyOnClick.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip.SetToolTip(this.CopyOnClick, "Copy capture to clipboard on select?");
            this.CopyOnClick.UseVisualStyleBackColor = false;
            // 
            // centerPanel
            // 
            this.centerPanel.Controls.Add(this.groupBox4);
            this.centerPanel.Controls.Add(this.groupBox3);
            this.centerPanel.Controls.Add(this.groupBox2);
            this.centerPanel.Controls.Add(this.groupBox1);
            this.centerPanel.Controls.Add(this.OptionsLabel);
            this.centerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.centerPanel.Location = new System.Drawing.Point(49, 0);
            this.centerPanel.Margin = new System.Windows.Forms.Padding(1, 3, 3, 3);
            this.centerPanel.Name = "centerPanel";
            this.centerPanel.Size = new System.Drawing.Size(419, 187);
            this.centerPanel.TabIndex = 19;
            // 
            // ReadFileButton
            // 
            this.ReadFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ReadFileButton.Location = new System.Drawing.Point(130, 152);
            this.ReadFileButton.Name = "ReadFileButton";
            this.ReadFileButton.Size = new System.Drawing.Size(75, 23);
            this.ReadFileButton.TabIndex = 2;
            this.ReadFileButton.Text = "read file";
            this.ReadFileButton.Click += new System.EventHandler(this.ReadFileButton_Click);
            // 
            // defaultTextToolStripMenuItem
            // 
            this.defaultTextToolStripMenuItem.Name = "defaultTextToolStripMenuItem";
            // 
            // hTMLtagswithattributesToolStripMenuItem
            // 
            this.hTMLtagswithattributesToolStripMenuItem.Name = "hTMLtagswithattributesToolStripMenuItem";
            // 
            // nesteddivtagsToolStripMenuItem
            // 
            this.nesteddivtagsToolStripMenuItem.Name = "nesteddivtagsToolStripMenuItem";
            // 
            // leftPanel
            // 
            this.leftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftPanel.Location = new System.Drawing.Point(0, 0);
            this.leftPanel.Margin = new System.Windows.Forms.Padding(3, 3, 1, 3);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(49, 187);
            this.leftPanel.TabIndex = 22;
            // 
            // rightPanel
            // 
            this.rightPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightPanel.Location = new System.Drawing.Point(468, 0);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(49, 187);
            this.rightPanel.TabIndex = 23;
            // 
            // TopSplitter
            // 
            this.TopSplitter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TopSplitter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TopSplitter.Location = new System.Drawing.Point(0, 0);
            this.TopSplitter.Name = "TopSplitter";
            this.TopSplitter.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // TopSplitter.Panel1
            // 
            this.TopSplitter.Panel1.Controls.Add(this.ErrorMessage);
            this.TopSplitter.Panel1.Controls.Add(this.Pattern);
            this.TopSplitter.Panel1.Controls.Add(this.PatternLabel);
            this.TopSplitter.Panel1.Controls.Add(this.VersionLabel);
            // 
            // TopSplitter.Panel2
            // 
            this.TopSplitter.Panel2.Controls.Add(this.searchTextPanel);
            this.TopSplitter.Panel2.Controls.Add(this.optionsPanel);
            this.TopSplitter.Size = new System.Drawing.Size(521, 544);
            this.TopSplitter.SplitterDistance = 159;
            this.TopSplitter.TabIndex = 24;
            this.TopSplitter.Text = "splitContainer1";
            // 
            // searchTextPanel
            // 
            this.searchTextPanel.Controls.Add(this.SearchResultsSplitter);
            this.searchTextPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.searchTextPanel.Location = new System.Drawing.Point(0, 187);
            this.searchTextPanel.Name = "searchTextPanel";
            this.searchTextPanel.Size = new System.Drawing.Size(517, 190);
            this.searchTextPanel.TabIndex = 2;
            // 
            // SearchResultsSplitter
            // 
            this.SearchResultsSplitter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SearchResultsSplitter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SearchResultsSplitter.Location = new System.Drawing.Point(0, 0);
            this.SearchResultsSplitter.Name = "SearchResultsSplitter";
            // 
            // SearchResultsSplitter.Panel1
            // 
            this.SearchResultsSplitter.Panel1.Controls.Add(this.ReadFileButton);
            this.SearchResultsSplitter.Panel1.Controls.Add(this.searchTextLabel);
            this.SearchResultsSplitter.Panel1.Controls.Add(this.SearchText);
            // 
            // SearchResultsSplitter.Panel2
            // 
            this.SearchResultsSplitter.Panel2.Controls.Add(this.CopyOnClick);
            this.SearchResultsSplitter.Panel2.Controls.Add(this.searchResults);
            this.SearchResultsSplitter.Panel2.Controls.Add(this.searchResultsLabel);
            this.SearchResultsSplitter.Size = new System.Drawing.Size(517, 190);
            this.SearchResultsSplitter.SplitterDistance = 222;
            this.SearchResultsSplitter.TabIndex = 13;
            this.SearchResultsSplitter.Text = "splitContainer1";
            // 
            // searchTextLabel
            // 
            this.searchTextLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            //this.searchTextLabel.AutoRelocate = true;
            this.searchTextLabel.BackColor = System.Drawing.Color.Moccasin;
            this.searchTextLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchTextLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.searchTextLabel.Location = new System.Drawing.Point(9, 5);
            this.searchTextLabel.Name = "searchTextLabel";
            this.searchTextLabel.Size = new System.Drawing.Size(205, 23);
            this.searchTextLabel.TabIndex = 0;
            this.searchTextLabel.Text = " Search &Text";
            this.searchTextLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // searchResultsLabel
            // 
            this.searchResultsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            //this.searchResultsLabel.AutoRelocate = true;
            this.searchResultsLabel.BackColor = System.Drawing.Color.Moccasin;
            this.searchResultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchResultsLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.searchResultsLabel.Location = new System.Drawing.Point(3, 5);
            this.searchResultsLabel.Name = "searchResultsLabel";
            this.searchResultsLabel.Size = new System.Drawing.Size(283, 23);
            this.searchResultsLabel.TabIndex = 12;
            this.searchResultsLabel.Text = " Search Results";
            this.searchResultsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // optionsPanel
            // 
            this.optionsPanel.Controls.Add(this.centerPanel);
            this.optionsPanel.Controls.Add(this.leftPanel);
            this.optionsPanel.Controls.Add(this.rightPanel);
            this.optionsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.optionsPanel.Location = new System.Drawing.Point(0, 0);
            this.optionsPanel.Name = "optionsPanel";
            this.optionsPanel.Size = new System.Drawing.Size(517, 187);
            this.optionsPanel.TabIndex = 1;
            // 
            // ExplorerForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(521, 544);
            this.Controls.Add(this.TopSplitter);
            this.MinimumSize = new System.Drawing.Size(450, 450);
            this.Name = "ExplorerForm";
            this.Text = "Regex Explorer";
            this.Load += new System.EventHandler(this.ExplorerForm_Load);
            this.Resize += new System.EventHandler(this.ExplorerForm_Resize);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.centerPanel.ResumeLayout(false);
            this.TopSplitter.Panel1.ResumeLayout(false);
            this.TopSplitter.Panel1.PerformLayout();
            this.TopSplitter.Panel2.ResumeLayout(false);
            this.TopSplitter.ResumeLayout(false);
            this.searchTextPanel.ResumeLayout(false);
            this.SearchResultsSplitter.Panel1.ResumeLayout(false);
            this.SearchResultsSplitter.Panel2.ResumeLayout(false);
            this.SearchResultsSplitter.Panel2.PerformLayout();
            this.SearchResultsSplitter.ResumeLayout(false);
            this.optionsPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new ExplorerForm());
		}

		#region exper. code
//		private static void BuildRegexen()
//		{
//			RegexCompilationInfo[] Regexen = {
//				new RegexCompilationInfo(".+", RegexOptions.Multiline, "lineBreak", "Shemitz.StdRegex", true)
//			};
//
//			AssemblyName Name = new AssemblyName();
//			Name.Name = "StdRegex";
//			Name.Version = new Version();
//
//			Regex.CompileToAssembly(Regexen, Name);
//		}
//
//		private Hashtable regexCache = new Hashtable();
//		private Regex getRegex(System.Type RegexType)
//		{
//			if (! regexCache.ContainsKey(RegexType))
//				regexCache[RegexType] = System.Activator.CreateInstance(RegexType);
//			return (Regex) regexCache[RegexType];
//
//		}
		#endregion exper. code

		#region Event handlers
        private int centerPanelWidth /*, bottomPanelTop */;

        /// <summary>
		/// Sets radio buttons' Tag property to a RegexOptions bit name.
		/// </summary>
		private void ExplorerForm_Load(object sender, System.EventArgs e)
		{
            // Init resize code
            centerPanelWidth = centerPanel.Width;
            ExplorerForm_Resize(null, null);

            // Set radio button tags
//			RegexOptions_None.Tag = RegexOptions.None;
			RegexOptions_IgnoreCase.Tag = RegexOptions.IgnoreCase;
			RegexOptions_Multiline.Tag = RegexOptions.Multiline;
			RegexOptions_ExplicitCapture.Tag = RegexOptions.ExplicitCapture;
			RegexOptions_IgnorePatternWhitespace.Tag = RegexOptions.IgnorePatternWhitespace;
			RegexOptions_Singleline.Tag = RegexOptions.Singleline;
			RegexOptions_Compiled.Tag = RegexOptions.Compiled;
			RegexOptions_CultureInvariant.Tag = RegexOptions.CultureInvariant;
			RegexOptions_ECMAScript.Tag = RegexOptions.ECMAScript;
			RegexOptions_RightToLeft.Tag = RegexOptions.RightToLeft;

            // Set popup menu click handlers
            foreach (MenuItem ThisMenu in PatternMenu.MenuItems)
                SetMenuClick(ThisMenu, delegate(object MenuParam, System.EventArgs dummyEventArgs)
                {
                    MenuItem Menu = (MenuItem) MenuParam;
                    Pattern.SelectedText = (string)Menu.Tag;
                } );
            foreach (MenuItem ThisMenu in TextMenu.MenuItems)
                SetMenuClick(ThisMenu, delegate(object MenuParam, System.EventArgs dummyEventArgs)
                {
                    MenuItem Menu = (MenuItem)MenuParam;
                    SearchText.SelectedText = (string)Menu.Tag;
                });

            // Set VersionLabel
            Version AppVersion = Assembly.GetExecutingAssembly().GetName().Version;
            VersionLabel.Text = String.Format(VersionLabel.Text,
                Assembly.GetExecutingAssembly().GetName().Version.ToString(2));
            toolTip.SetToolTip(VersionLabel, Build.Timestamp(AppVersion).ToShortDateString());

            // handle 'resize' &c
            UiChange();
		}

        private void SetMenuClick(MenuItem Menu, EventHandler Handler)
        {
            Menu.Click += Handler; // UseStandardPattern;
        }

        private void ControlTextChanged(object sender, System.EventArgs e)
		{
            FindRegexOptions();
            UiChange();
		}

        private void FindRegexOptions()
        {
			string Pattern = this.Pattern.Text;
			if (Pattern == null)
                Pattern = "";

            // Parse lines like ""#[ExplicitCapture|IgnorePatternWhitespace]""
            string OptionsParser = 
                @"\# \[ (?<option> \w+ ) (\s* \| \s* (?<option> \w+ ) )* \s* ]";

            MatchCollection Matches = Regex.Matches(Pattern,
                OptionsParser,
                RegexOptions.IgnorePatternWhitespace | RegexOptions.ExplicitCapture | RegexOptions.Compiled);
            if (Matches.Count == 1)
            {
                Type typeofRegexOptions = typeof(RegexOptions);
                CaptureCollection Captures = Matches[0].Groups[1].Captures;

                // Get a valid options bitmap
                RegexOptions Options = RegexOptions.None;
                foreach (Capture Token in Captures)
                {
                    string TokenValue = Token.Value;
                    if (!IsRegexOption(TokenValue))
                        return;
                    else
                        Options |= ToRegexOption(TokenValue);
                }
                using (new Interlock.Touch(SelfChange))
                    foreach (Control C in AllControls(this))
                    {
                        CheckBox CB = C as CheckBox;
                        if (CB != null)
                            if (CB.Tag is RegexOptions) 
                                CB.Checked = (Options & (RegexOptions)CB.Tag) != 0;
                    }
            }
        }

        public static IEnumerable<Control> AllControls(Control root)
        {
            foreach (Control Child in root.Controls)
            {
                yield return Child;
                foreach (Control GrandChild in AllControls(Child))
                    yield return GrandChild;
            }
        }

        private readonly Type typeofRegexOptions = typeof(RegexOptions);

        private bool IsRegexOption(string Name)
        {
            try
            { 
                Enum.Parse(typeofRegexOptions, Name, true);
                return true;
            }
            catch   
            {   return false;   }
        }

        private RegexOptions ToRegexOption(string Name)
        {
            return (RegexOptions) Enum.Parse(typeofRegexOptions, Name, true);
        }

        Interlock SelfChange = new Interlock();

        private void RegexOptions_None_Click(object sender, System.EventArgs e)
		{
			if (RegexOptions_None.Checked)
                using (new Interlock.Touch(SelfChange))
		        {
			        RegexOptions_IgnoreCase.Checked = false;
			        RegexOptions_Multiline.Checked = false;
			        RegexOptions_ExplicitCapture.Checked = false;
			        RegexOptions_IgnorePatternWhitespace.Checked = false;
			        RegexOptions_Singleline.Checked = false;
			        RegexOptions_Compiled.Checked = false;
			        RegexOptions_CultureInvariant.Checked = false;
			        RegexOptions_ECMAScript.Checked = false;
			        RegexOptions_RightToLeft.Checked = false;
		        }
            if (! SelfChange.Locked)
			    UiChange();
		}
	
		private void Option_Click(object sender, System.EventArgs e)
		{
            if (! SelfChange.Locked)
                UiChange();
        }

		private void ReadFileButton_Click(object sender, System.EventArgs e)
		{
			if (SearchTextDialog.ShowDialog() == DialogResult.OK)
				SearchText.Text = TextFile.Read(SearchTextDialog.FileName);
		}

        private void UseStandardPattern(object sender, System.EventArgs e)
        {
            MenuItem Menu = (MenuItem)sender;
            Pattern.SelectedText = (string)Menu.Tag;
        }

        private void UseStandardText(object sender, System.EventArgs e)
        {
            MenuItem Menu = (MenuItem)sender;
            SearchText.SelectedText = (string)Menu.Tag;
        }

        private void ExplorerForm_Resize(object sender, EventArgs e)
        {
            leftPanel.Width = rightPanel.Width = (ClientSize.Width - centerPanelWidth) / 2;
//            searchPanel.Height = ClientSize.Height - bottomPanelTop;
        }

        private void searchResults_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode ThisNode = searchResults.SelectedNode;
            if (ThisNode == null)
                return;

            Capture ThisCapture = ThisNode.Tag as Capture;
            if (ThisCapture == null)
                return;

            SearchText.SelectionStart = ThisCapture.Index;
            SearchText.SelectionLength = ThisCapture.Length;

            if (CopyOnClick.Checked && ThisCapture.Length > 0)
                Clipboard.SetText(ThisCapture.Value);
        }
        #endregion Event handlers

        #region Update code

        private void UiChange()
		{
			#region Get Pattern, make sure there's some text
			string Pattern = this.Pattern.Text;
			if (Pattern == null || Pattern == "") 
			{
				ErrorText = "No pattern";
				return;
			}
			#endregion Get Pattern, make sure there's some text

			#region Get SearchText, make sure there's some text
			string Text = SearchText.Text;
			if (Text == null)
				Text = "";
			#endregion Get SearchText, make sure there's some text

            RegexOptions Options = GetRegexOptions();

			#region Create and run Regex
			try // catch
			{
//				int SelectedIndex = Tabs.SelectedIndex ;
				Control ActiveControl = this.ActiveControl;

//                Tabs.SuspendLayout();

                try // finally
                {
                    ClearOldResults();

                    // Run the Regex
					MatchCollection Matches = Regex.Matches(Text, Pattern, Options);

                    ShowMatches(Matches);

                    ErrorText = Matches.Count > 0 ? null : "No matches";

                }
                #region finally - resume layout, restore selected tab, focus
                finally
                {
//                    Tabs.ResumeLayout();

//                    if (SelectedIndex < Tabs.TabCount)
//                        Tabs.SelectedIndex = SelectedIndex;
                    
                    // restore focus, so you can keep typing in pattern box or whatever
                    this.ActiveControl = ActiveControl;
                }
                #endregion finally - resume layout, restore selected tab, focus
            }
			#region catch - show error message
			catch (Exception E)
			{
				// Show the 1st line
				string[] Lines = E.Message.Split('\n'); // faster than .+ regex, for short strings
				ErrorText = Lines[0];
            }
            #endregion catch - show error message
			#endregion Create and run Regex
		}

        private RegexOptions GetRegexOptions()
        {
            RegexOptions Options = RegexOptions.None;
            foreach (Control Group in centerPanel.Controls)
                if (Group is GroupBox)
                    foreach (Control C in Group.Controls)
                        if (C is CheckBox && ((CheckBox)C).Checked /*&& C.Tag is RegexOptions*/)
                            Options |= (RegexOptions)C.Tag;
            using (new Interlock.Touch(SelfChange))
                RegexOptions_None.Checked = Options == RegexOptions.None; //  true;
            return Options;
        }

        private void ClearOldResults()
        {
//            for (int Index = Tabs.Controls.Count - 1; Index > 0; Index--)
//                Tabs.Controls.RemoveAt(Index);
            searchResults.Nodes.Clear();
        }

        private void ShowMatches(MatchCollection Matches)
        {
            #region try
            try
            {
            #endregion try
                searchResults.BeginUpdate();

                int MatchCount = 0;
                foreach (Match ThisMatch in Matches)
                {
                    TreeNode MatchNode = searchResults.Nodes.Add(
                        String.Format("Match {0}: Value = \"{1}\"",
                        MatchCount++, EscapeNewline(ThisMatch.Value))); // 1st, 2nd, 3rd match ....
                    MatchNode.Tag = ThisMatch;

                    #region Groups
                    if (ThisMatch.Groups.Count > 1)
                    {
                        int GroupIndex = 0;
                        foreach (Group ThisGroup in ThisMatch.Groups)
                        {
                            string GroupText = String.Format(
                                ThisGroup.Success
                                    ? "Group {0}: Value == \"{1}\""
                                    : "Group {0}, no match.",
                                GroupIndex++,
                                EscapeNewline(ThisGroup.Value));
                            TreeNode GroupNode = MatchNode.Nodes.Add(GroupText);
                            GroupNode.Tag = ThisGroup;

                            #region Captures
                            if (ThisGroup.Captures.Count > 1)
                            {
                                int CaptureIndex = 0;
                                foreach (Capture ThisCapture in ThisGroup.Captures)
                                {
                                    TreeNode CaptureNode = GroupNode.Nodes.Add(
                                        String.Format("Capture {0}: Value = \"{1}\"",
                                        ++CaptureIndex, EscapeNewline(ThisCapture.Value)));
                                    CaptureNode.Tag = ThisCapture;
                                }
                            }
                            #endregion Captures
                        }
                    }
                    #endregion Groups
                }
                if (MatchCount == 0)
                    searchResults.Nodes.Add("No match");

            }
            #region finally
            finally
            {
                searchResults.EndUpdate();
            }
            #endregion finally
        }

        private string EscapeNewline(string Value)
        {
            return Value.Replace("\n", "\\n").Replace("\r", "\\r");
        }

        private string ErrorText
        {
			get	
			{	return ErrorMessage.Text;	}
			set
			{
				ErrorMessage.Text = value;
				ErrorMessage.Left = PatternLabel.Right - ErrorMessage.Width - 8;
				ErrorMessage.Visible = (value != null) & (value != "");

			}
		}
		#endregion Update code
    }
}
