﻿#region Using directives

using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;
using Shemitz.Utilities;
#endregion

namespace DemandCreate
{
    class Program
    {
        static DemandCreate Regexs = new DemandCreate();

        static void Main(string[] args)
        {
//            DemandCreate Regexs = new DemandCreate();

            using (new Benchmark("jit")) ;

            string Text = @"Line 1
Line 2
Line 3
Line 4
Line 5
Line 6";

            using (new Benchmark("dynamic"))
            {
                Regex Dynamic = Regexs.Create("LineBreak");
                Dynamic.Match(Text);
            }

            using (new Benchmark("static"))
            {
                Regex Static = new Regex(".+", RegexOptions.None);
                Static.Match(Text);
            }
            Console.ReadLine();
        }
    }

    class DemandCreate
    {
        private Assembly PrecompiledRegexs;

        public DemandCreate()
        {
            string CurrentDirectory = Directory.GetCurrentDirectory();
            if (!File.Exists(CurrentDirectory + "\\PrecompiledRegexs.dll"))
                Regex.CompileToAssembly(new RegexCompilationInfo[] 
                {
                    new RegexCompilationInfo(".+", RegexOptions.None, "LineBreak", "PrecompiledRegexs", true)
                }, new AssemblyName("PrecompiledRegexs"));

            PrecompiledRegexs = Assembly.LoadFile(CurrentDirectory + "\\PrecompiledRegexs.dll");
        }

        public Regex Create(string Name)
        {
            Type T = PrecompiledRegexs.GetType("PrecompiledRegexs." + Name);
            return T != null ? (Regex)Activator.CreateInstance(T) : null;
        }
    }
}
