// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace Substrings
{
	public class Substring
	{
		#region privates
		private string privateBase;
		private int privateIndex;
		private int privateLength;
		#endregion privates

		#region Constructors

		/// <summary>
		/// Represents a region within a larger string. 
		/// </summary>
		/// <param name="Base">The larger string</param>
		/// <param name="Index">The start point</param>
		/// <param name="Length">The length</param>
		public Substring(string Base, int Index, int Length)
		{
			privateBase = Base;
			privateIndex = Index;
			privateLength = Length;
		}

		/// <summary>
		/// Represents a region within a larger string. The 'right tail' overload.
		/// </summary>
		/// <param name="Base">The string to wrap a Substring around</param>
		/// <param name="Index">The start point</param>
		public Substring(string Base, int Index): this(Base, Index, Base.Length - Index) {}

		/// <summary>
		/// Represents a region within a larger string. Special constructor that includes whole string.
		/// </summary>
		/// <param name="Base">The string to wrap a Substring around</param>
		public Substring(string Base): this(Base, 0, Base.Length) {}

		/// <summary>
		/// Substring of a Substring - drop the first Index chars of Value
		/// </summary>
		/// <param name="Base">The Substring to shorten</param>
		/// <param name="Index">The first char of Value to preserve</param>
		public Substring(Substring Base, int Index): this(Base, Index,  Base.Length - Index) {}

		/// <summary>
		/// Substring of a Substring - trims front and back of Value, without touching Base
		/// </summary>
		/// <param name="Base">The Substring to shorten</param>
		/// <param name="Index">The first char of Value to preserve</param>
		/// <param name="Length">The number of chars of Value to preserve</param>
		public Substring(Substring Base, int Index, int Length)
		{
			//			if (Base == null)
			if (Base.IsEmpty())
				throw new Exception("Base shouldn't be null");
			privateBase = Base.Base;

			privateIndex = Base.Index + Index;
			if (! Base.IndexInSubstring(privateIndex))
				throw new ArgumentOutOfRangeException("Index", Index, "Not in Substring");

			privateLength = Length;
			if (privateLength < 0)
				throw new ArgumentOutOfRangeException("Length", Length, "Length < 0");
				//				privateLength = 0;
			else if (privateIndex + privateLength > privateBase.Length)
				privateLength = privateBase.Length - privateIndex;
		}

		/// <summary>
		/// Represents a region within a larger string. 
		/// </summary>
		/// <param name="Target">A string that a Regex successully Match()ed</param>
		/// <param name="G">A capture within the Target</param>
		public Substring(string Target, Group G)
		{
			//			substringOfGroup(Target, G);
			if (! G.Success)
				throw new Exception("Regex match not successful");
			if (G.Length <= 0)
				throw new Exception("Regex match empty");
			privateBase = Target;
			privateIndex = G.Index;
			privateLength = G.Length;
		}

		private void substringOfGroup(string Base, Group G)
		{
			if (! G.Success)
				throw new Exception("Regex match not successful");
			if (G.Length <= 0)
				throw new Exception("Regex match empty");
			privateBase = Base;
			privateIndex = G.Index;
			privateLength = G.Length;
		}
		
		/// <summary>
		/// Represents a region within a larger string. 
		/// </summary>
		/// <param name="Target">A Substring that a Regex successully Match()ed in</param>
		/// <param name="G">A capture within the Target</param>
		public Substring(Substring Target, Group G)
		{
			//			substringOfGroup(Target.Base, G);
			if (! G.Success)
				throw new Exception("Regex match not successful");
			if (G.Length <= 0)
				throw new Exception("Regex match empty");
			privateBase = Target.Base;
			privateIndex = G.Index;
			privateLength = G.Length;
		}
		
		/// <summary>
		/// Represents a region within a larger string. (The NUnit override.)
		/// </summary>
		//		public Substring() {}

		#endregion Constructors

		#region Public string-like properties &c
		/// <summary>
		/// The string that this Substring is a 'window onto'
		/// </summary>
		public string Base { get { return privateBase;   } }
		/// <summary>
		/// The starting offset, within the Base string
		/// </summary>
		public int Index   { get { return privateIndex;  } }
		/// <summary>
		/// Substring Length
		/// </summary>
		public int Length  { get { return privateLength; } }

		public string Value { get { return ToString(); } }

		override public string ToString()
		{
			return Base.Substring(Index, Length);
		}

		public static explicit operator string(Substring S)
		{
			//			return S == null ? null: S.ToString();
			return S.IsEmpty() ? null: S.ToString();
		}

		//		public static implicit operator Substring(string S)
		//		{
		//			return S == null ? null: new Substring(S);
		//		}

		public int Compare(string CompareTo)
		{
			return Compare(CompareTo, false);
		}

		public int Compare(string CompareTo, bool IgnoreCase)
		{
			return String.Compare(Base, Index, CompareTo, 0, Length, IgnoreCase);
		}

		public int Compare(Substring CompareTo)
		{
			return Compare(CompareTo, false);
		}

		public int Compare(Substring CompareTo, bool IgnoreCase)
		{
			int ThisLength = Length, ThatLength = CompareTo.Length;
			int Lesser = ThisLength < ThatLength ? ThisLength : ThatLength;

			return String.Compare(Base, Index, CompareTo.Base, CompareTo.Index, Lesser, IgnoreCase);
		}

		#endregion Public string-like properties &c

		#region Regex shims
		/// <summary>
		/// Returns Pattern.Match(Target).Success, and creates Substring if true (null if false)
		/// </summary>
		/// <param name="Return">The Substring with the match info, or null</param>
		/// <param name="Pattern">The Regex to Match()</param>
		/// <param name="Target">The string to Match() in</param>
		/// <returns>Pattern.Match(Target).Success</returns>
		public static bool IfMatch(out Substring Return, Regex Pattern, string Target)
		{
			Match M = Pattern.Match(Target);
			if (M.Success)
				Return = new Substring(Target, M.Index, M.Length);
			else
				Return = Substring.Empty; // null;
			return M.Success;
		}

		/// <summary>
		/// Returns Pattern.Match(Target).Success, and creates Substring if true (null if false)
		/// </summary>
		/// <param name="Return">The Substring with the match info, or null</param>
		/// <param name="Pattern">The Regex to Match()</param>
		/// <param name="Target">The Substring to Match() in</param>
		/// <returns>Pattern.Match(Target).Success</returns>
		public static bool IfMatch(out Substring Return, Regex Pattern, Substring Target)
		{
			//			Match M = Pattern.Match(Target.Base, Target.Index, Target.Length);
			Match M = Target.Match(Pattern);
			if (M.Success)
				Return = new Substring(Target.Base, M.Index, M.Length);
			else
				Return = Substring.Empty; // null;
			return M.Success;
		}

		public Match Match(Regex Pattern)
		{
			return Pattern.Match(Base, Index, Length);
		}

		public Match Match(Regex Pattern, int OffsetInBaseString)
		{
			if (OffsetInBaseString < Index)
				throw new ArgumentOutOfRangeException("OffsetInBaseString", "Not within Substring");
			if (! IndexInSubstring((int) OffsetInBaseString))
				throw new ArgumentOutOfRangeException("OffsetInBaseString", "Not within base string");
			return Pattern.Match(Base, OffsetInBaseString, Length - (OffsetInBaseString - Index));
		}

		/// <summary>
		/// Repeatedly does a Regex Match() on the Substring Base string, within the Substring 'window'; 
		/// returns all Match objs through IEnumerator (foreach).
		/// </summary>
		/// <param name="Pattern">The Regex to Match() in the Substring</param>
		/// <returns></returns>
		public IEnumerable Matches(Regex Pattern)
			//		public IEnumerator Matches(Regex Pattern)
		{
			return new privateMatches(Pattern, this);
		}

		private class privateMatches: IEnumerable, IEnumerator
		{
			private Regex Pattern;
			private Substring Target;
			private int Index;
			private Match CurrentMatch;

			public IEnumerator GetEnumerator()
			{
				return this;
			}

			public privateMatches(Regex Pattern, Substring Target)
			{
				this.Pattern = Pattern;
				this.Target = Target;
				Reset();
			}

			public void Reset()
			{
				Index = Target.Index;
			}

			public bool MoveNext()
			{
				if (! Target.IndexInSubstring(Index)) // Nowhere to Match()
					return false;

				CurrentMatch = Pattern.Match(Target.Base, Index, Target.Length - (Index - Target.Index));
				if (CurrentMatch.Success)
					Index = CurrentMatch.Index + CurrentMatch.Length;
				return CurrentMatch.Success;
			}

			public object Current {	get { return CurrentMatch; } }
		}

		#endregion Regex shims

		#region Misc. ops
		public bool IndexInSubstring(int Index)
		{
			return Index >= this.Index && Index < this.Index + this.Length;
		}

		/// <summary>
		/// Case-sensitive search for Pattern within Substring
		/// </summary>
		/// <param name="Pattern">String to find within substring</param>
		/// <param name="Offset">Offset WITHIN SUBSTRING to begin search at</param>
		/// <returns>Offset WITHIN SUBSTRING of match, or -1</returns>
		public int IndexOf(string Pattern, int Offset)
		{
			return Base.IndexOf(Pattern, Index + Offset, Length - Offset) - Index;
		}

		/// <summary>
		/// Case-sensitive search for Pattern within Substring
		/// </summary>
		/// <param name="Pattern">String to find within substring</param>
		/// <returns>Offset WITHIN SUBSTRING of match, or -1</returns>
		public int IndexOf(string Pattern)
		{
			return IndexOf(Pattern, 0);
		}
		#endregion Misc. ops

		#region Empty
		public static Substring Empty = new Substring((string) null, 0, 0);
		//		static Substring()
		//		{
		////			Empty = new Substring();
		//			Empty.privateBase = null;
		//			Empty.privateIndex = 0;
		//			Empty.privateLength = 0;
		//		}
		public bool IsEmpty()
		{
			return Base == null && Index == 0 && Length == 0;
		}
		#endregion Empty
	}
}
