// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

// If you set a breakpoint on public static Pseudo operator +, 
// you will see that it is never called - one or both Pseudo? 
// values equaled null. If you uncomment the code in Program.Main, 
// you will see that the operator is called when neither 
// Pseudo? value equaled null.

namespace LiftedOverloadedOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            //Pseudo? P = new Pseudo(1);
            //Pseudo? Q = new Pseudo(2);
            //Pseudo? R = P + Q;

            ////Pseudo PPrime = new Pseudo(10);
            ////Pseudo QPrime = new Pseudo(20);
            ////Pseudo RPrime = PPrime + QPrime;
            ////R = PPrime;
            ////R = QPrime;
            ////R = PPrime + QPrime;

            Pseudo? Null = null;
            Pseudo? NonNull = new Pseudo(47);
            Pseudo? Sum = Null + NonNull;

            Console.WriteLine("{0}, {1}, {2}", Null.HasValue, NonNull.HasValue, Sum.HasValue);
            Console.ReadLine();
        }
    }

    struct Pseudo
    {
        public static Pseudo operator +(Pseudo Left, Pseudo Right)
        {
            // Set a breakpoint on the next line
            return new Pseudo(Left.Value + Right.Value);
        }

        public Pseudo(int Value)
        {
            this.Value = Value;
        }

        private int Value;
    }
}
