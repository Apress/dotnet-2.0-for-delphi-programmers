// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace LiftedOperators
{
    static class Program
    {
        static void Main(string[] args)
        {
            bool?[] BoolValues = new bool?[] { true, false, null };
            int?[] IntValues = new int?[] { -1, 0, 1, null };
            float?[] FloatValues = new float?[] { 1.2f, 2.3f, null };

            Table<bool>("&", delegate(bool? Left, bool? Right) { return Left & Right; }, BoolValues);
            Table<bool>("|", delegate(bool? Left, bool? Right) { return Left | Right; }, BoolValues);
            Table<bool>("^", delegate(bool? Left, bool? Right) { return Left ^ Right; }, BoolValues);

            Table<bool>("==", delegate(bool? Left, bool? Right) { return Left == Right; }, BoolValues);
            Table<bool>("!=", delegate(bool? Left, bool? Right) { return Left != Right; }, BoolValues);

            Table<int>(">", delegate(int? Left, int? Right) { return Left > Right; }, IntValues);
            Table<int>("<", delegate(int? Left, int? Right) { return Left < Right; }, IntValues);

            Table<float>(">", delegate(float? Left, float? Right) { return Left > Right; }, FloatValues);
            Table<float>("<", delegate(float? Left, float? Right) { return Left < Right; }, FloatValues);

            Console.ReadLine();
        }

        delegate bool? NullableTest<T>(T? Left, T? Right) where T : struct;

        static void Table<T>(string Tag, NullableTest<T> Operator, T?[] Values) where T : struct
        {
            Console.WriteLine("The {0} Table", Tag);

            Console.Write("\t");
            foreach (T? Col in Values)
                Console.Write("{0}\t", State(Col));
            Console.WriteLine();

            foreach (T? Row in Values)
            {
                Console.Write("{0}\t", State(Row));
                foreach (T? Col in Values)
                {
                    Console.Write("{0}\t", State(Operator(Row, Col)));
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        static string State<T>(T? NullableValue) where T : struct
        {
            return NullableValue.HasValue
                ? NullableValue.Value.ToString()
                : "null";
        }

    }
}
