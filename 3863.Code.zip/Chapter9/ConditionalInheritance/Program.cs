// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#define FOO

using System;
using System.Diagnostics;

namespace ConditionalInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            new Derived().Foo();
            Console.ReadLine();
        }
    }
}
