// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;
using System.Diagnostics;

namespace ConditionalAttributes
{
    [AttributeUsage(AttributeTargets.Class), Conditional("DECORATE"), Conditional("FRED")]
    public class DecorationAttribute : Attribute { }

    class Program
    {
        static void Main(string[] args)
        {
            Report(typeof(Alpha));
            Report(typeof(Beta));
            Console.ReadLine();
        }

        static void Report(Type T)
        {
            Console.WriteLine("Type '{0}' {1} the [Decoration] attribute",
                T.Name,
                T.IsDefined(typeof(DecorationAttribute), false)
                    ? "has"
                    : "does not have"
            );
        }
    }
}
