// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Reflection;

[assembly: CLSCompliant(true)]

namespace attributes
{
	class JonAttribute: System.Attribute
	{
		public int Age
		{
			get	{	return age;		}
			set	{	age = value;	Console.WriteLine("public int Age");}
		}
		private int age = 45;

		public JonAttribute()
		{}
		public JonAttribute(int age)
		{
			Console.WriteLine("public JonAttribute(int age)");
			this.age = age;
		}
	}


	[System.Flags(), Jon(25, Age = 47)] public enum Colors {Red, [Jon] Green, Blue}

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Type ColorsType = typeof(Colors);
			object[] Attributes = ColorsType.GetCustomAttributes(typeof(JonAttribute), false);
			Console.WriteLine("{0} attribute{1}", Attributes.Length, Attributes.Length != 1 ? "s" : "");

			JonAttribute Fred = (JonAttribute) Attributes[0];
			Console.WriteLine(Fred.Age);
	
			Fred.Age = 45;
			Console.WriteLine(Fred.Age);
			Fred = null;

			Fred = (JonAttribute) ColorsType.GetCustomAttributes(typeof(JonAttribute), false)[0];
			Console.WriteLine(Fred.Age);

			Console.ReadLine();

			//
			// TODO: Add code to start application here
			//
		}
	}
}

