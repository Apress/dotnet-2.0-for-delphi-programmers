// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#define CONDITIONAL_

/// When CONDITIONAL is #defined-ed, this exe needs "ConditionalLibrary.dll".
/// The exe won't run if you copy the exe to a directory without "ConditionalLibrary.dll"
/// (or if you delete the "ConditionalLibrary.dll" from the binary directory.)
/// 
/// When CONDITIONAL is not #defined-ed, this exe can be copied to a directory 
/// without "ConditionalLibrary.dll" and will run just fine.

using System;
using ConditionalLibrary;

namespace Conditional
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			ConditionalClass.Method(); // Only if CONDITIONAL is #defined.
			Console.WriteLine("OK");
			Console.ReadLine();
		}
	}
}

