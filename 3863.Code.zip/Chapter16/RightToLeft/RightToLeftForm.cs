// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using Shemitz.Drawing;

namespace RightToLeft
{
    public partial class RightToLeftForm : Form
    {
        public RightToLeftForm()
        {
            InitializeComponent();
        }

        private void RightToLeftForm_Layout(object sender, LayoutEventArgs e)
        {
            Bitmap Background = new Bitmap(ClientSize.Width, ClientSize.Height);
            using (Graphics G = Graphics.FromImage(Background))
            using (Brush Gradient = new LinearGradientBrush(ClientRectangle, Color.White, Color.LightBlue, LinearGradientMode.ForwardDiagonal))
                G.FillRectangle(Gradient, ClientRectangle);
            BackgroundImage = Background;
        }

        private const string LoremIpsum = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

        private void RightToLeftForm_Paint(object sender, PaintEventArgs e)
        {
            using (Font Tahoma9 = new Font("Tahoma", 9))
            using (StringFormat RightToLeft = new StringFormat(StringFormatFlags.DirectionRightToLeft))
            {
                int ClientWidth = ClientSize.Width;

                // Unwrapped, point form
                e.Graphics.DrawString(LoremIpsum, Tahoma9, Brushes.Black, 8, 8);
                e.Graphics.DrawString(LoremIpsum, Tahoma9, Brushes.Black, ClientWidth - 8, 24, RightToLeft);

                // Wrapped, rectangle form
                RectangleF Box = new RectangleF(8, 40, ClientWidth - 16, 80);
                e.Graphics.DrawString(LoremIpsum, Tahoma9, Brushes.Black, Box);

                Box.Offset(0, Box.Height + 16);
                Color TranslucentWhite = Color.FromArgb(96, Color.White); // Change.SetAlpha(Color.White, 96);
                using (Brush TranslucentBrush = new SolidBrush(TranslucentWhite))
                    e.Graphics.FillRectangle(TranslucentBrush, Box);
                e.Graphics.DrawString(LoremIpsum, Tahoma9, Brushes.Black, Box, RightToLeft);
            }
        }
    }
}