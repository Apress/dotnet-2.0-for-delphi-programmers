using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Gradients
{
    public partial class GradientExplorerForm : Form
    {
        public GradientExplorerForm()
        {
            InitializeComponent();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
        }
    }
}