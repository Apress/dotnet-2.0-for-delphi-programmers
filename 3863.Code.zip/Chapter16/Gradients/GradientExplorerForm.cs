// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shemitz.Drawing;

namespace Gradients
{
    public partial class GradientExplorerForm : Form
    {
        public GradientExplorerForm()
        {
            InitializeComponent();
        }

        private string TextPattern;

        private void GradientExplorerForm_Load(object sender, EventArgs e)
        {
            TextPattern = this.Text; // "Gradient Explorer - {0} to {1}"
            StopColor = Change.SetBrightness(StartColor, 0.9f);
        }

        private Color _StartColor = Color.LightSeaGreen;
        private Color _StopColor = Color.Transparent;// = Color.SeaGreen;

        private Color StartColor
        {
            get { return _StartColor; }
            set { _StartColor = value; CreateGradient(); }
        }

        private Color StopColor
        {
            get { return _StopColor; }
            set { _StopColor = value; CreateGradient(); }
        }

        private void CreateGradient()
        {
            if (StopColor == Color.Transparent)
                return;

            int StartRGB = StartColor.ToArgb() & 0x00FFFFFF,
                StopRGB = StopColor.ToArgb() & 0x00FFFFFF;
            Text = String.Format(TextPattern, StartRGB, StopRGB);

            BackgroundImage = Gradient.Rectangle(ClientRectangle, StartColor, StopColor);
        }

        private PointF ClickPoint = Point.Empty;

        private void GradientExplorerForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                ClickPoint = new PointF(e.X, e.Y);
            else
                ClickPoint = PointF.Empty;
        }

        private void GradientExplorerForm_Click(object sender, EventArgs e)
        {
            bool TopLeft = InTopLeft(ClickPoint);
            
            colorDialog1.Color = TopLeft ? StartColor : StopColor;
            colorDialog1.FullOpen = true;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
                if (TopLeft)
                    StartColor = colorDialog1.Color;
                else
                    StopColor = colorDialog1.Color;
        }

        /// <summary>
        /// Is point P above the diagonal from bottom left to top right?
        /// </summary>
        private bool InTopLeft(PointF P)
        {
            Size Client = this.ClientSize;
            return P.Y / Client.Height < 1 - P.X / Client.Width;
        }

        private void GradientExplorerForm_Layout(object sender, LayoutEventArgs e)
        {
            CreateGradient();
        }
    }
}