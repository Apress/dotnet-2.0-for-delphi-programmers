// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace OutlineText
{
    public partial class OutlineTextForm : Form
    {
        public OutlineTextForm()
        {
            InitializeComponent();
        }

        private void OutlineTextForm_Paint(object sender, PaintEventArgs e)
        {
            using (GraphicsPath Path = new GraphicsPath())
            {
                using (FontFamily GenericSerif = FontFamily.GenericSerif)
                {
                    #region First string

                    const string FirstString = "Outlined text";
                    Path.AddString(FirstString, GenericSerif, (int) FontStyle.Regular, 64, new Point(10, 10), StringFormat.GenericDefault);

                    e.Graphics.DrawPath(Pens.Black, Path);

                    // Reset path - remove first string
                    Path.Reset();

                    #endregion First string

                    #region Second string

                    const string SecondString = "Filled & outlined text";
                    Point SecondPoint = new Point(10, 80);
                    Path.AddString(SecondString, GenericSerif, (int)FontStyle.Regular, 64, SecondPoint, StringFormat.GenericDefault);
                   
                    #region Measure the string, to build gradient brushes that fill it neatly
                    Size Extent;
                    using (Font Serif = new Font(GenericSerif, 64))
                        Extent = e.Graphics.MeasureString(SecondString, Serif).ToSize();
                    Rectangle Bounds = new Rectangle(SecondPoint, Extent);
                    #endregion Measure the string

                    using (Brush
                        InteriorBrush = new LinearGradientBrush(Bounds, Color.Yellow, Color.Red, LinearGradientMode.Vertical),
                        ExteriorBrush = new LinearGradientBrush(Bounds, Color.Red, Color.Yellow, LinearGradientMode.Vertical))
                    {
                        e.Graphics.FillPath(InteriorBrush, Path);
                        using (Pen Outline = new Pen(ExteriorBrush))
                            e.Graphics.DrawPath(Outline, Path);
                    }

                    // Reset path - remove second string
                    Path.Reset();

                    #endregion Second string

                    #region Third string

                    const string ThirdString = "Filled text";
                    Point ThirdPoint = new Point(10, 150);
                    Path.AddString(ThirdString, GenericSerif, (int)FontStyle.Regular, 64, ThirdPoint, StringFormat.GenericDefault);

                    #region Measure the string, to build gradient brushes that fill it neatly
                    Size ThirdExtent;
                    using (Font Serif = new Font(GenericSerif, 64))
                        ThirdExtent = e.Graphics.MeasureString(ThirdString, Serif).ToSize();
                    Rectangle ThirdBounds = new Rectangle(ThirdPoint, ThirdExtent);
                    #endregion Measure the string

                    using (Brush
                        InteriorBrush = new LinearGradientBrush(ThirdBounds, Color.Plum, Color.SeaShell, LinearGradientMode.Vertical))//,
                        //ExteriorBrush = new LinearGradientBrush(Bounds, Color.Red, Color.Yellow, LinearGradientMode.Vertical))
                    {
                        e.Graphics.FillPath(InteriorBrush, Path);
                        //using (Pen Outline = new Pen(ExteriorBrush))
                        //    e.Graphics.DrawPath(Outline, Path);
                    }

                    // Reset path - remove second string
                    Path.Reset();

                    #endregion Second string
                }
            }
        }
    }
}