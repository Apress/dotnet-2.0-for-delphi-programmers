// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AlphaTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

private void Form1_Load(object sender, EventArgs e)
{
    using (Bitmap SmallBitmap = new Bitmap(1, 1))
    using (Brush
        OpaqueBrush = new SolidBrush(Color.FromArgb(unchecked((int)0xFF4080C0))),
        TranslucentBrush = new SolidBrush(Color.FromArgb(0x40506070)))
    using (Graphics SmallGraphics = Graphics.FromImage(SmallBitmap))
    {
        SmallGraphics.FillRectangle(OpaqueBrush, 0, 0, 1, 1);
        Color First = SmallBitmap.GetPixel(0, 0);
        SmallGraphics.FillRectangle(TranslucentBrush, 0, 0, 1, 1);
        Color Second = SmallBitmap.GetPixel(0, 0);

        ResultLabel.Text = String.Format("0x{0:X6} -> 0x{1:X6}", First.ToArgb(), Second.ToArgb());
    }
}
    }
}