// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Shemitz.Drawing;
using System.Drawing.Drawing2D;

namespace CornerGradient
{
    public partial class CornerGradientForm : Form
    {
        public CornerGradientForm()
        {
            InitializeComponent();
        }

        private void CornerGradientForm_Paint(object sender, PaintEventArgs e)
        {
            Color Outside = Color.LightSeaGreen;
            Color Inside = Change.SetBrightness(Outside, 0.9f);

            Rectangle LeftRectangle = new Rectangle(10, 26, 16, 100);
            Rectangle TopRectangle = new Rectangle(26, 10, 100, 16);
            Rectangle CornerRectangle = new Rectangle(10, 10, 33, 33);

            using (Brush LeftBrush = Gradient.Brush(LeftRectangle, Outside, Inside, LinearGradientMode.Horizontal))
                e.Graphics.FillRectangle(LeftBrush, LeftRectangle);
            using (Brush TopBrush = Gradient.Brush(TopRectangle, Outside, Inside, LinearGradientMode.Vertical))
                e.Graphics.FillRectangle(TopBrush, TopRectangle);

            using (GraphicsPath CornerPath = new GraphicsPath())
            {
                CornerPath.AddPie(CornerRectangle, -90f, -90f);
                using (PathGradientBrush CornerBrush = new PathGradientBrush(CornerPath))
                {
                    CornerBrush.SurroundColors = new Color[] { Outside };
                    CornerBrush.CenterColor = Inside;
                    CornerBrush.CenterPoint = new PointF(26, 26);

                    e.Graphics.FillPie(CornerBrush, CornerRectangle, -90f, -90f);
                }
            }

        }
    }
}