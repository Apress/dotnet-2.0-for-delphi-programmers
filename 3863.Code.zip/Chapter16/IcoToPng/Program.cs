// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Drawing;

namespace IcoToPng
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (string S in args)
                ProcessFilemask(S);
        }

        static void ProcessFilemask(string Pathname)
        {
            string PathPart = Path.GetDirectoryName(Pathname),
                Filepart = Path.GetFileName(Pathname);
            foreach (string Filename in Directory.GetFiles(PathPart, Filepart))
                ProcessIcoFile(Filename);
        }

        private static void ProcessIcoFile(string Filename)
        {
            using (Icon Original = new Icon(Filename))
            using (Bitmap PngBitmap = new Bitmap(Original.Width, Original.Height))
            {
                using (Graphics Png = Graphics.FromImage(PngBitmap))
                    Png.DrawIcon(Original, 0, 0);
                string NewFilename = Path.ChangeExtension(Filename, ".png");
                PngBitmap.Save(NewFilename);
                Console.WriteLine(NewFilename);
            }
        }
    }
}
