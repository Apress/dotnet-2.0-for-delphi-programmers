using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NaiveRotation
{
    public partial class NaiveRotationForm : Form
    {
        public NaiveRotationForm()
        {
            InitializeComponent();
        }
    }
}