// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace HatchBrushes
{
    public partial class HatchBrushes : Form
    {
        public HatchBrushes()
        {
            InitializeComponent();
        }

        private int[] HatchStyles;

        private void HatchBrushes_Load(object sender, EventArgs e)
        {
            Dictionary<int, HatchStyle> Styles = new Dictionary<int, HatchStyle>();
            foreach (HatchStyle Style in Enum.GetValues(typeof(HatchStyle)))
            {
                if (! Styles.ContainsKey((int) Style))
                    Styles[(int) Style] = Style;
            }
            HatchStyles = new int[Styles.Keys.Count];
            Styles.Keys.CopyTo(HatchStyles, 0);
            Array.Sort(HatchStyles);

            Text = String.Format("{0} unique hatch styles", HatchStyles.Length);
        }

        private void HatchBrushes_Layout(object sender, LayoutEventArgs e)
        {
            Invalidate();
        }

        private void HatchBrushes_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.FillRectangle(Brushes.White, ClientRectangle);

            const int Columns = 9;
            int Rows = (HatchStyles.Length + Columns - 1) / Columns;

            int LastColumn = Columns - 1;
            int LastRow = Rows - 1;

            Size Client = ClientSize;
            Size Cell = new Size(Client.Width / Columns, Client.Height / Rows);
            
            int Row = 0, Index = 0;
            do
            {
                for (int Col = 0; Col < Columns; Col++)
                {
                    using (HatchBrush Hatch = new HatchBrush((HatchStyle)HatchStyles[Index], Color.White, Color.Black))
                    {
                        int Width = (Col < LastColumn) 
                            ? Cell.Width 
                            : Client.Width - Cell.Width * LastColumn;
                        int Height = (Row < LastRow)
                            ? Cell.Height
                            : Client.Height - Cell.Height * LastRow;
                        e.Graphics.FillRectangle(Hatch, Col * Cell.Width, Row * Cell.Height, Width, Height);
                    }

                    if (++Index >= HatchStyles.Length)
                        break;
                }
                Row++;
            } while (Index < HatchStyles.Length);
        }
    }
}