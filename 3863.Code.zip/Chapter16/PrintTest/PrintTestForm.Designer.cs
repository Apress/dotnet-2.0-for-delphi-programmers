namespace HitTesting
{
    partial class PrintTestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrintTestForm));
            this.DoubleClickLabel = new System.Windows.Forms.Label();
            this.Printer = new System.Drawing.Printing.PrintDocument();
            this.PrintPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.PrintSetup = new System.Windows.Forms.PrintDialog();
            this.SuspendLayout();
            // 
            // DoubleClickLabel
            // 
            this.DoubleClickLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.DoubleClickLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DoubleClickLabel.Location = new System.Drawing.Point(0, 213);
            this.DoubleClickLabel.Name = "DoubleClickLabel";
            this.DoubleClickLabel.Size = new System.Drawing.Size(279, 13);
            this.DoubleClickLabel.TabIndex = 0;
            this.DoubleClickLabel.Text = "Double click to print";
            // 
            // Printer
            // 
            this.Printer.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.Printer_PrintPage);
            // 
            // PrintPreview
            // 
            this.PrintPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.PrintPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.PrintPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.PrintPreview.Document = this.Printer;
            this.PrintPreview.Enabled = true;
            this.PrintPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("PrintPreview.Icon")));
            this.PrintPreview.Name = "PrintPreview";
            this.PrintPreview.Visible = false;
            // 
            // PrintSetup
            // 
            this.PrintSetup.Document = this.Printer;
            this.PrintSetup.ShowNetwork = false;
            // 
            // PrintTestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 226);
            this.Controls.Add(this.DoubleClickLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "PrintTestForm";
            this.Text = "Print Testing";
            this.Load += new System.EventHandler(this.HitTestingForm_Load);
            this.DoubleClick += new System.EventHandler(this.PrintTestForm_DoubleClick);
            this.Layout += new System.Windows.Forms.LayoutEventHandler(this.HitTestingForm_Layout);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label DoubleClickLabel;
        private System.Drawing.Printing.PrintDocument Printer;
        private System.Windows.Forms.PrintPreviewDialog PrintPreview;
        private System.Windows.Forms.PrintDialog PrintSetup;
    }
}

