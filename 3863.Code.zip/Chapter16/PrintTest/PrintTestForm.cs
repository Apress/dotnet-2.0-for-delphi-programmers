// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shemitz.Drawing;
using System.Drawing.Drawing2D;

namespace HitTesting
{
    public partial class PrintTestForm : Form
    {
        public PrintTestForm()
        {
            InitializeComponent();
        }

        private Rectangle RectangleBounds = new Rectangle(40, 40, 200, 128);
        private Rectangle EllipseBounds = new Rectangle(60, 30, 150, 100);

        private GraphicsPath EllipsePath;

        private void HitTestingForm_Load(object sender, EventArgs e)
        {
            EllipsePath = new GraphicsPath();
            EllipsePath.AddEllipse(EllipseBounds);
        }

        private void HitTestingForm_Layout(object sender, LayoutEventArgs e)
        {
            if (ClientRectangle.Height <= 0 || ClientRectangle.Width <= 0) // MSVDM can cause this ....
                return; 

            // Initialize
            Bitmap BackgroundImage = Gradient.Rectangle(ClientRectangle, 0.98f, Color.LightSkyBlue);
            
            // Draw ellipse and rectangle
            using (Graphics Background = Graphics.FromImage(BackgroundImage))
            {
                using (Brush RectangleBrush = Gradient.Brush(RectangleBounds, Color.OrangeRed, 0.96f))
                    Background.FillRectangle(RectangleBrush, RectangleBounds);
                using (PathGradientBrush EllipseBrush = new PathGradientBrush(EllipsePath))
                {
                    Color EllipseColor = Color.LightSeaGreen;

                    EllipseBrush.CenterPoint = new PointF(
                        EllipseBounds.Left + EllipseBounds.Width * 2f / 3,
                        EllipseBounds.Top + EllipseBounds.Height * 1f / 3 );
                    EllipseBrush.CenterColor = Change.SetBrightness(EllipseColor, 0.98f);
                    EllipseBrush.SurroundColors = new Color[] { EllipseColor };

                    Background.FillEllipse(EllipseBrush, EllipseBounds);
                }
            }
            
            // Set it
            this.BackgroundImage = BackgroundImage;
        }

        private void PrintTestForm_DoubleClick(object sender, EventArgs e)
        {
            if (PrintSetup.ShowDialog() == DialogResult.OK)
                PrintPreview.ShowDialog();
        }

        private void Printer_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.PageUnit = GraphicsUnit.Inch;
            e.Graphics.DrawImage(BackgroundImage, 1.5f, 1.5f);
            e.HasMorePages = false;
        }
    }
}