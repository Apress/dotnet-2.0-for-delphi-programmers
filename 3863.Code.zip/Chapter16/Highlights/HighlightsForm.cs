// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

using Shemitz.Drawing;

namespace Highlights
{
    public partial class HighlightsForm : Form
    {
        public HighlightsForm()
        {
            InitializeComponent();
        }

        private void HighlightsForm_Layout(object sender, LayoutEventArgs e)
        {

            Rectangle Client = ClientRectangle;
            Bitmap BackgroundImage = Gradient.Rectangle(Client, 0.80f, Color.LightSeaGreen);

            Color StartStripe = Color.White;
            Color StopStripe = Change.SetBrightness(StartStripe, 0.85f);
            StartStripe = Change.SetAlpha(StartStripe, 222);
            StopStripe = Change.SetAlpha(StopStripe, 200);

            using (Brush B = Gradient.Brush(Client, StartStripe, StopStripe))
            using (Pen P = new Pen(B))
            using (Graphics BackgroundGraphics = Graphics.FromImage(BackgroundImage))
                for (int Index = 0, Step = 5; Index < Client.Height; Index += Step++)
                    BackgroundGraphics.DrawLine(P, Client.Left, Index, Client.Right, Index);
            this.BackgroundImage = BackgroundImage;
        }

        private void HighlightsForm_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.CompositingMode = CompositingMode.SourceCopy;
            using (GraphicsPath HighlightPath = new GraphicsPath())
            {
                #region Fully manual

                HighlightPath.AddEllipse(16, 16, 48, 48);
                using (PathGradientBrush HighlightBrush = new PathGradientBrush(HighlightPath))
                {
                    HighlightBrush.CenterPoint = new PointF(25, 25);
                    HighlightBrush.CenterColor = Color.PaleTurquoise;
                    HighlightBrush.SurroundColors = new Color[] { Color.Turquoise };

                    e.Graphics.FillEllipse(HighlightBrush, 16, 16, 48, 48);

                }
                #endregion Fully manual

                #region Semi-automatic

                DrawHighlight(e.Graphics, new Rectangle(16, 123, 164, 164),
                    SetAlpha(Color.Turquoise, 0.33f), //new PointF(0.6f, -0.6f), 1f,
                    OutlineEllipse, FillEllipse, DrawEllipse);

                DrawHighlight(e.Graphics, new Rectangle(200, 123, 164, 164),
                    SetAlpha(Color.Turquoise, 0.66f), //new PointF(-0.6f, -0.65f), 1f,
                    OutlineEllipse, FillEllipse, null);//DrawEllipse);

                DrawHighlight(e.Graphics, new Rectangle(400, 123, 164, 164),
                    Color.Turquoise, new PointF(-0.6f, -0.6f), 0.995f,
                    OutlineEllipse, FillEllipse, null);//DrawEllipse);

                DrawHighlight(e.Graphics, new Rectangle(69, 69, 128, 32),
                    SetAlpha(Color.Red, 0.5f), //new PointF(-0.25f, -0.25f), 1f,
                    OutlineEllipse, FillEllipse, DrawEllipse);

                //DrawHighlight(e.Graphics, new Rectangle(275, 69, 48, 32),
                //    SetAlpha(Color.Red, 0.75f), //new PointF(-0.25f, -0.25f), 1f,
                //    OutlineRectangle, FillRectangle, DrawRectangle);

                DrawHighlight(e.Graphics, new Rectangle(100, 10, 24, 24),
                    Color.SeaGreen, //new PointF(-0.75f, -0.25f), 1f,
                    OutlineEllipse, FillEllipse, DrawEllipse);

                DrawHighlight(e.Graphics, new Rectangle(140, 10, 24, 24),
                    Color.Turquoise, //new PointF(-0.75f, -0.25f), 1f,
                    OutlineEllipse, FillEllipse, DrawEllipse);

                for (int I = 0; I < 7; I++)
                DrawHighlight(e.Graphics, new Rectangle(180 + I * 64, 10, 48, 48),
                    SetAlpha(Color.Orange, (I+1)/7f),//new PointF(-0.375f, -0.375f), 1f,
                    OutlineEllipse, FillEllipse); //DrawEllipse);

                #endregion Semi-automatic
            }
        }

        private static void DrawHighlight(Graphics G, Rectangle R,
            Color C, 
            DrawOutline Trace, FillPath Fill)
        {
            DrawHighlight(G, R, C, new PointF(-0.6f, -0.6f), 0.875f, Trace, Fill, null);
        }

        private static void DrawHighlight(Graphics G, Rectangle R,
            Color C,
            DrawOutline Trace, FillPath Fill, DrawPath Outline)
        {
            DrawHighlight(G, R, C, new PointF(-0.6f, -0.6f), 0.9f, Trace, Fill, Outline);
        }

        //TODO: really should calculate highlight point from light source ....
        private static void DrawHighlight(Graphics G, Rectangle R, 
            Color C, PointF Highlight, float HighlightRatio,
            DrawOutline Trace, FillPath Fill, DrawPath Outline)
        {
            using (GraphicsPath HighlightPath = new GraphicsPath())
            {
                Trace(HighlightPath, R);
                using (PathGradientBrush HighlightBrush = new PathGradientBrush(HighlightPath))
                {
                    #region Setup HighlightBrush

                    HighlightBrush.CenterPoint = new PointF(
                        HighlightCoordinate(R.Left, R.Right, Highlight.X),
                        HighlightCoordinate(R.Top, R.Bottom, Highlight.Y)
                        );
                    
                    //HighlightBrush.CenterColor = RGBHSL.SetBrightness(C, HighlightRatio);
                    //HighlightBrush.CenterColor = SetAlpha(RGBHSL.SetBrightness(C, HighlightRatio), C.A);
                    Color CenterColor = Change.SetBrightness(C, HighlightRatio);
                    HighlightBrush.CenterColor = Change.SetAlpha(CenterColor, C.A);

                    HighlightBrush.SurroundColors = new Color[] { C };

                    #endregion Setup HighlightBrush

                    Fill(G, HighlightBrush, R);
                    if (Outline != null)
                        using (Pen P = new Pen(C))
                            Outline(G, P, R);
                }
            }
        }

        private static float HighlightCoordinate(float Low, float High, float CenterOffset)
        {
            float
                Middle = (Low + High) / 2,
                Delta = (High - Low) / 2;
            return Middle + Delta * CenterOffset;
        }


        #region Standard shapes

        // Ellipses

        private static DrawOutline OutlineEllipse = (DrawOutline)delegate(GraphicsPath Path, Rectangle Bounds)
        {
            Path.AddEllipse(Bounds);
        };

        private static DrawPath DrawEllipse = (DrawPath)delegate(Graphics G, Pen OutlinePen, Rectangle Bounds)
        {
            G.DrawEllipse(OutlinePen, Bounds);
        };

        private static FillPath FillEllipse = (FillPath)delegate(Graphics G, Brush HighlightBrush, Rectangle Bounds)
        {
            G.FillEllipse(HighlightBrush, Bounds);
            //using (Pen Brushed = new Pen(HighlightBrush))
            //    G.DrawEllipse(Brushed, Bounds);
        };

        // Rectangles

        private static DrawOutline OutlineRectangle = (DrawOutline)delegate(GraphicsPath Path, Rectangle Bounds)
        {
            Path.AddRectangle(Bounds);
        };

        private static DrawPath DrawRectangle = (DrawPath)delegate(Graphics G, Pen OutlinePen, Rectangle Bounds)
        {
            G.DrawRectangle(OutlinePen, Bounds);
            //OutlinePen.LineJoin = LineJoin.Round;
            //G.DrawLines(OutlinePen, new Point[] {
            //    Bounds.Location, 
            //    new Point(Bounds.Right, Bounds.Top),
            //    new Point(Bounds.Right, Bounds.Bottom), 
            //    new Point(Bounds.Left, Bounds.Bottom),
            //    Bounds.Location
            //});
        };

        private static FillPath FillRectangle = (FillPath)delegate(Graphics G, Brush HighlightBrush, Rectangle Bounds)
        {
            G.FillRectangle(HighlightBrush, Bounds);
        };

        #endregion Standard shapes

        //public static Color SetAlpha(Color C, int Alpha)
        //{
        //    return Color.FromArgb((Alpha << 24) + (C.ToArgb() & 0x00FFFFFF));
        //}

        public static Color SetAlpha(Color C, float Alpha)
        {
            //return Color.FromArgb(((int)(255 * Alpha) << 24) + (C.ToArgb() & 0x00FFFFFF));

            return Change.SetAlpha(C, (int)(Alpha * 255));
        }

    }

    public delegate void DrawOutline(GraphicsPath Path, Rectangle Bounds);
    public delegate void DrawPath(Graphics G, Pen OutlinePen, Rectangle Bounds);
    public delegate void FillPath(Graphics G, Brush HighlightBrush, Rectangle Bounds);
}

