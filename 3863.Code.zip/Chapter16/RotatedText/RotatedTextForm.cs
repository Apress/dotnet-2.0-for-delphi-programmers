// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Shemitz.Drawing;

namespace RotatedText
{
    public partial class RotatedTextForm : Form
    {
        public RotatedTextForm()
        {
            InitializeComponent();
        }

        private void RotatedTextForm_Paint(object sender, PaintEventArgs e)
        {
            const float Rotation = 45f;// 45 degrees clockwise

            using (Font Tahoma12 = new Font("Tahoma", 12))
            {
                e.Graphics.DrawString("Normal, horizontal text", Tahoma12, Brushes.Black, 10, 10);

                using (StringFormat Format = new StringFormat(StringFormatFlags.DirectionVertical ))
                    e.Graphics.DrawString("Vertical text", Tahoma12, Brushes.Black, 210, 10, Format);
                using (StringFormat Format = new StringFormat(StringFormatFlags.DirectionVertical | StringFormatFlags.DirectionRightToLeft))
                    e.Graphics.DrawString("Vertical text 2", Tahoma12, Brushes.Blue, 210, 10, Format);

                e.Graphics.RotateTransform(Rotation);
e.Graphics.DrawString("Rotated text", Tahoma12, Brushes.Black,
//                    DrawingTools.RotatePoint(25, 50, -Rotation));
    DrawingTools.Untransform(e.Graphics, 25, 50));

                e.Graphics.ResetTransform();
                e.Graphics.RotateTransform(-90); // 90 degrees counter-clockwise
                SizeF MVT = e.Graphics.MeasureString("More vertical text", Tahoma12);
                e.Graphics.DrawString("More vertical text", Tahoma12, Brushes.Black,
//                    DrawingTools.RotatePoint(230, 10 + MVT.Width, 90));
                    DrawingTools.Untransform(e.Graphics, 230, 10 + MVT.Width));
            }
        }

        private void RotatedTextForm_MouseLeave(object sender, EventArgs e)
        {
            ShowMousePosition.Text = "";
        }

        private void RotatedTextForm_MouseMove(object sender, MouseEventArgs e)
        {
            ShowMousePosition.Text = String.Format("({0}, {1})", e.X, e.Y);
        }
    }
}