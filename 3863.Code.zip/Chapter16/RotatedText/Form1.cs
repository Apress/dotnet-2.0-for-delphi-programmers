using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace RotatedText
{
    public partial class RotatedTextForm : Form
    {
        public RotatedTextForm()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            const float Rotation = 45f;

            using (Font Tahoma12 = new Font("Tahoma", 12))
            {
                e.Graphics.DrawString("Normal, horizontal text", Tahoma12, Brushes.Black, 10, 10);
                PointF[] RotatedPoint = new PointF[] { new PointF(25, 35) };
                using (Matrix RotatePoint = new Matrix())
                {
                    RotatePoint.Rotate(-Rotation);
                    RotatePoint.TransformPoints(RotatedPoint);
                }
                e.Graphics.RotateTransform(Rotation);
                e.Graphics.DrawString("Rotated text", Tahoma12, Brushes.Black, RotatedPoint[0]);
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            ShowMousePosition.Text = String.Format("({0}, {1})", e.X, e.Y);
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            ShowMousePosition.Text = "";
        }

        private void Clock_Tick(object sender, EventArgs e)
        {

        }
    }
}