// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace InterpolationColors
{
    public partial class InterpolationColorsForm : Form
    {
        public InterpolationColorsForm()
        {
            InitializeComponent();
        }

        private void InterpolationColorsForm_Paint(object sender, PaintEventArgs e)
        {
            Rectangle ClientRectangle = this.ClientRectangle;
            using (LinearGradientBrush Linear = new LinearGradientBrush(ClientRectangle, Color.White, Color.LightBlue, LinearGradientMode.Horizontal))
            {
                ColorBlend Blend = new ColorBlend(7);
                Blend.Colors = new Color[] { Color.Red, Color.Orange, Color.Yellow, Color.Green, Color.Blue, Color.Indigo, Color.Violet };
                Blend.Positions = new float[] { 0f, 1f/6f, 2f/6f, 3f/6f, 4f/6f, 5f/6f, 1f };
                Linear.InterpolationColors = Blend;

                e.Graphics.FillRectangle(Linear, ClientRectangle);
            }
        }
    }
}