// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using Shemitz.Drawing;

namespace PlusPath
{
    public partial class CompoundShapeForm : Form
    {
        public CompoundShapeForm()
        {
            InitializeComponent();
        }

        private void PlusPathForm_Layout(object sender, LayoutEventArgs e)
        {
            BackgroundImage = Gradient.Rectangle(ClientRectangle, Color.Red, Color.Yellow);
        }

        private void PlusPathForm_Paint(object sender, PaintEventArgs e)
        {
            const int Unit = 24;
            using (GraphicsPath PlusPath = new GraphicsPath(FillMode.Winding))
            {
                PlusPath.AddRectangle(new Rectangle(2 * Unit, 1 * Unit, 1 * Unit, 3 * Unit));
                PlusPath.AddRectangle(new Rectangle(1 * Unit, 2 * Unit, 3 * Unit, 1 * Unit));
                PlusPath.AddEllipse(Unit, Unit, Unit * 2 + 1, Unit * 2);

                using (Brush PlusBrush = Gradient.Brush(Rectangle.Round(PlusPath.GetBounds()), 
                    Color.White, Color.Blue, LinearGradientMode.ForwardDiagonal))
                    e.Graphics.FillPath(PlusBrush, PlusPath);
            }
        }
    }
}