// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shemitz.Drawing;

namespace ColorWheel
{
    public partial class ColorWheelForm : Form
    {
        public ColorWheelForm()
        {
            InitializeComponent();
        }

        private void ColorWheelForm_Layout(object sender, LayoutEventArgs e)
        {
            Rectangle Client = ClientRectangle;
            Point Center = new Point(Client.Width / 2, Client.Height / 2);
            int Radius = Math.Min(Center.X, Center.Y);

            Bitmap BackgroundImage = new Bitmap(Client.Width, Client.Height);
            using (Graphics G = Graphics.FromImage(BackgroundImage))
            {
                G.FillRectangle(Brushes.White, Client);

                #region constants

                const float StartRay = 0.2f; // relative positions of rays and numbers
                const float StopRay  = 0.7f;
                const float Angles   = 0.9f;

                const float Brightness = 0.5f; // == Color.Red.GetBrightness(); // 1 == white, 0 == black ...

                const int LinesPerDegree = 10; // higher numbers are slower; lower numbers give artifacts at large sizes

                #endregion constants

                #region Wheel

                for (int Angle = 0; Angle < 360 * LinesPerDegree; Angle++)
                {
                    float Radians = Angle * (float)Math.PI / (180f * LinesPerDegree);
                    Color ThisColor = HSB.ToColor(Angle / (float)LinesPerDegree, 1, Brightness);
                    using (Pen P = new Pen(ThisColor))
                    {
                        PointF Unit = new PointF(Radius * (float) Math.Cos(Radians),
                            Radius * -(float)Math.Sin(Radians));
                        PointF Inner = new PointF(Unit.X * StartRay + Center.X, Unit.Y * StartRay + Center.Y);
                        PointF Outer = new PointF(Unit.X * StopRay + Center.X, Unit.Y * StopRay + Center.Y);

                        G.DrawLine(P, Inner, Outer);
                    }
                }

                #endregion Wheel

                #region Labels

                float LabelOffset = Radius * Angles;
                for (int Angle = 0; Angle < 360; Angle += 30)
                {
                    float Radians = Angle * (float)Math.PI / 180f;
                    PointF LabelPos = new PointF(LabelOffset * (float)Math.Cos(Radians) + Center.X,
                        LabelOffset * -(float)Math.Sin(Radians) + Center.Y);

                    G.DrawString(Angle.ToString(), this.Font, Brushes.Black, LabelPos);
                }

                #endregion Labels
            }
            this.BackgroundImage = BackgroundImage;
        }
    }
}