// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections;

// A C# version of the very contrived Chapter2\NestedClasses Delphi project

namespace NestedClasses
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			foreach (int I in new Outer())
				Console.Write("{0} ", I);
			Console.ReadLine();
		}
	}

	class Outer: IEnumerable
	{
		private int[] Data;
		public Outer(): this(11)
		{}

		public Outer(int Length)
		{
			Data = new int[Length];
			for (int I = 0; I < Data.Length; I++)
				Data[I] = I + 1;
		}

		public IEnumerator GetEnumerator()
		{
			return new Inner(this);
		}

		private class Inner: IEnumerator
		{
			private Outer Owner;
			private int Index;

			public Inner(Outer Owner)
			{
				this.Owner = Owner;
				Reset();
			}

			public void Reset()
			{
				Index = -1;
			}

			public object Current
			{
				get	{	return Owner.Data[Index];	}
			}

			public bool MoveNext()
			{
				return ++Index < Owner.Data.Length;
			}
		}
	}
}
