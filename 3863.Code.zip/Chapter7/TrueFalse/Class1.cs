// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace TrueFalse
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			Operators True = new Operators("True", 1), False = new Operators("False", 0);
			Console.WriteLine("if (True)");
			if (True)
				Console.WriteLine("True");
			Console.WriteLine("if (True || False)");
			if (True || False)
				Console.WriteLine("True || False");
			Console.WriteLine("if (True && False)");
			if (True && False)
				Console.WriteLine("True && False");
			Console.ReadLine();
		}
	}

	struct Operators
	{
		private const int DefaultValue = 0;
		private int Value;
		private string Identity;
		
		public Operators(string Identity): this(Identity, DefaultValue)
		{}
		
		public Operators(string Identity, int Value)
		{
			this.Value = Value;
			this.Identity = Identity;
		}

		public static implicit operator bool(Operators Op)
		{
			Console.WriteLine("{0}: operator bool", Op.Identity);
			return Op.Value != 0;
		}

		public static bool operator true(Operators Op)
		{
			Console.WriteLine("{0}: operator true", Op.Identity);
			return Op.Value != 0;
		}

		public static bool operator false(Operators Op)
		{
			Console.WriteLine("{0}: operator false", Op.Identity);
			return Op.Value == 0;
		}

		public static Operators operator & (Operators Left, Operators Right)
		{
			Console.WriteLine("{0} & {1}", Left.Identity, Right.Identity);
			return new Operators("(" + Left.Identity + "&" + Right.Identity + ")", Left.Value & Right.Value);
		}

		public static Operators operator | (Operators Left, Operators Right)
		{
			Console.WriteLine("{0} | {1}", Left.Identity, Right.Identity);
			return new Operators("(" + Left.Identity + "|" + Right.Identity + ")", Left.Value | Right.Value);
		}
	}
}
