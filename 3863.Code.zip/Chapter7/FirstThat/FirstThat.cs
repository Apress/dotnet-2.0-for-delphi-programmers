// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary2
{
    public delegate bool Predicate<T>(T Argument);
    public class Class1
    {
        public static int FirstThat<T>(Predicate<T> Test, params T[] Data)
        {
            for (int I = 0; I < Data.Length; I++)
                if (Test(Data[I]))
                    return I;
            // else
            return -1;
        }

        private static bool Positive(int Value)
        {
            return Value > 0;
        }

        private static bool NeverTrue<T>(T Value) 
        { 
            return false; 
        }

        public static int FirstPositive(params int[] Data)
        {
            int FirstTry = FirstThat<int>(NeverTrue<int>, Data);
            return FirstTry >= 0
                ? FirstTry
                : FirstThat<int>(Positive, Data);
        }
    }
}
