// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Diagnostics;

using Shemitz.Utilities;

namespace Shemitz.XML
{
    public enum SortOrder { Ascending, Descending };
    public enum DataType { Alphabetic, Numeric };

    // This would be an "abstract" class in 1.1
    public static class Xsl
    {
        #region Apply transforms

        /// <summary>
        /// Use the XSL stream to transform the Input stream, writing to the Output stream
        /// </summary>
        /// <param name="Output">Transformed XML</param>
        /// <param name="Input">XML to transform</param>
        /// <param name="XSL">XSL to apply</param>
#if Version1pt1
        public static void ApplyXslt(Stream Output, Stream Input, Stream XSL)
        {
            #region Load the XSL stream into an XslTransform

            XSL.Position = 0;
            XmlReader XslReader = new XmlTextReader(XSL);

            Debug.Assert(XslReader.ReadState == ReadState.Initial);

            XslTransform Xslt = new XslTransform();
            Xslt.Load(XslReader);

            #endregion Load the XSL Stream into an XslTransform

            #region Apply XSL

            Input.Position = Output.Position = 0; // reset both streams, just to be safe

            System.Xml.XPath.XPathDocument InputDocument = new System.Xml.XPath.XPathDocument(Input);
            XmlWriter OutputWriter = new XmlTextWriter(Output, System.Text.Encoding.UTF8);
            // you CAN write to a 'raw Stream', but then you get an 
            // <?xml version="1.0" encoding="utf-8"?> XML header

            Xslt.Transform(InputDocument, null, OutputWriter); // Transform Input according to XSL, placing result in Output 
            OutputWriter.Flush();

            #endregion Apply XSL
        }
#else
        public static void ApplyXslt(Stream Output, Stream Input, Stream XSL)
        {
            #region Load the XSL stream into an XslTransform

            XSL.Position = 0;
            XmlReader XslReader = new XmlTextReader(XSL);

            Debug.Assert(XslReader.ReadState == ReadState.Initial);

#if DEBUG
            XslCompiledTransform Xslt = new XslCompiledTransform(true); // enable debug information
#else
            XslCompiledTransform Xslt = new XslCompiledTransform(false);
#endif
            Xslt.Load(XslReader);

            #endregion Load the XSL Stream into an XslTransform

            #region Apply XSL

            Input.Position = Output.Position = 0; // reset both streams, just to be safe
            Debug.Assert(Output.Length == 0);

            XmlReader InputReader = new XmlTextReader(Input);
            XmlWriter OutputWriter = new XmlTextWriter(Output, System.Text.Encoding.UTF8);

            Xslt.Transform(InputReader, OutputWriter); // Transform Input according to XSL, placing result in Output 
            OutputWriter.Flush();

            #endregion Apply XSL
        }
#endif

        /// <summary>
        /// Use the supplied XSL to transform the Input stream, writing to the Output stream
        /// </summary>
        /// <param name="Output">Transformed XML</param>
        /// <param name="Input">XML to transform</param>
        /// <param name="XSL">XSL to apply</param>
        public static void ApplyXslt(Stream Output, Stream Input, string XSL)
        {
            using (Stream XslStream = StreamTools.FromString(XSL))
                ApplyXslt(Output, Input, XslStream);
        }

        /// <summary>
        /// Use the supplied XSL stream to transform the Input file, writing to the Output file
        /// </summary>
        /// <param name="Output">Name of filename to save transformed XML to</param>
        /// <param name="Input">Filename of XML to transform</param>
        /// <param name="XSL">XSL to apply</param>
        public static void ApplyXslt(string Output, string Input, Stream XSL)
        {
            using (Stream
                OutputStream = new FileStream(Output, FileMode.Create, FileAccess.Write),
                InputStream = new FileStream(Input, FileMode.Open, FileAccess.Read))
                ApplyXslt(OutputStream, InputStream, XSL);
        }

        /// <summary>
        /// Use the supplied XSL stream to transform the Input file, writing to the Output file
        /// </summary>
        /// <param name="Output">Name of filename to save transformed XML to</param>
        /// <param name="Input">Filename of XML to transform</param>
        /// <param name="XSL">XSL to apply</param>
        public static void ApplyXslt(string Output, string Input, string XSL)
        {
            using (Stream
                OutputStream = new FileStream(Output, FileMode.Create, FileAccess.Write),
                InputStream = new FileStream(Input, FileMode.Open, FileAccess.Read),
                XslStream = StreamTools.FromString(XSL))
                ApplyXslt(OutputStream, InputStream, XslStream);
        }

        #endregion Apply transforms

        #region XSLT methods

        // Helper methods that generate SOME xsl: elements - written as needed ....

        // Most XSL statements are XML tags with some attributes and some content.
        // The general pattern here is that there are two overloads for every method:
        // 1)   any attributes are populated from the leading parameters, 
        //      and the content comes from the final string parameter
        // 2)   any attributes are populated from the leading parameters, 
        //      and the content comes from a concatenation of the final params string[] parameter.

        #region xsl:apply-templates

        public static string ApplyTemplates()
        {
            return String.Format("<xsl:apply-templates />");
        }

        public static string ApplyTemplates(string Select)
        {
            return String.Format("<xsl:apply-templates select=\"{0}\"/>", Select);
        }

        public static string ApplyTemplates(string Select, string Content)
        {
            return String.Format("<xsl:apply-templates select=\"{0}\">{1}</xsl:apply-templates>",
                Select, Content);
        }

        public static string ApplyTemplates(string Select, params object[] Contents)
        {
            return ApplyTemplates(Select, String.Concat(Contents));
        }

        #endregion xsl:apply-templates

        #region xsl:call-template

        public static string CallTemplate(string Name)
        {
            return String.Format("<xsl:call-template name=\"{0}\"/>", Name);
        }

        public static string CallTemplate(string Name, string WithParams)
        {
            return String.Format("<xsl:call-template name=\"{0}\">{1}</xsl:call-template>", Name, WithParams);
        }

        public static string CallTemplate(string Name, params object[] WithParams)
        {
            return CallTemplate(Name, String.Concat(WithParams));
        }

        #endregion xsl:call-template

        #region xsl:choose

        public static string Choose(string Terms)
        {
            return String.Format("<xsl:choose>{0}</xsl:choose>", Terms);
        }

        public static string Choose(params object[] Terms)
        {
            return Choose(String.Concat(Terms));
        }

        #endregion xsl:choose

        #region xsl:if

        public static string If(string Test, string Content)
        {
            return String.Format("<xsl:if test=\"{0}\">{1}</xsl:if>", Test, Content);
        }

        public static string If(string Test, params object[] Contents)
        {
            return If(Test, String.Concat(Contents));
        }

        #endregion xsl:if

        #region xsl:otherwise

        public static string Otherwise(string Content)
        {
            return String.Format("<xsl:otherwise>{0}</xsl:otherwise>", Content);
        }

        public static string Otherwise(params object[] Contents)
        {
            return Otherwise(String.Concat(Contents));
        }

        #endregion xsl:otherwise

        #region xsl:param

        /// <summary>
        /// Generate an xsl:param element with no default value
        /// </summary>
        /// <param name="Name">The name= attribute</param>
        public static string Param(string Name)
        {
            return String.Format("<xsl:param name=\"{0}\"/>", Name);
        }

        /// <summary>
        /// Generate an xsl:param element with a default value
        /// </summary>
        /// <param name="Name">The name= attribute</param>
        /// <param name="Select">Is this an empty element with a select= attribute, or a normal element with content and a /xsl:param tag?</param>
        /// <param name="Content">Param value</param>
        public static string Param(string Name, bool Select, string Content)
        {
            string Template = Select
                ? "<xsl:param name=\"{0}\" select=\"{1}\"/>"
                : "<xsl:param name=\"{0}\">{1}</xsl:param>";

            return String.Format(Template, Name, Content);
        }

        /// <summary>
        /// Generate an xsl:param element with a default value
        /// </summary>
        /// <param name="Name">The name= attribute</param>
        /// <param name="Select">Is this an empty element with a select= attribute, or a normal element with content and a /xsl:param tag?</param>
        /// <param name="Contents">Param value</param>
        public static string Param(string Name, bool Select, params object[] Contents)
        {
            return Param(Name, Select, String.Concat(Contents));
        }

        #endregion xsl:param

        #region xsl:sort

        // The xsl:sort element is complex, and I don't implement every possibility

        /// <summary>
        /// Sort by the value of the current node
        /// </summary>
        public static string Sort()
        {
            return "<xsl:sort/>";
        }

        /// <summary>
        /// Sort by the Key value
        /// </summary>
        public static string Sort(string Key)
        {
            return string.Format("<xsl:sort select=\"{0}\"/>", Key);
        }

        /// <summary>
        /// Sort by the Key value
        /// </summary>
        /// <param name="Key">Key to sort by</param>
        /// <param name="Order">ascending/descending</param>
        public static string Sort(string Key, SortOrder Order)
        {
            string OrderString = (Order == SortOrder.Ascending) ? "ascending" : "descending";
            return string.Format("<xsl:sort select=\"{0}\" order=\"{1}\"/>", Key, OrderString);
        }

        /// <summary>
        /// Sort by the Key value
        /// </summary>
        /// <param name="Key">Key to sort by</param>
        /// <param name="Order">ascending/descending</param>
        /// <param name="Type">text/numeric</param>
        public static string Sort(string Key, SortOrder Order, DataType Type)
        {
            string OrderString = (Order == SortOrder.Ascending) ? "ascending" : "descending";
            string TypeString = (Type == DataType.Alphabetic) ? "text" : "number";
            return string.Format("<xsl:sort select=\"{0}\" order=\"{1}\"/ data-type=\"{2}\">", Key, OrderString, TypeString);
        }


        #endregion xsl:sort

        #region xsl:stylesheet

        /// <summary>
        /// Wrap standard XSL stylesheet around 'bare' content
        /// </summary>
        /// <param name="Contents">The actual XSL, minus the xml header line and <stylesheet></stylesheet> boilerplate</param>
        public static string Stylesheet(string Content)
        {
            const string Template = @"<?xml version=""1.0""?><xsl:stylesheet version=""1.0"" xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"">{0}</xsl:stylesheet>";
            return String.Format(Template, Content);
        }

        /// <summary>
        /// Wrap standard XSL stylesheet around an 'element stream'
        /// </summary>
        /// <param name="Contents">A 'stream' of elements containing the actual XSL, 
        /// minus the xml header line and <stylesheet></stylesheet> boilerplate</param>
        public static string Stylesheet(params object[] Contents)
        {
            return Stylesheet(String.Concat(Contents));
        }

        #endregion xsl:stylesheet

        #region xsl:template

        /// <summary>
        /// Generate an xsl:template element
        /// </summary>
        /// <param name="Match">The XML element name to match</param>
        /// <param name="Content">The output to generate on a match</param>
        /// <returns></returns>
        public static string Template(string Match, string Content)
        {
            return String.Format("<xsl:template match=\"{0}\">{1}</xsl:template>", Match, Content);
        }

        /// <summary>
        /// Generate an xsl:template element
        /// </summary>
        /// <param name="Match">The XML element name to match</param>
        /// <param name="Contents">The output to generate on a match</param>
        /// <returns></returns>
        public static string Template(string Match, params object[] Contents)
        {
            return Template(Match, String.Concat(Contents));
        }

        /// <summary>
        /// Generate an xsl:template element
        /// </summary>
        /// <param name="Name">The template name</param>
        /// <param name="Content">The output to generate on a match</param>
        /// <returns></returns>
        public static string NamedTemplate(string Name, string Content)
        {
            return String.Format("<xsl:template name=\"{0}\">{1}</xsl:template>", Name, Content);
        }

        /// <summary>
        /// Generate an xsl:template element
        /// </summary>
        /// <param name="Name">The template name</param>
        /// <param name="Contents">The output to generate on a match</param>
        /// <returns></returns>
        public static string NamedTemplate(string Name, params object[] Contents)
        {
            return NamedTemplate(Name, String.Concat(Contents));
        }

        #endregion xsl:template

        #region xsl:text

        public static string Text(string Value)
        {
            return String.Format("<xsl:text>{0}</xsl:text>", Value);
        }

        public static string Text(string Value, bool DisableOutputEscaping)
        {
            return String.Format("<xsl:text disable-output-escaping=\"{1}\">{0}</xsl:text>", Value, YesNo(DisableOutputEscaping));
        }
        #endregion xsl:text

        #region xsl:value-of

        public static string ValueOf(string Select)
        {
            return String.Format("<xsl:value-of select=\"{0}\"/>", Select);
        }

        public static string ValueOf(string Select, bool DisableOutputEscaping)
        {
            return String.Format("<xsl:value-of select=\"{0}\" disable-output-escaping=\"{1}\"/>",
                Select, YesNo(DisableOutputEscaping));
        }


        #endregion xsl:value-of

        #region xsl:when

        public static string When(string Test, string Content)
        {
            return String.Format("<xsl:when test=\"{0}\">{1}</xsl:when>", Test, Content);
        }

        public static string When(string Test, params object[] Content)
        {
            return When(Test, String.Concat(Content));
        }

        #endregion xsl:when

        #region xsl:with-param

        /// <summary>
        /// Generates an xsl:with-param element
        /// </summary>
        /// <param name="Name">The name= attribute</param>
        /// <param name="Select">Is this an empty element with a select= attribute, or a normal element with content and a /xsl:with-param tag?</param>
        /// <param name="Content">The parameter value</param>
        public static string WithParam(string Name, bool Select, string Content)
        {
            string Template = Select
                ? "<xsl:with-param name=\"{0}\" select=\"{1}\"/>"
                : "<xsl:with-param name=\"{0}\">{1}</xsl:with-param>";

            return String.Format(Template, Name, Content);
        }

        /// <summary>
        /// Generates an xsl:with-param element
        /// </summary>
        /// <param name="Name">The name= attribute</param>
        /// <param name="Select">Is this an empty element with a select= attribute, or a normal element with content and a /xsl:with-param tag?</param>
        /// <param name="Contents">The parameter value</param>
        public static string WithParam(string Name, bool Select, params object[] Contents)
        {
            return WithParam(Name, Select, String.Concat(Contents));
        }

        #endregion xsl:param

        private static string YesNo(bool Value)
        {
            return Value ? "yes" : "no";
        }

        #endregion XSLT methods
    }
}
