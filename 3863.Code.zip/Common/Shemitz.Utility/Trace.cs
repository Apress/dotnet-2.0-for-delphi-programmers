﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Diagnostics;
//using System.Text;

#endregion

namespace Shemitz.Trace
{
    /// <summary>
    /// Console.Write and WriteLine, when DEBUG is defined.
    /// </summary>
    public class Trace
    {
        #region Line
        [Conditional("DEBUG")]
        public static void Line(string S)
        {
            Console.WriteLine(S);
        }

        [Conditional("DEBUG")]
        public static void Line(object O)
        {
            Console.WriteLine(O);
        }

        [Conditional("DEBUG")]
        public static void Line(string S, object O)
        {
            Console.WriteLine(S, O);
        }

        [Conditional("DEBUG")]
        public static void Line(string S, object O, object O2)
        {
            Console.WriteLine(S, O, O2);
        }

        [Conditional("DEBUG")]
        public static void Line(string S, object O, object O2, object O3)
        {
            Console.WriteLine(S, O, O2, O3);
        }

        [Conditional("DEBUG")]
        public static void Line(string S, params object[] O)
        {
            Console.WriteLine(S, O);
        }

        #endregion Line

        #region Write
        [Conditional("DEBUG")]
        public static void Write(string S)
        {
            Console.Write(S);
        }

        [Conditional("DEBUG")]
        public static void Write(object O)
        {
            Console.Write(O);
        }

        [Conditional("DEBUG")]
        public static void Write(string S, object O)
        {
            Console.Write(S, O);
        }

        [Conditional("DEBUG")]
        public static void Write(string S, object O, object O2)
        {
            Console.Write(S, O, O2);
        }

        [Conditional("DEBUG")]
        public static void Write(string S, object O, object O2, object O3)
        {
            Console.Write(S, O, O2, O3);
        }

        [Conditional("DEBUG")]
        public static void Write(string S, params object[] O)
        {
            Console.Write(S, O);
        }

        #endregion Write
    }

}
