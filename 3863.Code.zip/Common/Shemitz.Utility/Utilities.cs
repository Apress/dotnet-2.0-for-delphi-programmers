// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Collections.Generic;

// Utility code for my book

namespace Shemitz.Utilities
{
    #region Benchmarks
    /// <summary>
    /// Time units for the Benchmark class
    /// </summary>
    public enum TimeUnit : int
    {
        /// <summary>
        /// Select most sensible unit - between 1 and 3 digits to left of decimal
        /// </summary>
        Auto = 0,
        /// <summary>
        /// Report elapsed time in seconds
        /// </summary>
        second = 1,
        /// <summary>
        /// Report elapsed time in milliseconds
        /// </summary>
        millisecond = 1000,
        /// <summary>
        /// Report elapsed time in microseconds
        /// </summary>
        microsecond = 1000000,
        /// <summary>
        /// Report elapsed time in nanoseconds
        /// </summary>
        nanosecond = 1000000000
    };

    /// <summary>
    /// A simple benchmark class - use as "using (new Benchmark(string Msg)){}"
    /// </summary>
    public class Benchmark : System.IDisposable
    {
        public double Seconds = -1;

        [System.Runtime.InteropServices.DllImport("KERNEL32")]
        extern private static bool QueryPerformanceCounter(out long PerformanceCount);

        [System.Runtime.InteropServices.DllImport("KERNEL32")]
        extern private static bool QueryPerformanceFrequency(out long Frequency);

        private long StartCount, StopCount;

        private string StopMessage;
        private TimeUnit Unit;

        /// <summary>
        /// Benchmark with no output - useful for jitting test methods and Benchmark code.
        /// </summary>
        public Benchmark()
            : this(null)
        { }

        /// <summary>
        /// Benchmark, using microsecond units
        /// </summary>
        /// <param name="StopMessage">Message to display with elapsed time. null suppresses output.</param>
        public Benchmark(string StopMessage) : this(StopMessage, TimeUnit.Auto) { }

        public Benchmark(string MessagePattern, params object[] Parameters)
            :
            this(String.Format(MessagePattern, Parameters)) { }

        /// <summary>
        /// Benchmark, using arbitrary units
        /// </summary>
        /// <param name="StopMessage">Message to display with elapsed time. null suppresses output.</param>
        /// <param name="Unit">Time unit</param>
        public Benchmark(string StopMessage, TimeUnit Unit)
        {
            this.StopMessage = StopMessage;
            this.Unit = Unit;

            StopCount = -1;
            if (!QueryPerformanceCounter(out StartCount))
                throw new Exception("Couldn't QueryPerformanceCounter()");
        }

        /// <summary>
        /// Reports on elapsed time at end of using(){} clause
        /// </summary>
        public void Dispose()
        {
            QueryPerformanceCounter(out StopCount);

            long Frequency;
            QueryPerformanceFrequency(out Frequency);

            Seconds = (StopCount - StartCount) / (double)Frequency;

            if (StopMessage == null)
                return;

            TimeUnit Scale = Unit;
            if (Unit == TimeUnit.Auto)
            {
                if (Seconds >= 1.0)
                    Scale = TimeUnit.second;
                else if (Seconds >= 1E-3)
                    Scale = TimeUnit.millisecond;
                else if (Seconds >= 1E-6)
                    Scale = TimeUnit.microsecond;
                else Scale = TimeUnit.nanosecond;
            }
            Console.WriteLine("{0}: {1:f2} {2}s.", StopMessage, Seconds * (int)Scale, Scale.ToString());
        }
    }

    /// <summary>
    /// A delegate that takes no parameters and returns no results - excellent for benchmarking fragments. 
    /// Creating a delegate then executing it in the jit Benchmark and the 'real' Benchmark means that all 
    /// code has been jitted before being benchmarked.
    /// </summary>
    public delegate void Method();

    /// <summary>
    /// The Fragment class takes a <see cref="Method">Method</see> delegate and benchmarks it.
    /// </summary>
    /// <remarks>
    /// You should jit both the <see cref="Benchmark">Benchmark</see> class and the Fragment parameter
    /// in setup code - "using (new Benchmark()) Fragment();" or the like
    /// </remarks>
    public static class Fragment
    {
        public static void Timer(string Tag, Method Fragment)
        {
            Timer(Tag, Fragment, 1);
        }

        public static void Timer(string Tag, Method Fragment, int Repetitions)
        {
            if (Repetitions > 1)
                Tag = String.Format("{1}x {0}", Tag, Repetitions);
            // for loop is jitted before using statement executes
            using (new Benchmark(Tag))
                for (int Index = 0; Index < Repetitions; Index++)
                    Fragment();
        }
    }

#endregion Benchmarks

    #region Split class -- Extract delimiter characters for each string in a Split() result
    /// <summary>
    /// Extract delimiter characters for each string in a Split() result
    /// </summary>
    public class Split
    {
        private string original;
        private string[] strings;

        public Split(string value, params char[] Delimiters)
        {
            original = value;
            strings = value.Split(Delimiters);
        }

        public string this[int Index] { get { return strings[Index]; } }

        public int Length { get { return strings.Length; } }

        /// <summary>
        /// The character before the Nth element in the Split array
        /// </summary>
        /// <param name="N">Must be >= 1</param>
        /// <returns>The break char before the Nth Split string</returns>
        public char Before(int N)
        {
            // sum of previous, plus break chars
            return original[SumLengths(N) + N - 1];
        }

        /// <summary>
        /// The character after the Nth element in the Split array
        /// </summary>
        /// <param name="N">Must be at least 0, and less than Split array Length</param>
        /// <returns>The break char after the Nth Split string</returns>
        public char After(int N)
        {
            return original[SumLengths(N + 1) + N];
        }

        private int SumLengths(int N)
        {
            int Result = 0;
            for (int Index = 0; Index < N; Index++)
                Result += strings[Index].Length;
            return Result;
        }
    }
    #endregion Split class -- Extract delimiter characters for each string in a Split() result

    #region TextFile class - map text files to and from strings
    /// <summary>
    /// Read a textfile to a string; write a string to a textfile.
    /// </summary>
    public class TextFile
    {
        #region Read() - Read a text file

        public static string Read(FileStream Stream)
        {
            Stream.Position = 0;
            using (StreamReader Reader = new StreamReader(Stream))
            {
                char[] Text = new char[Stream.Length];
                Reader.Read(Text, 0, (int)Stream.Length);
                return new String(Text);
            }
        }

        public static string Read(FileInfo Info)
        {
            return Read(Info.Open(FileMode.Open, FileAccess.Read, FileShare.Read));
        }

        public static string Read(string FileName)
        {
            using (StreamReader Reader = new StreamReader(FileName))
                return Reader.ReadToEnd();
        }


        #endregion

        #region Write() - Write a text file

        public static void Write(FileStream Stream, string FileText)
        {
            Stream.Position = 0;
            using (StreamWriter Writer = new StreamWriter(Stream))
                Writer.Write(FileText);
        }

        public static void Write(FileInfo Info, string FileText)
        {
            Write(Info.Open(FileMode.Create), FileText);
        }

        public static void Write(string FileName, string FileText)
        {
            // ugly old code ... but it does work ....
            Write(new FileInfo(FileName), FileText);
        }

        public static void Write16(string FileName, string FileText)
        {
            using (StreamWriter Writer = new StreamWriter(FileName, false, Encoding.Unicode))
                Writer.Write(FileText);
        }

        #endregion
    }
    #endregion TextFile class - map text files to and from strings

    #region Nested update locking

    /// <summary>
    /// An 'update lock' class that automatically unlocks. 
    /// Use as "using (new Interlock.Touch(ThisInterlock)) {}"
    /// </summary>
    public class Interlock
    {
        private int lockLevel = 0;

        /// <summary>
        /// Are we in a self-change?
        /// </summary>
        public bool Locked
        {
            get { return lockLevel != 0; }
        }

        /// <summary>
        /// Are we in a self-change?
        /// </summary>
        public bool Set
        {
            get { return Locked; }
        }

        /// <summary>
        /// An IDisposable class that locks on entry and unlocks on exit.
        /// </summary>
        public class Touch : IDisposable
        {

            private Interlock flag;

            public Touch(Interlock Flag)
            {
                flag = Flag;
                flag.lockLevel++;
            }

            #region IDisposable Members

            public void Dispose()
            {
                flag.lockLevel--;
            }

            #endregion
        }
    }

    #endregion Nested update locking

    #region generic singleton
    public static class Unique<T> where T : class, new()
    {
        private static T cache = default(T);
        private static object cacheLock = new object();
        // can't lock cache field (which may be null) - 
        // mustn't lock typeof(T) or typeof(Unique<T>)

        public static T Instance
        {
            get
            {
                lock (cacheLock)
                    if (cache == null)
                        return cache = new T();
                    else
                        return cache;
            }
        }
    }
    #endregion generic singleton

    #region Manifest resources

    public static class EmbeddedResource
    {
        public static Stream GetStream(Assembly Resourceful, string Name)
        {
            string DotName = "." + Name;
            string UniqueQualifiedName = null;
            foreach (string QualifiedName in Resourceful.GetManifestResourceNames())
                if (QualifiedName.EndsWith(DotName))
                {
                    if (UniqueQualifiedName == null)
                        UniqueQualifiedName = QualifiedName;
                    else
                        throw new ArgumentException("Ambiguous resource name", "Name");
                }
            if (UniqueQualifiedName == null)
                throw new ArgumentException("No match", "Name");
            else
                return Resourceful.GetManifestResourceStream(UniqueQualifiedName);
        }

        public static Bitmap GetBitmap(string Name)
        {
            using (Stream S = GetStream(Assembly.GetCallingAssembly(), Name))
                if (S == null)
                    return null;
                else
                {
                    Bitmap FromStream = new Bitmap(S);
                    return new Bitmap(FromStream);
                }
        }

        public static string GetString(string Name)
        {
            using (Stream S = GetStream(Assembly.GetCallingAssembly(), Name))
                if (S == null)
                    return null;
                else
                    using (StreamReader R = new StreamReader(S))
                        return R.ReadToEnd();
        }
    }

    #endregion Manifest resources

    #region Build date/time

    public static class Build
    {
        /// <summary>
        /// Returns build date/time, assuming Version was specified as AssemblyVersion("1.0.*") (or any other major.minor)
        /// </summary>
        /// <param name="V">A Version instance, with build date/time info in build.revision fields</param>
        /// <remarks>
        /// Date/time does not honor daylight savings time.
        /// </remarks>
        public static DateTime Timestamp(Version V)
        {
            return new DateTime(2000, 2, 1) + new TimeSpan(V.Build, 0, 0, V.Revision * 2);
        }
    }

    #endregion Build date/time

    #region String <-> Stream

    /// <summary>
    /// Utilities to convert strings to and from streams
    /// </summary>
    public static class StreamTools
    {
        public static Stream FromString(string Input)
        {
            System.IO.Stream Result = new MemoryStream();
            StreamWriter Writer = new StreamWriter(Result);
            Writer.Write(Input);
            Writer.Flush();
            return Result;
        }

        public static string ToString(Stream Input)
        {
            using (StreamReader Reader = new StreamReader(CopyStream(Input)))
                return Reader.ReadToEnd();
        }

        private static Stream CopyStream(Stream Input)
        {
            const int BufferSize = 1024 * 64; // 64K buffer

            long StartPosition = Input.Position;
            long InputLength = Input.Length;
            byte[] Buffer = new byte[BufferSize];
            Stream Result = new MemoryStream();

            try
            {
                Input.Position = 0;
                while (Input.Position < InputLength)
                {
                    int ChunkSize = (int)Math.Min(BufferSize, InputLength - Input.Position);
                    Input.Read(Buffer, 0, ChunkSize);
                    Result.Write(Buffer, 0, ChunkSize);
                }
                Result.Flush();
                Result.Position = 0;
                return Result;
            }
            finally
            {
                Input.Position = StartPosition;
            }
        }
    }

    #endregion String <-> Stream

    #region Fire and forget

    public /*static*/ class FireAndForget
    {
        public static void EndInvoke(IAsyncResult Async)
        {
            Delegate D = (Delegate)Async.AsyncState; // raise an exception if AsyncState is not a delegate

            Type TypeofDelegate = D.GetType();
            MethodInfo EndInvoke = TypeofDelegate.GetMethod("EndInvoke", new Type[] { typeof(IAsyncResult) });
            EndInvoke.Invoke(D, new object[] { Async });
        }

        /// <summary>
        /// A lazy-create AsyncCallback singleton
        /// </summary>
        public static AsyncCallback EndInvokeDelegate
        {
            get
            {
                lock (DelegateLock)
                    if (_EndInvokeDelegate == null)
                        return _EndInvokeDelegate = new AsyncCallback(EndInvoke);
                    else
                        return _EndInvokeDelegate;
            }
        }
        private static AsyncCallback _EndInvokeDelegate;
        private static object DelegateLock = new object();

    }

    #endregion Fire and forget

    #region Lists

    public static class Concat
    {
        public static List<T> ToList<T>(params IEnumerable<T>[] Data)
        {
            List<T> Result = new List<T>();
            foreach (IEnumerable<T> E in Data)
                foreach (T Datum in E)
                    Result.Add(Datum);
            return Result;
        }

        public static T[] ToArray<T>(params IEnumerable<T>[] Data)
        {
            return ToList<T>(Data).ToArray();
        }
    }

    #endregion Lists

    #region Generic readonly locals

    public struct ReadOnly<T>
    {
        public readonly T Value;

        public ReadOnly(T Value)
        {
            this.Value = Value;
        }

        public ReadOnly(object Value)
        {
            this.Value = (T)Value;
        }
    }

    #endregion Generic readonly locals
}
