// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace Shemitz.Drawing
{
    public static class DrawingTools
    {
        #region Untransform

        public static PointF Untransform(Graphics G, float x, float y)
        {
            return Untransform(G.Transform, new PointF(x, y));
        }

        public static PointF Untransform(Graphics G, PointF Point)
        {
            return Untransform(G.Transform, Point);
        }

        public static PointF Untransform(Matrix Transform, PointF Point)
        {
            using (Matrix Inverted = Transform.Clone())
            {
                Inverted.Invert();
                return TransformPoint(Inverted, Point);
            }
        }

        #endregion Untransform

        #region TransformPoint

        public static PointF TransformPoint(Matrix Transform, PointF Point)
        {
            PointF[] PointArray = new PointF[] { Point };
            Transform.TransformPoints(PointArray);
            return PointArray[0];
        }

        #endregion TransformPoint

        #region RotatePoint

        public static PointF RotatePoint(PointF Point, float Angle)
        {
            //PointF[] PointArray = new PointF[] { Point };
            //using (Matrix Rotate = new Matrix())
            //{
            //    Rotate.Rotate(Angle);
            //    Rotate.TransformPoints(PointArray);
            //}
            //return PointArray[0];
            using (Matrix Rotate = new Matrix())
            {
                Rotate.Rotate(Angle);
                return TransformPoint(Rotate, Point);
            }
        }

        public static PointF RotatePoint(float X, float Y, float Angle)
        {
            return RotatePoint(new PointF(X, Y), Angle);
        }

        #endregion RotatePoint

        #region Alpha

        public static ImageAttributes Alpha(float Value)
        {
            ColorMatrix SetAlpha = new ColorMatrix(); // an identity matrix
            //SetAlpha.Matrix00 = 1.0f; // Red
            //SetAlpha.Matrix11 = 1.0f; // Green
            //SetAlpha.Matrix22 = 1.0f; // Blue
            SetAlpha.Matrix33 = Value; // alpha
            //SetAlpha.Matrix44 = 1.0f; // w

            ImageAttributes Result = new ImageAttributes();
            Result.SetColorMatrix(SetAlpha);
            return Result;
        }

        #endregion Alpha
    }
    public static class Change
    {
        #region Points

        #region Untransform

        public static PointF Untransform(Graphics G, float x, float y)
        {
            return Untransform(G.Transform, new PointF(x, y));
        }

        public static PointF Untransform(Graphics G, PointF Point)
        {
            return Untransform(G.Transform, Point);
        }

        public static PointF Untransform(Matrix Transform, PointF Point)
        {
            using (Matrix Inverted = Transform.Clone())
            {
                Inverted.Invert();
                return TransformPoint(Inverted, Point);
            }
        }

        #endregion Untransform

        #region TransformPoint

        public static PointF TransformPoint(Matrix Transform, PointF Point)
        {
            PointF[] PointArray = new PointF[] { Point };
            Transform.TransformPoints(PointArray);
            return PointArray[0];
        }

        #endregion TransformPoint

        #region RotatePoint

        public static PointF RotatePoint(PointF Point, float Angle)
        {
            //PointF[] PointArray = new PointF[] { Point };
            //using (Matrix Rotate = new Matrix())
            //{
            //    Rotate.Rotate(Angle);
            //    Rotate.TransformPoints(PointArray);
            //}
            //return PointArray[0];
            using (Matrix Rotate = new Matrix())
            {
                Rotate.Rotate(Angle);
                return TransformPoint(Rotate, Point);
            }
        }

        public static PointF RotatePoint(float X, float Y, float Angle)
        {
            return RotatePoint(new PointF(X, Y), Angle);
        }

        #endregion RotatePoint

        #endregion Points

        #region Alpha

        public static ImageAttributes Alpha(float Value)
        {
            ColorMatrix SetAlpha = new ColorMatrix(); // an identity matrix
            //SetAlpha.Matrix00 = 1.0f; // Red
            //SetAlpha.Matrix11 = 1.0f; // Green
            //SetAlpha.Matrix22 = 1.0f; // Blue
            SetAlpha.Matrix33 = Value; // alpha
            //SetAlpha.Matrix44 = 1.0f; // w

            ImageAttributes Result = new ImageAttributes();
            Result.SetColorMatrix(SetAlpha);
            return Result;
        }

        #endregion Alpha

        #region Colors

        #region ARGB

        public static Color SetAlpha(Color Original, int Value)
        {
            return SetChannel(Original, Value, Channel.Alpha);
        }

        public static Color SetRed(Color Original, int Value)
        {
            return SetChannel(Original, Value, Channel.Red);
        }

        public static Color SetGreen(Color Original, int Value)
        {
            return SetChannel(Original, Value, Channel.Green);
        }

        public static Color SetBlue(Color Original, int Value)
        {
            return SetChannel(Original, Value, Channel.Blue);
        }

        public static Color SetChannel(Color Original, int Value, int ChannelShift)
        {
            // Set up the bit masks
            int ChannelBits = 0x000000FF << ChannelShift;
            int OtherBits = (int)(0xFFFFFFFF ^ ChannelBits);

            // Qualify the Value
            Value = Value & 0x00FF; // Only the low byte

            // Strip out the channel we're setting
            int NonChannel = Original.ToArgb() & OtherBits;

            // Return the appropriate new ARGB
            return Color.FromArgb(NonChannel + (Value << ChannelShift));
        }
        public static Color SetChannel(Color Original, int Value, Channel Channel)
        {
            return SetChannel(Original, Value, (int)Channel * 8);
         }
        public enum Channel
        {
            Alpha = 3, Red = 2, Green = 1, Blue = 0,
            AlphaBits = Alpha * 8, RedBits = Red * 8, GreenBits = Green * 8, BlueBits = Blue * 8
        }
        #endregion ARGB

        #endregion Colors

        #region HSB

        public static Color SetHue(Color Original, float Value)
        {
            return HSB.SetHue(Original, Value);
        }

        public static Color SetSaturation(Color Original, float Value)
        {
            return HSB.SetSaturation(Original, Value);
        }

        public static Color SetBrightness(Color Original, float Value)
        {
            return HSB.SetBrightness(Original, Value);
        }

        #endregion HSB
    }

    public class HSB
    {
        #region The fields

        private float _Hue;
        private float _Saturation;
        private float _Brightness;

        #endregion The fields

        #region The constructors

        public HSB(float Hue, float Saturation, float Brightness)
        {
            this.Hue = Hue;
            this.Saturation = Saturation;
            this.Brightness = Brightness;
        }

        public HSB(Color ARGB)
            : this(ARGB.GetHue(), ARGB.GetSaturation(), ARGB.GetBrightness())
        { }

        #endregion The constructors

        #region The methods

        public Color ToColor()
        {
            // Based on Bob Powell's HSB-to-RGB code at http://www.bobpowell.net/RGBHSB.htm
            // - which was "Adapted from the algoritm in Foley and Van-Dam"

            double r = 0, g = 0, b = 0;
            double temp1, temp2;

            if (Brightness == 0)
            {
                r = g = b = 0;
            }
            else
            {
                if (Saturation == 0)
                {
                    r = g = b = Brightness;
                }
                else
                {
                    temp2 = (Brightness <= 0.5)
                        ? Brightness * (1.0 + Saturation)
                        : Brightness + Saturation - (Brightness * Saturation);
                    temp1 = 2.0 * Brightness - temp2;

                    double NormalizedHue = Hue / 360.0;
                    double[] t3 = new double[] { NormalizedHue + 1.0 / 3.0, NormalizedHue, NormalizedHue - 1.0 / 3.0 };
                    double[] clr = new double[] { 0, 0, 0 };
                    for (int i = 0; i < 3; i++)
                    {
                        if (t3[i] < 0)
                            t3[i] += 1.0;
                        if (t3[i] > 1)
                            t3[i] -= 1.0;

                        if (6.0 * t3[i] < 1.0)
                            clr[i] = temp1 + (temp2 - temp1) * t3[i] * 6.0;
                        else if (2.0 * t3[i] < 1.0)
                            clr[i] = temp2;
                        else if (3.0 * t3[i] < 2.0)
                            clr[i] = (temp1 + (temp2 - temp1) * ((2.0 / 3.0) - t3[i]) * 6.0);
                        else
                            clr[i] = temp1;
                    }
                    r = clr[0];
                    g = clr[1];
                    b = clr[2];
                }
            }

            return Color.FromArgb((int)(255 * r), (int)(255 * g), (int)(255 * b));
        }

        public Color ToColor(int Alpha)
        {
            Color Opaque = ToColor();
            return Change.SetAlpha(Opaque, Alpha);
        }

        public static Color ToColor(float Hue, float Saturation, float Brightness)
        {
            HSB Triplet = new HSB(Hue, Saturation, Brightness);
            return Triplet.ToColor();
        }

        public static Color ToColor(float Hue, float Saturation, float Brightness, int Alpha)
        {
            Color Opaque = ToColor(Hue, Saturation, Brightness);
            return Change.SetAlpha(Opaque, Alpha);
        }


        //public static Color HSL_to_RGB(HSL hsl)
        //{
        //    double r = 0, g = 0, b = 0;
        //    double temp1, temp2;

        //    if (hsl.L == 0)
        //    {
        //        r = g = b = 0;
        //    }
        //    else
        //    {
        //        if (hsl.S == 0)
        //        {
        //            r = g = b = hsl.L;
        //        }
        //        else
        //        {
        //            temp2 = ((hsl.L <= 0.5) ? hsl.L * (1.0 + hsl.S) : hsl.L + hsl.S - (hsl.L * hsl.S));
        //            temp1 = 2.0 * hsl.L - temp2;

        //            double[] t3 = new double[] { hsl.H + 1.0 / 3.0, hsl.H, hsl.H - 1.0 / 3.0 };
        //            double[] clr = new double[] { 0, 0, 0 };
        //            for (int i = 0; i < 3; i++)
        //            {
        //                if (t3[i] < 0)
        //                    t3[i] += 1.0;
        //                if (t3[i] > 1)
        //                    t3[i] -= 1.0;

        //                if (6.0 * t3[i] < 1.0)
        //                    clr[i] = temp1 + (temp2 - temp1) * t3[i] * 6.0;
        //                else if (2.0 * t3[i] < 1.0)
        //                    clr[i] = temp2;
        //                else if (3.0 * t3[i] < 2.0)
        //                    clr[i] = (temp1 + (temp2 - temp1) * ((2.0 / 3.0) - t3[i]) * 6.0);
        //                else
        //                    clr[i] = temp1;
        //            }
        //            r = clr[0];
        //            g = clr[1];
        //            b = clr[2];
        //        }
        //    }

        //    return Color.FromArgb((int)(255 * r), (int)(255 * g), (int)(255 * b));

        //}

        public static Color SetHue(Color Original, float Value)
        {
            HSB Result = new HSB(Original);
            Result.Hue = Value;
            return Result.ToColor();
        }

        public static Color SetSaturation(Color Original, float Value)
        {
            HSB Result = new HSB(Original);
            Result.Saturation = Value;
            return Result.ToColor();
        }

        public static Color SetBrightness(Color Original, float Value)
        {
            HSB Result = new HSB(Original);
            Result.Brightness = Value;
            return Result.ToColor();
        }

        #endregion The methods

        #region The properties

        public float Hue
        {
            get { return _Hue; }
            set { _Hue = value; }// Set(out _Hue, value); }
        }

        public float Saturation
        {
            get { return _Saturation; }
            set { Set(out _Saturation, value); }
        }

        public float Brightness
        {
            get { return _Brightness; }
            set { Set(out _Brightness, value); }
        }

        private void Set(out float Component, float Value)
        {
            if (Value < 0)
                Component = 0f;
            else if (Value < 1)
                Component = Value;
            else Component = 1f;
        }

        #endregion The properties
    }

    public static class Gradient
    {
        #region public static LinearGradientBrush Brush

        public static LinearGradientBrush Brush(Rectangle Bounds, Color StartColor, Color StopColor)
        {
            return Brush(Bounds, StartColor, StopColor, LinearGradientMode.ForwardDiagonal);
        }

        public static LinearGradientBrush Brush(Rectangle Bounds, Color StartColor, float StopBrightness)
        {
            return Brush(Bounds, StartColor, StopBrightness, LinearGradientMode.ForwardDiagonal);
        }

        public static LinearGradientBrush Brush(Rectangle Bounds, float StartBrightness, Color StopColor)
        {
            return Brush(Bounds, StartBrightness, StopColor, LinearGradientMode.ForwardDiagonal);
        }

        public static LinearGradientBrush Brush(Rectangle Bounds, Color StartColor, Color StopColor, LinearGradientMode Mode)
        {
            return new LinearGradientBrush(Bounds, StartColor, StopColor, Mode);
        }

        public static LinearGradientBrush Brush(Rectangle Bounds, Color StartColor, float StopBrightness, LinearGradientMode Mode)
        {
            return Brush(Bounds, StartColor, Change.SetBrightness(StartColor, StopBrightness), Mode);
        }

        public static LinearGradientBrush Brush(Rectangle Bounds, float StartBrightness, Color StopColor, LinearGradientMode Mode)
        {
            return Brush(Bounds, Change.SetBrightness(StopColor, StartBrightness), StopColor, Mode);
        }

        #endregion public static LinearGradientBrush Brush

        #region public static Bitmap Rectangle

        public static Bitmap Rectangle(Rectangle Bounds, Color StartColor, Color StopColor)
        {
            return Rectangle(Bounds, StartColor, StopColor, LinearGradientMode.ForwardDiagonal);
        }

        public static Bitmap Rectangle(Rectangle Bounds, Color StartColor, float StopBrightness)
        {
            return Rectangle(Bounds, StartColor, StopBrightness, LinearGradientMode.ForwardDiagonal);
        }

        public static Bitmap Rectangle(Rectangle Bounds, float StartBrightness, Color StopColor)
        {
            return Rectangle(Bounds, StartBrightness, StopColor, LinearGradientMode.ForwardDiagonal);
        }
        
        private static Bitmap Rectangle(Rectangle Bounds, Color StartColor, Color StopColor, LinearGradientMode Mode)
        {
            Bitmap Result = new Bitmap(Bounds.Width, Bounds.Height);

            using (Graphics BackgroundGraphics = Graphics.FromImage(Result))
            using (Brush BackgroundBrush = Gradient.Brush(Bounds, StartColor, StopColor, Mode))
                    BackgroundGraphics.FillRectangle(BackgroundBrush, Bounds);

            return Result;            
        }

        public static Bitmap Rectangle(Rectangle Bounds, Color StartColor, float StopBrightness, LinearGradientMode Mode)
        {
            return Rectangle(Bounds, StartColor, Change.SetBrightness(StartColor, StopBrightness), Mode);
        }

        public static Bitmap Rectangle(Rectangle Bounds, float StartBrightness, Color StopColor, LinearGradientMode Mode)
        {
            return Rectangle(Bounds, Change.SetBrightness(StopColor, StartBrightness), StopColor, Mode);
        }

        #endregion public static Bitmap Rectangle
    }
}
