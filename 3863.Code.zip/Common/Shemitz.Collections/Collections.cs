﻿// Copyright © 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
//using System.Text;

#endregion

/// Supports autoApply and manualApply for benchmarking - use Apply.

namespace Shemitz.Collections.Generic
{
    /// <summary>
    /// Enumeration operators - sort, reverse, and trim
    /// </summary>
    public static class Operator
    {
        /// <summary>
        /// Read a collection in reverse. NOTE: Creates a list containing all collection items.
        /// </summary>
        /// <typeparam name="T">The type of each item in  the collection</typeparam>
        /// <param name="Collection">An enumeration.</param>
        /// <returns>The enumeration, backwards.</returns>
        public static IEnumerable<T> Reverse<T>(IEnumerable<T> Collection)
        {
            List<T> Result = snapshot<T>(Collection);
            Result.Reverse();
            return Result;
        }

        /// <summary>
        /// Read a collection in sorted order. NOTE: Creates a list containing all collection items.
        /// </summary>
        /// <typeparam name="T">The type of each item in  the collection</typeparam>
        /// <param name="Collection">An enumeration.</param>
        /// <returns>The enumeration, sorted.</returns>
        public static IEnumerable<T> Sorted<T>(IEnumerable<T> Collection)
        {
            List<T> Result = snapshot<T>(Collection);
            Result.Sort();
            return Result;
        }

        /// <summary>
        /// Read a collection in sorted order. NOTE: Creates a list containing all collection items.
        /// </summary>
        /// <typeparam name="T">The type of each item in  the collection</typeparam>
        /// <param name="Collection">An enumeration.</param>
        /// <param name="Comparison">The comparison predicate</param>
        /// <returns>The enumeration, sorted.</returns>
        public static IEnumerable<T> Sorted<T>(IEnumerable<T> Collection, Comparison<T> Comparison)
        {
            List<T> Result = snapshot<T>(Collection);
            Result.Sort(Comparison);
            return Result;
        }

        /// <summary>
        /// Read a collection in sorted order. NOTE: Creates a list containing all collection items.
        /// </summary>
        /// <typeparam name="T">The type of each item in  the collection</typeparam>
        /// <param name="Collection">An enumeration.</param>
        /// <param name="Comparer">The comparison interface</param>
        /// <returns>The enumeration, sorted.</returns>
        public static IEnumerable<T> Sorted<T>(IEnumerable<T> Collection, IComparer<T> Comparer)
        {
            List<T> Result = snapshot<T>(Collection);
            Result.Sort(Comparer);
            return Result;
        }

        private static List<T> snapshot<T>(IEnumerable<T> Collection)
        {
            lock (Collection)
                return new List<T>(Collection);
        }

        /// <summary>
        /// Returns only the first N items of an emueration
        /// </summary>
        /// <typeparam name="T">Type of each item in enumeration</typeparam>
        /// <param name="Items">The enumeration</param>
        /// <param name="N">The max number of items to return</param>
        /// <returns>A (possibly shortened) enumeration</returns>
        public static IEnumerable<T> FirstN<T>(IEnumerable<T> Items, int N)
        {
            foreach (T Item in Items)
                if (N-- > 0)
                    yield return Item;
                else
                    yield break;
        }

    }

    /// <summary>
    /// A delegate that converts from one type to another. 
    /// Like Converter, but with params modeled on assignment.
    /// </summary>
    /// <typeparam name="OutType">Output type</typeparam>
    /// <typeparam name="InType">Input type</typeparam>
    /// <param name="Item">Input value</param>
    public delegate OutType Mapper<OutType, InType>(InType Item);

    /// <summary>
    /// Static methods for Predicate&lt;T&gt; manipulation
    /// </summary>
    /// <typeparam name="T">The type of each predicate Item</typeparam>
    public static class Predicates<T>
    {
        /// <summary>
        /// Inverts a Predicate&lt;T&gt;
        /// </summary>
        /// <param name="predicate">The Predicate&lt;T&gt; to invert</param>
        /// <returns>A new predicate that returns !predicate(Item)</returns>
        public static Predicate<T> Not(Predicate<T> predicate)
        {
            return delegate(T Item) { return !predicate(Item); };
        }

        /// <summary>
        /// A predicate that returns true when Item == Value
        /// </summary>
        /// <param name="Value">Value to test for</param>
        public static Predicate<T> Equal(T Value)
        {
            return (new Value(Value)).Equal;
        }

        /// <summary>
        /// A predicate that returns true when Item != Value
        /// </summary>
        /// <param name="Value">Value to test for</param>
        /// <returns></returns>
        public static Predicate<T> NotEqual(T Value)
        {
            return (new Value(Value)).NotEqual;
        }

        private class Value
        {
            private T V;

            public Value(T V)
            {
                this.V = V;
            }

            public bool Equal(T Item)
            {
                return V.Equals(Item);
            }

            public bool NotEqual(T Item)
            {
                return ! Equal(Item);
            }
        }
    }

//    interface IApply//<T>
//    {
//        T Find<T>(IEnumerable<T> Items, Predicate<T> Test);
//        IEnumerable<T> FindAll<T>(IEnumerable<T> Items, Predicate<T> Test);
//        IEnumerable<OutType> Map<OutType, InType>(IEnumerable<InType> Items, Mapper<OutType, InType> Map);
//        IEnumerable<OutType> ConvertAll<InType, OutType>(IEnumerable<InType> Items, Converter<InType, OutType> Convert);
//    }

    /// <summary>
    /// Internal class - use Apply
    /// </summary>
    public abstract class baseApply 
    {
        /// <summary>
        /// First item that satisfies predicate
        /// </summary>
        /// <typeparam name="T">Type of each element</typeparam>
        /// <param name="Items">Collection</param>
        /// <param name="Test">The predicate to apply</param>
        /// <returns>First item that satisfies predicate</returns>
        public static T Find<T>(IEnumerable<T> Items, Predicate<T> Test)
        {
            foreach (T Item in Items)
                if (Test(Item))
                    return Item;
            return default(T);
        }
    }

    /// <summary>
    /// Only for benchmarking - use Apply
    /// </summary>
    public class autoApply : baseApply//, IApply
    {
        /// <summary>
        /// Apply a delegate to eachg element of an enumeration. 
        /// Useful when you want to apply the same code to several different collections.
        /// </summary>
        /// <typeparam name="T">Enumeration type</typeparam>
        /// <param name="Items">An enumeration</param>
        /// <param name="Action">A method to apply to each item</param>
        public static void Apply<T>(IEnumerable<T> Items, Action<T> Action)
        {
            #warning this code needs some nunit tests
            foreach (T Item in Items)
                Action(Item);
        }

        /// <summary>
        /// All items in enumeration that satisfy predicate
        /// </summary>
        /// <typeparam name="T">Type of each item in enumeration</typeparam>
        /// <param name="Items">The enumeration</param>
        /// <param name="Test">The predicate to apply to each item</param>
        /// <returns></returns>
        public static IEnumerable<T> FindAll<T>(IEnumerable<T> Items, Predicate<T> Test)
        {
            foreach (T Item in Items)
                if (Test(Item))
                    yield return Item;
        }

        /// <summary>
        /// Returns a new enumeration, where each item has been transformed to a new type
        /// </summary>
        /// <typeparam name="OutType">Type of each item in output enumeration</typeparam>
        /// <typeparam name="InType">Type of each item in input enumeration</typeparam>
        /// <param name="Items">Input enumeration</param>
        /// <param name="Map">Delegate that converts each item</param>
        /// <returns></returns>
        public static IEnumerable<OutType> Map<OutType, InType>(IEnumerable<InType> Items, Mapper<OutType, InType> Map)
        {
            foreach (InType Item in Items)
                yield return Map(Item);
        }

        public static IEnumerable<OutType> ConvertAll<InType, OutType>(IEnumerable<InType> Items, Converter<InType, OutType> Convert)
        {
            return Map<OutType, InType>(Items, delegate(InType Item)
            {
                return Convert(Item);
            });
        }
    }

    /// <summary>
    /// Apply filters and maps to enumerations.
    /// </summary>
    public sealed class Apply : autoApply {}

    /// <summary>
    /// Only for benchmarking - use Apply
    /// </summary>
    public class manualApply : baseApply
    {
        public static IEnumerable<T> FindAll<T>(IEnumerable<T> Items, Predicate<T> Test)
        {
            return new allThat<T>(Items, Test);
        }
        private class allThat<T>: IEnumerable<T>, IEnumerator<T>
        {

            private IEnumerator<T> items;
            private Predicate<T> test;

            public allThat(IEnumerable<T> Items, Predicate<T> Test)
            {
                items = Items.GetEnumerator();
                test = Test;
            }

            #region IEnumerable<T> Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this;
            }

            public IEnumerator<T> GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerator<T> Members
            private T current;

            object IEnumerator.Current
            {
                get { return current; }
            }

            T IEnumerator<T>.Current
            {
                get { return current; }
            }

            bool IEnumerator.MoveNext()
            {
                while (items.MoveNext())
                {
                    if (test(current = items.Current))
                        return true;
                }
                return false; // fell off end, with no items that passed test
            }

            void IEnumerator.Reset() { }

            #endregion

            #region IDisposable Members

            void IDisposable.Dispose()
            {
            }

            #endregion
        }

        public static IEnumerable<OutType> Map<OutType, InType>(IEnumerable<InType> Items, Mapper<OutType, InType> Map)
        {
            return new map<OutType, InType>(Items, Map);
        }
        private class map<OutType, InType> : IEnumerable<OutType>, IEnumerator<OutType>
        {

            private IEnumerator<InType> items;
            private Mapper<OutType, InType> mapper;

            public map(IEnumerable<InType> Items, Mapper<OutType, InType> Map)
            {
                items = Items.GetEnumerator();
                mapper = Map;
            }

            #region IEnumerable<OutType> Members

            public IEnumerator<OutType> GetEnumerator()
            {
                return this;
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerator<OutType> Members
            private OutType current;

            public OutType Current
            {
                get { return current; }
            }

            object IEnumerator.Current
            {
                get { return current; }
            }

            public bool MoveNext()
            {
                if (items.MoveNext())
                {
                    current = mapper(items.Current);
                    return true;
                }
                else
                    return false;
            }

            public void Reset() {}

            #endregion

            #region IDisposable Members

            public void Dispose()
            {
            }

            #endregion
        }
    }
}
