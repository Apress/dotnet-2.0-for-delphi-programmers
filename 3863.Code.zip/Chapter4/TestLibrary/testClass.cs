// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;

namespace testLibrary
{
	public class testClass
	{
//		public testClass() 
//		{
//		}

		private int aField = 0;

		public void Set(int Value)
		{
			 aField = Value;
		}

		public int Conditional(object Obj)
		{
			Array asArray = Obj as Array;
			if (asArray != null)
				aField = asArray.Length;
			return aField;
		}
	}
}
