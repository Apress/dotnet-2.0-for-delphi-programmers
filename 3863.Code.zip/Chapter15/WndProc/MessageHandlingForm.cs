// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;

namespace WndProc
{
    public partial class MessageHandlingForm : Form
    {
        public MessageHandlingForm()
        {
            InitializeComponent();
            Messages = new MessageMap(this);
        }

        protected MessageMap Messages;

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (Messages.IsAssigned(m.Msg))
                Messages[m.Msg](ref m);
        }
    }

    public class MessageMap
    {
        /// <summary>
        /// Finds "[Message(int)] private AnyName(ref Message M) {}" methods, 
        /// declared in current form,
        /// and installs them in a MessageHandler dictionary, keyed by message number
        /// </summary>
        public MessageMap(Form ThisForm) : this(ThisForm, false) { }

        /// <summary>
        /// Finds public and private "[Message(int)] AnyName(ref Message M) {}" methods, 
        /// declared in current form,
        /// and installs them in a MessageHandler dictionary, keyed by message number
        /// </summary>
        public MessageMap(Form ThisForm, bool IncludePublicMethods) : this(ThisForm, false, IncludePublicMethods) { }

        /// <summary>
        /// Finds public and private "[Message(int)] AnyName(ref Message M) {}" methods, 
        /// optionally looking at inherited methods,
        /// and installs them in a MessageHandler dictionary, keyed by message number
        /// </summary>
        public MessageMap(Form ThisForm, bool IncludeInheritedMethods, bool IncludePublicMethods)
        {
            // Get methods
            Type ThisType = ThisForm.GetType();
            List<MethodInfo> MethodList = new List<MethodInfo>();

            // Public methods
            if (IncludePublicMethods)
            {
                BindingFlags PublicFlags = BindingFlags.Instance | BindingFlags.Public;
                if (!IncludeInheritedMethods)
                    PublicFlags |= BindingFlags.DeclaredOnly;

                MethodInfo[] Methods = ThisType.GetMethods(PublicFlags);

                MethodList.AddRange(Methods);
            }

            //// Get all public methods
            //BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public;
            //List<MethodInfo> Methods = new List<MethodInfo>(ThisType.GetMethods(Flags));

            // add private methods declared in current class
            BindingFlags PrivateFlags = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;
            MethodList.AddRange(ThisType.GetMethods(PrivateFlags));

            // Look for methods with the [Message] attribute
            Type AttributeType = typeof(MessageAttribute); // each typeof() call IS a call
            Type VoidType = typeof(void);
            Type MessageType = typeof(Message);
            Type HandlerType = typeof(MessageHandler);

            foreach (MethodInfo Method in MethodList)
            {
                bool InheritedMethod = Method.DeclaringType != Method.ReflectedType;
                // Look for methods with the [Message] attribute
                if (Method.IsDefined(AttributeType, InheritedMethod))
                    // Void?
                    if (Method.ReturnType == VoidType)
                    {
                        // (ref Message)?
                        ParameterInfo[] Parameters = Method.GetParameters();
                        if (Parameters.Length == 1)
                        {
                            Type ParameterType = Parameters[0].ParameterType;
                            if (ParameterType.IsByRef && MessageType.IsAssignableFrom(ParameterType.GetElementType()))
                            {
                                // [Message(N)] void Foo(ref Message Bar) {}
                                object[] Attributes = Method.GetCustomAttributes(AttributeType, InheritedMethod);
                                Debug.Assert(Attributes.Length == 1);
                                MessageAttribute Attribute = (MessageAttribute)Attributes[0];

                                // Add to the message map
                                this[Attribute.MessageNumber] = (MessageHandler)Delegate.CreateDelegate(
                                    HandlerType, ThisForm, Method);
                            }
                        }
                    }
            }
        }

        private Dictionary<int, MessageHandler> MessageHandlers =
            new Dictionary<int, MessageHandler>();

        public MessageHandler this[int MessageNumber]
        {
            get { return MessageHandlers[MessageNumber]; }
            set { MessageHandlers[MessageNumber] = value; }
        }

        public bool Contains(int MessageNumber)
        {
            return MessageHandlers.ContainsKey(MessageNumber);
        }

        /// <summary>
        /// Both in map, and not a null value
        /// </summary>
        public bool IsAssigned(int MessageNumber)
        {
            return Contains(MessageNumber) && (this[MessageNumber] != null);
        }

        public void Add(int MessageNumber, MessageHandler Handler)
        {
            MessageHandlers[MessageNumber] = GetMessageHandler(MessageNumber) + Handler;
        }

        public void Remove(int MessageNumber, MessageHandler Handler)
        {
            MessageHandlers[MessageNumber] = GetMessageHandler(MessageNumber) - Handler;
        }

        private MessageHandler GetMessageHandler(int Msg)
        {
            return MessageHandlers.ContainsKey(Msg) ? MessageHandlers[Msg] : null;
        }
    }

    [AttributeUsage(AttributeTargets.Method)]
    public class MessageAttribute : Attribute
    {
        public MessageAttribute(int MessageNumber)
        {
            this._MessageNumber = MessageNumber;
        }

        private int _MessageNumber;

        public int MessageNumber
        {
            get { return _MessageNumber; }
        }
    }

    public delegate void MessageHandler(ref Message M);
}