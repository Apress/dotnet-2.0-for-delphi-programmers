// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WndProc
{
    public partial class ClipboardWatcher : MessageHandlingForm
    {
        public ClipboardWatcher()
        {
            InitializeComponent();
            AcquireClipboardViewerChain();
        }

        #region ClipboardChanged event

        protected event MethodInvoker ClipboardChanged;

        [Message(WM_DRAWCLIPBOARD)]
        private void DrawClipboard(ref Message M)
        {
            if (ClipboardChanged != null)
                ClipboardChanged();
            SendMessage(NextClipboardViewer, M);
        }

        [Message(WM_DESTROYCLIPBOARD)]
        private void DestroyClipboard(ref Message M)
        {
            if (ClipboardChanged != null)
                ClipboardChanged();
            SendMessage(NextClipboardViewer, M);
        }

        [Message(WM_CHANGECBCHAIN)]
        private void ChangeCbChain(ref Message M)
        {
            if (M.WParam == NextClipboardViewer)
                NextClipboardViewer = M.LParam;
            else
                SendMessage(NextClipboardViewer, M);
        }

        #region Win32 API

        // defined in winuser.h (and Messages.pas)
        const int WM_DRAWCLIPBOARD = 0x308;
        const int WM_CHANGECBCHAIN = 0x030D;
        const int WM_DESTROYCLIPBOARD = 0x0307;

        IntPtr NextClipboardViewer;

        // Called in the constructor
        private void AcquireClipboardViewerChain()
        {
            NextClipboardViewer = (IntPtr)SetClipboardViewer((int)this.Handle);
        }

        // Called in Dispose
        private void RestoreClipboardViewerChain()
        {
            ChangeClipboardChain(this.Handle, NextClipboardViewer);
        }

        [DllImport("User32.dll")]
        protected static extern int
            SetClipboardViewer(int hWndNewViewer);

        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern bool
            ChangeClipboardChain(IntPtr hWndRemove,
            IntPtr hWndNewNext);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int SendMessage(IntPtr hwnd, int wMsg,
            IntPtr wParam,
            IntPtr lParam);

        public static int SendMessage(IntPtr WindowHandle, Message M)
        {
            return SendMessage(WindowHandle, M.Msg, M.WParam, M.LParam);
        }

        #endregion Win32 API

        #endregion ClipboardChanged event

        private void Form2_Load(object sender, EventArgs e)
        {
            ClipboardChanged += new MethodInvoker(Form2_ClipboardChanged);
            ClipboardChanged(); // set the ClipboardState label
        }

        void Form2_ClipboardChanged()
        {
            IDataObject Data = Clipboard.GetDataObject();
            if (Data.GetDataPresent(DataFormats.Rtf))
                ClipboardState.Text = "Clipboard contains RTF";
            else
                ClipboardState.Text = "Clipboard does not contain RTF";
        }

    }
}