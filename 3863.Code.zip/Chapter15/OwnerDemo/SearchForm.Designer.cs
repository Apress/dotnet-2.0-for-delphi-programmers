namespace OwnerDemo
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchForm));
            this.gradientPanels1 = new Shemitz.GradientPanels.GradientPanels();
            this.WordOriented = new System.Windows.Forms.CheckBox();
            this.SearchForLbl = new System.Windows.Forms.Label();
            this.FindButton = new System.Windows.Forms.Button();
            this.RegularExpression = new System.Windows.Forms.CheckBox();
            this.CaseSensitive = new System.Windows.Forms.CheckBox();
            this.SearchText = new System.Windows.Forms.TextBox();
            this.gradientPanels1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gradientPanels1
            // 
            this.gradientPanels1.BackColor = System.Drawing.Color.Transparent;
            this.gradientPanels1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gradientPanels1.BackgroundImage")));
            this.gradientPanels1.Controls.Add(this.WordOriented);
            this.gradientPanels1.Controls.Add(this.SearchForLbl);
            this.gradientPanels1.Controls.Add(this.FindButton);
            this.gradientPanels1.Controls.Add(this.RegularExpression);
            this.gradientPanels1.Controls.Add(this.CaseSensitive);
            this.gradientPanels1.Controls.Add(this.SearchText);
            this.gradientPanels1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gradientPanels1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gradientPanels1.Location = new System.Drawing.Point(0, 0);
            this.gradientPanels1.Name = "gradientPanels1";
            this.gradientPanels1.Size = new System.Drawing.Size(387, 61);
            this.gradientPanels1.StartColor = System.Drawing.Color.White;
            this.gradientPanels1.StopColor = System.Drawing.Color.PaleTurquoise;
            this.gradientPanels1.TabIndex = 0;
            // 
            // WordOriented
            // 
            this.WordOriented.AutoSize = true;
            this.WordOriented.Location = new System.Drawing.Point(115, 34);
            this.WordOriented.Name = "WordOriented";
            this.WordOriented.Size = new System.Drawing.Size(64, 17);
            this.WordOriented.TabIndex = 2;
            this.WordOriented.Text = "As &word";
            this.WordOriented.UseVisualStyleBackColor = false;
            // 
            // SearchForLbl
            // 
            this.SearchForLbl.AutoSize = true;
            this.SearchForLbl.Location = new System.Drawing.Point(7, 11);
            this.SearchForLbl.Name = "SearchForLbl";
            this.SearchForLbl.Size = new System.Drawing.Size(56, 13);
            this.SearchForLbl.TabIndex = 0;
            this.SearchForLbl.Text = "&Search for";
            // 
            // FindButton
            // 
            this.FindButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FindButton.Enabled = false;
            this.FindButton.Location = new System.Drawing.Point(305, 30);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(75, 23);
            this.FindButton.TabIndex = 5;
            this.FindButton.Text = "&Find";
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // RegularExpression
            // 
            this.RegularExpression.AutoSize = true;
            this.RegularExpression.Location = new System.Drawing.Point(190, 34);
            this.RegularExpression.Name = "RegularExpression";
            this.RegularExpression.Size = new System.Drawing.Size(116, 17);
            this.RegularExpression.TabIndex = 3;
            this.RegularExpression.Text = "&Regular expression";
            // 
            // CaseSensitive
            // 
            this.CaseSensitive.AutoSize = true;
            this.CaseSensitive.Location = new System.Drawing.Point(7, 34);
            this.CaseSensitive.Name = "CaseSensitive";
            this.CaseSensitive.Size = new System.Drawing.Size(94, 17);
            this.CaseSensitive.TabIndex = 2;
            this.CaseSensitive.Text = "&Case sensitive";
            // 
            // SearchText
            // 
            this.SearchText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchText.Location = new System.Drawing.Point(70, 8);
            this.SearchText.Name = "SearchText";
            this.SearchText.Size = new System.Drawing.Size(310, 20);
            this.SearchText.TabIndex = 1;
            this.SearchText.TextChanged += new System.EventHandler(this.SearchText_TextChanged);
            // 
            // SearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 61);
            this.Controls.Add(this.gradientPanels1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SearchForm";
            this.ShowInTaskbar = false;
            this.Text = "Search file";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SearchForm_FormClosed);
            this.gradientPanels1.ResumeLayout(false);
            this.gradientPanels1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Shemitz.GradientPanels.GradientPanels gradientPanels1;
        private System.Windows.Forms.Label SearchForLbl;
        private System.Windows.Forms.Button FindButton;
        private System.Windows.Forms.CheckBox RegularExpression;
        private System.Windows.Forms.CheckBox CaseSensitive;
        private System.Windows.Forms.TextBox SearchText;
        private System.Windows.Forms.CheckBox WordOriented;



    }
}