namespace OwnerDemo
{
    partial class ViewerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RTF = new System.Windows.Forms.RichTextBox();
            this.SelectFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // RTF
            // 
            this.RTF.BackColor = System.Drawing.SystemColors.Window;
            this.RTF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RTF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RTF.HideSelection = false;
            this.RTF.Location = new System.Drawing.Point(0, 0);
            this.RTF.Name = "RTF";
            this.RTF.ReadOnly = true;
            this.RTF.ShowSelectionMargin = true;
            this.RTF.Size = new System.Drawing.Size(640, 542);
            this.RTF.TabIndex = 0;
            this.RTF.Text = "Ctrl+F\tFind text\nCtrl+O\tOpen file";
            // 
            // SelectFileDlg
            // 
            this.SelectFileDlg.Filter = "Text files|*.rtf;*.txt";
            // 
            // ViewerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 542);
            this.Controls.Add(this.RTF);
            this.KeyPreview = true;
            this.Name = "ViewerForm";
            this.Text = "RTF Viewer";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ViewerForm_KeyPress);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog SelectFileDlg;
        internal System.Windows.Forms.RichTextBox RTF;
    }
}

