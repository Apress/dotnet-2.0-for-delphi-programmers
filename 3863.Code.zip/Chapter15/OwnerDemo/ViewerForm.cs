// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace OwnerDemo
{
    public partial class ViewerForm : Form
    {
        public ViewerForm()
        {
            InitializeComponent();
        }

        private void ViewerForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case '\x06': // Ctrl+F
                    ShowSearchDialog();
                    break;
                case '\x0F': // Ctrl+O
                    OpenFileCommand();
                    break;
            }
        }

        #region ShowSearchDialog

        private void ShowSearchDialog()
        {
            if (SearchDlg == null)
                SearchDlg = new SearchForm(this);
            SearchDlg.Show();
        }

        internal SearchForm SearchDlg = null;

        #endregion ShowSearchDialog

        #region OpenFileCommand

        private void OpenFileCommand()
        {
            if (SelectFileDlg.ShowDialog() == DialogResult.OK)
            {
                switch (Path.GetExtension(SelectFileDlg.FileName.ToLower()))
                {
                    case ".txt":
                        RTF.Text = ReadTextFile(SelectFileDlg.FileName);
                        RTF.SelectionStart = 0;
                        break;
                    case ".rtf":
                        RTF.SelectionStart = 0;
                        RTF.LoadFile(SelectFileDlg.FileName);
                        break;
                }                
            }
        }

        private string ReadTextFile(string Filename)
        {
            using (StreamReader F = new StreamReader(Filename))
                return F.ReadToEnd();
        }

        #endregion OpenFileCommand

    }
}