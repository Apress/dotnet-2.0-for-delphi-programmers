// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Drawing.Imaging;

namespace Shemitz.GradientPanels
{
    public class GradientPanels : Panel
    {
        public GradientPanels()
        {
            base.BackColor = Color.Transparent;
        }

        public Color StartColor
        {
            get { return _StartColor; }
            set { _StartColor = value;  NewBackgroundImage();  }
        }
        private Color _StartColor = Color.Ivory;

        public Color StopColor
        {
            get { return _StopColor;    }
            set { _StopColor = value; NewBackgroundImage(); }
        }
        private Color _StopColor = Color.LightBlue;

        public LinearGradientMode GradientMode
        {
            get { return _GradientMode; }
            set { _GradientMode = value; NewBackgroundImage(); }
        }
        private LinearGradientMode _GradientMode = LinearGradientMode.ForwardDiagonal;

        protected override void OnLayout(LayoutEventArgs levent)
        {
            base.OnLayout(levent);
            NewBackgroundImage();
        }

        private void NewBackgroundImage()
        {
            Rectangle Client = ClientRectangle;
            Bitmap Image = new Bitmap(Client.Width, Client.Height, PixelFormat.Format32bppArgb);
            using (LinearGradientBrush Brush = new LinearGradientBrush(
                Client,
                StartColor,
                StopColor,
                GradientMode))
            using (Graphics G = Graphics.FromImage(Image))
                G.FillRectangle(Brush, Client);
            BackgroundImage = Image;
        }
    }
}
