using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace Shemitz.GradientPanels
{
    public class GradientPanels : Panel
    {
        public Color StartColor
        {
            get { return _StartColor; }
            set { _StartColor = value; }
        }
        private Color _StartColor = Color.Ivory;

        public Color StopColor
        {
            get { return _StopColor; }
            set { _StopColor = value; }
        }
        private Color _StopColor = Color.HotPink;

        public LinearGradientMode GradientMode
        {
            get { return _GradientMode; }
            set { _GradientMode = value; }
        }
        private LinearGradientMode _GradientMode;

        private Bitmap NewBackgroundImage()
        {
            Rectangle Client = ClientRectangle;
            using (LinearGradientBrush Brush = new LinearGradientBrush(
                Client,
                Color.HotPink,
                Color.Ivory,
                LinearGradientMode.ForwardDiagonal))
            using (Bitmap Image = new Bitmap(Client.Width, Client.Height))
            {
                using (Graphics G = Graphics.FromImage(Image))
                    G.FillRectangle(Brush, Client);
                return Image;
            }
        }

        protected override void OnLayout(LayoutEventArgs levent)
        {
            base.OnLayout(levent);
            BackgroundImage = NewBackgroundImage();
        }
}
}
