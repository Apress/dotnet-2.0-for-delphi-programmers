// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace OwnerDemo
{
    public partial class SearchForm : Form
    {
        public SearchForm(ViewerForm Owner)
        {
            InitializeComponent();

            this.Owner = Viewer = Owner;
        }

        ViewerForm Viewer;

        private void SearchText_TextChanged(object sender, EventArgs e)
        {
            string Text = SearchText.Text;
            FindButton.Enabled = Text != "";
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            string Text = SearchText.Text;
            Debug.Assert(Text != null && Text != "");

            bool IgnoreCase = !CaseSensitive.Checked;
            bool AsWord = WordOriented.Checked;
            bool UseRegex = RegularExpression.Checked;

            RegexOptions Flags = IgnoreCase
                ? RegexOptions.IgnoreCase
                : RegexOptions.None;
            if (!UseRegex)
                Text = Regex.Escape(Text); // search for Text as a literal
            if (AsWord)
                Text = @"\b" + Text + @"\b";

            Regex R = new Regex(Text, Flags);

            RichTextBox RTF = Viewer.RTF;
            Match M = R.Match(RTF.Text,
                RTF.SelectionStart + RTF.SelectionLength);
            if (M.Success)
            {
                RTF.SelectionStart = M.Index;
                RTF.SelectionLength = M.Length;
            }
        }

        private void SearchForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Viewer.SearchDlg = null;
        }
    }
}