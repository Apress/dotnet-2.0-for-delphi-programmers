// Copyright � 2006 by Jon Shemitz, all rights reserved.
// Permission is hereby granted to freely use, modify, and
// distribute this source code PROVIDED that all six lines of
// this copyright and contact notice are included without any
// changes. Questions? Comments? Offers of work?
// mailto:jon@midnightbeach.com - http://www.midnightbeach.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CausesValidation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Message(string M)
        {
            //Messages.SelectionStart = Messages.Text.Length;
            //Messages.SelectedText = M + '\n';
            //// dang, this works with RTF ...

            M += ": " + DateTime.Now.ToString();
            string Text = Messages.Text;
            if (Text == null || Text == "")
                Messages.Text = M;
            else
            {
                Text += "\n" + M;
                Messages.Lines = Text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            }
        }

        private void A_Validating(object sender, CancelEventArgs e)
        {
            Message("A_Validating");
        }

        private void B_Validating(object sender, CancelEventArgs e)
        {
            Message("B_Validating");
        }

        private void C_Validating(object sender, CancelEventArgs e)
        {
            Message("C_Validating");
            e.Cancel = Weirdness.Checked && this.ActiveControl != C;
        }

        private void Cancel_Validating(object sender, CancelEventArgs e)
        {
            Message("Cancel_Validating");
        }

        private void OK_Validating(object sender, CancelEventArgs e)
        {
            Message("OK_Validating");
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Message("Cancel_Click");
        }

        private void OK_Click(object sender, EventArgs e)
        {
            Message("OK_Click");
        }

    }
}