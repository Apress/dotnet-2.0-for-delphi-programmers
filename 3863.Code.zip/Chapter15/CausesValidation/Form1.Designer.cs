namespace CausesValidation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Messages = new System.Windows.Forms.TextBox();
            this.A = new System.Windows.Forms.TextBox();
            this.B = new System.Windows.Forms.TextBox();
            this.C = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Weirdness = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // Messages
            // 
            this.Messages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Messages.BackColor = System.Drawing.SystemColors.Window;
            this.Messages.Location = new System.Drawing.Point(0, 132);
            this.Messages.Multiline = true;
            this.Messages.Name = "Messages";
            this.Messages.ReadOnly = true;
            this.Messages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Messages.Size = new System.Drawing.Size(256, 142);
            this.Messages.TabIndex = 0;
            this.Messages.TabStop = false;
            this.toolTip1.SetToolTip(this.Messages, "CausesValidation is true");
            // 
            // A
            // 
            this.A.CausesValidation = false;
            this.A.Location = new System.Drawing.Point(16, 11);
            this.A.Name = "A";
            this.A.Size = new System.Drawing.Size(100, 20);
            this.A.TabIndex = 0;
            this.toolTip1.SetToolTip(this.A, "A - CausesValidation is false");
            this.A.Validating += new System.ComponentModel.CancelEventHandler(this.A_Validating);
            // 
            // B
            // 
            this.B.Location = new System.Drawing.Point(16, 51);
            this.B.Name = "B";
            this.B.Size = new System.Drawing.Size(100, 20);
            this.B.TabIndex = 1;
            this.toolTip1.SetToolTip(this.B, "B - CausesValidation is true");
            this.B.Validating += new System.ComponentModel.CancelEventHandler(this.B_Validating);
            // 
            // C
            // 
            this.C.Location = new System.Drawing.Point(16, 90);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(100, 20);
            this.C.TabIndex = 2;
            this.toolTip1.SetToolTip(this.C, "C - CausesValidation is true");
            this.C.Validating += new System.ComponentModel.CancelEventHandler(this.C_Validating);
            // 
            // button1
            // 
            this.button1.CausesValidation = false;
            this.button1.Location = new System.Drawing.Point(165, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Cancel";
            this.toolTip1.SetToolTip(this.button1, "CausesValidation is false");
            this.button1.Click += new System.EventHandler(this.Cancel_Click);
            this.button1.Validating += new System.ComponentModel.CancelEventHandler(this.Cancel_Validating);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(165, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "OK";
            this.toolTip1.SetToolTip(this.button2, "CausesValidation is true");
            this.button2.Click += new System.EventHandler(this.OK_Click);
            this.button2.Validating += new System.ComponentModel.CancelEventHandler(this.OK_Validating);
            // 
            // Weirdness
            // 
            this.Weirdness.AutoSize = true;
            this.Weirdness.CausesValidation = false;
            this.Weirdness.Location = new System.Drawing.Point(165, 93);
            this.Weirdness.Name = "Weirdness";
            this.Weirdness.Size = new System.Drawing.Size(76, 17);
            this.Weirdness.TabIndex = 5;
            this.Weirdness.Text = "Weirdness";
            this.toolTip1.SetToolTip(this.Weirdness, "C hogs the focus when this is checked.");
            this.Weirdness.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 274);
            this.Controls.Add(this.Weirdness);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.C);
            this.Controls.Add(this.B);
            this.Controls.Add(this.A);
            this.Controls.Add(this.Messages);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Validation Explorer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Messages;
        private System.Windows.Forms.TextBox A;
        private System.Windows.Forms.TextBox B;
        private System.Windows.Forms.TextBox C;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox Weirdness;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

