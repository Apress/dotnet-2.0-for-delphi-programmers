namespace AlignVsAnchor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TopAlignedPanel = new System.Windows.Forms.Panel();
            this.BottomAnchoredPanel = new System.Windows.Forms.Panel();
            this.TopAlignedLabel = new System.Windows.Forms.Label();
            this.BottomAnchoredLabel = new System.Windows.Forms.Label();
            this.TopAlignedPanel.SuspendLayout();
            this.BottomAnchoredPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopAlignedPanel
            // 
            this.TopAlignedPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TopAlignedPanel.Controls.Add(this.TopAlignedLabel);
            this.TopAlignedPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopAlignedPanel.Location = new System.Drawing.Point(0, 0);
            this.TopAlignedPanel.Name = "TopAlignedPanel";
            this.TopAlignedPanel.Size = new System.Drawing.Size(222, 28);
            this.TopAlignedPanel.TabIndex = 0;
            // 
            // BottomAnchoredPanel
            // 
            this.BottomAnchoredPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.BottomAnchoredPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BottomAnchoredPanel.Controls.Add(this.BottomAnchoredLabel);
            this.BottomAnchoredPanel.Location = new System.Drawing.Point(25, 65);
            this.BottomAnchoredPanel.Name = "BottomAnchoredPanel";
            this.BottomAnchoredPanel.Size = new System.Drawing.Size(172, 48);
            this.BottomAnchoredPanel.TabIndex = 1;
            // 
            // TopAlignedLabel
            // 
            this.TopAlignedLabel.BackColor = System.Drawing.Color.Transparent;
            this.TopAlignedLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TopAlignedLabel.Location = new System.Drawing.Point(0, 0);
            this.TopAlignedLabel.Name = "TopAlignedLabel";
            this.TopAlignedLabel.Size = new System.Drawing.Size(220, 26);
            this.TopAlignedLabel.TabIndex = 0;
            this.TopAlignedLabel.Text = "Top Aligned Panel";
            this.TopAlignedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BottomAnchoredLabel
            // 
            this.BottomAnchoredLabel.BackColor = System.Drawing.Color.Transparent;
            this.BottomAnchoredLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BottomAnchoredLabel.Location = new System.Drawing.Point(0, 0);
            this.BottomAnchoredLabel.Name = "BottomAnchoredLabel";
            this.BottomAnchoredLabel.Size = new System.Drawing.Size(170, 46);
            this.BottomAnchoredLabel.TabIndex = 1;
            this.BottomAnchoredLabel.Text = "Bottom Anchored Panel";
            this.BottomAnchoredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 125);
            this.Controls.Add(this.BottomAnchoredPanel);
            this.Controls.Add(this.TopAlignedPanel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.TopAlignedPanel.ResumeLayout(false);
            this.BottomAnchoredPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel TopAlignedPanel;
        private System.Windows.Forms.Panel BottomAnchoredPanel;
        private System.Windows.Forms.Label TopAlignedLabel;
        private System.Windows.Forms.Label BottomAnchoredLabel;
    }
}

